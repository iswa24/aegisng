AEGIS — combined package
Generated 2026-09-24

- AEGIS-web-api-agent-cases.zip         — 40 governed web/API case templates
      (one per weakness class, OWASP WSTG + API Top 10 + CWE) + INDEX +
      GOVERNANCE-MATRIX.csv. (A zip inside this zip.)
- AEGIS-BRD-TRD-Requirements.xlsx       — the BRD/TRD workbook (21 tabs).
- 20-governance-authorize-spec.md       — governance authorize() service spec (L5.1).
- DR-governance-three-layers-design.md  — instructions vs guardrails vs governance
      (three-layer control model + worked example).
- aegis-microservice-architecture.md    — the microservice design document.
- AEGIS-microservice-architecture.png/.svg — the microservice architecture diagram.

Note: the workbook was scrubbed of firm name + obvious internal tokens; the
governance and microservice documents were NOT scrubbed and still contain internal
codenames (and the microservice doc predates the name-removal pass).
