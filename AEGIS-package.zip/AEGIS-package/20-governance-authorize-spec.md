# 20 · governance — `authorize()` Service Specification (L5.1)

**Status:** SPECCED · **Lane:** L5 Control plane (the authorization wall) · **Owner:** AEGIS platform
**Depends on:** Run Broker (L4, the only door in), RoE / Case model (L2), Foundation Postgres (state: budget, kill-switch), Cosmos/WORM (L6, the audit log)
**Called by:** the worker, on **every** action — via the `GovernanceClient` in `aegis_worker/governance.py`
**Last updated:** 2026-09-22

---

## 1. What this service is (in one paragraph)

`governance` is the **yes/no wall**. Before the worker does anything that touches a
target — read a page, send a POST, assume a role — it must first **ask** governance
"am I allowed to do this?" and obey the answer. Governance holds all the authority
(the approved scope, the budget, the kill-switch, the destruction ban) in one place,
**outside** the worker, and answers one question at a time: *allow*, *deny*, or
*pause for a human*. It is deny-by-default and fail-closed: if anything is missing,
stale, or broken, the answer is **no**.

**SWE analogy.** This is an **authorization service**, exactly like an authz/policy
service in a normal app (think OPA, or a `checkPermission(user, action, resource)`
call). Your app code never decides whether a user may delete a record — it asks the
authz service and does what it says. AEGIS is the same, with one twist: the "app code"
here is a pentest agent that may be running attacker-influenced input, so we assume it
could be compromised and design the wall to hold even then.

---

## 2. Why it lives *outside* the worker (the one idea everything hangs on)

This is DEC-1, and it is the whole point, so it's worth saying plainly.

If the guard lived **inside** the agent process — an `if allowed:` check in the same
code — then a compromised agent could just patch it out. It's like putting the bouncer
*inside* the nightclub and letting patrons rewrite his instructions. So the guard lives
in a **separate service, in a separate trust zone**, that the worker can only *talk to*,
never *modify*.

Concretely:
- The worker reaches governance through **exactly one network path — the Run Broker**
  (DEC-2). It has no database connection, no signing key, no route to anything else in
  the control plane.
- The worker can **ask** for a decision. It cannot **set** one. The worst a
  fully-compromised worker can do is get a wrong **deny** (a false "no"), never a forged
  **allow**. It can lie in its request, but a lie only ever narrows what it's granted.
- `aegis_worker/governance.py` is just the **phone** — an SDK that makes the call and
  returns the answer. It carries no authority itself. (The file even says so at the top.)

> **The invariant:** nothing that touches attacker-controlled bytes ever holds authority,
> a DB write, a signing key, or a route into the control plane. The worker touches those
> bytes, so it holds none of those things. Governance holds all of them and touches none
> of the bytes — every field it receives is a bounded type or a **hash**, never raw target
> data.

---

## 3. Design decisions (locked)

| # | Decision | Why |
|---|----------|-----|
| DEC-G1 | **External wall, reached only via the Run Broker.** Governance is a control-plane service; the worker calls it over the network, never links it in-process. | A compromised agent can't bypass, forge, or silence a guard it has no write access to. (DEC-1 / DEC-2.) |
| DEC-G2 | **Deny-by-default, fail-closed at every step.** Every branch's fallback is *deny*. Missing RoE, expired token, budget lookup down, audit log unwritable → **deny**. | An unaudited or unauthorized *allow* is far worse than a false *deny*. A false *deny* just stalls a run; a false *allow* is an ungoverned action against a real system. |
| DEC-G3 | **One atomic decision, not a distributed checklist.** Scope, environment, destruction-ban, budget, rate-limit, and kill-switch are all evaluated in **one** service, in **one** call. | If budget lived in another service, every decision would need a mid-decision network hop — a second failure domain that could independently regress to fail-*open*. One brain, one deny-by-default evaluation. |
| DEC-G4 | **Allow is a short-lived capability, not a permanent grant.** An *allow* returns a **60-second, single-action token** the egress-gateway checks. Permission expires almost immediately. | Closes the gap between "authorized" and "acted." Like a pre-signed URL that expires: you got a yes for *this* action, *now* — not a standing licence. |
| DEC-G5 | **Write the decision to the audit log BEFORE returning it.** The WORM event is appended first; only then does the answer leave the process. If the log write fails, the answer becomes *deny("audit_unavailable")*. | "We authorized X" must be a durable fact the instant X is allowed. No silent, unlogged allows — ever. |
| DEC-G6 | **Destruction is banned platform-wide, ahead of RoE.** A deny-list of destructive action signatures is checked *before* the run's own permissions are even consulted. **No RoE can grant them.** | Some actions (data deletion, infra teardown, disabling MFA) are never OK from an automated run, no matter what a given engagement's scope says. Deny-wins. |
| DEC-G7 | **Guardrails ≠ governance.** Content hygiene (prompt-injection filtering, output sanity) is a *separate, softer* thing and is **never** a substitute for this wall. (DEC-3.) | A guardrail is a spam filter; governance is the door lock. One cleans text, the other authorizes actions. Don't let a passed guardrail imply an authorized action. |

---

## 4. The action classes (what the worker is asking about)

Every capability the agent can invoke is labelled with **one action class**. This is the
single most important input to a decision — it says *how dangerous* the thing is.

| Class | Means | Example | Default treatment |
|-------|-------|---------|-------------------|
| `READ` | Observe only. No state change on the target. | GET a page, read a banner, enumerate endpoints, resolve DNS. | Allowed in-scope (even read-only prod, Zone A). |
| `CHANGE` | Mutates state. | POST that writes data, change a setting, upload a file, log in and alter something. | Allowed **only if the RoE permits changes**, and normally only on a replica (Zone B). |
| `DESTROY` | Destructive / irreversible. | Delete data, teardown, DoS-like load, credential rotation the run doesn't own. | **Denied** by the platform-wide ban (DEC-G6). Only ever on an isolated twin, human-approved, never headless. |
| `UNKNOWN` | Not yet classified. | A new tool, or an action the classifier couldn't label. | **Treated as the most dangerous → deny.** (Default-deny for the un-labelled.) |

This matches what the worker already sends today (`aegis_worker/governance.py`:
`READ / CHANGE / DESTROY / UNKNOWN`). A finer sub-taxonomy
(`read_only_recon → state_changing → privilege_escalation → lateral_movement →
prod_confirm`) is an **optional refinement** carried as an open follow-up (§11, OF-2);
the four coarse classes are the canonical contract.

**Environment / zone** rides alongside the class and decides *where* a class is allowed:

- **Zone A — read-only prod:** `READ` only. The real target, look-but-don't-touch.
- **Zone B — replica:** `CHANGE` allowed here — an isolated twin, so mutation is safe.
- **Zone C — gated prod confirm:** a `CHANGE` on the *real* target, but **only** with a
  fresh human approval (HITL). This is the pause path (§6).

---

## 5. The contract (request → decision)

### 5.1 Wire shape (worker → Run Broker → governance)

```
POST /authorize
{
  "run_id":       "...",                 # which run is asking
  "fid":          "...",                 # the per-run functional identity (which workload)
  "obo_subject":  "sid:iswarya.v",       # WHICH HUMAN's authority this run acts under (SID)
  "action_class": "READ|CHANGE|DESTROY|UNKNOWN",
  "tool":         "http_get",            # the capability being invoked
  "target":       { "host": "app.example.com",
                    "resolved_ip": "10.2.3.4",   # the IP it actually resolved to
                    "port": 443 },
  "args_digest":  "sha256:...",          # a HASH of the arguments — never the raw payload
  "roe_token":    "<JWS>"                # the signed Rules-of-Engagement for this run
}
```

Two things to notice, both deliberate:
- **`obo_subject` is required.** Every run acts under a *named human's* authority (the
  SID that `console-api` carried on-behalf-of, DEC of the entry lane). A request with no
  attributable human is refused **before any other check** — there's no such thing as an
  anonymous authorized action.
- **`args_digest` is a hash, never the raw arguments.** Governance never sees
  attacker-influenced bytes. It authorizes on *facts about* the action (class, target,
  which human, which run), not on the payload itself. (The worker's client already hashes
  the payload: `payload_sha256`.)

### 5.2 Response shape

```
200 OK
{
  "decision":   "ALLOW | DENY | PAUSE_FOR_APPROVAL",
  "reason":     "human-readable why",
  "layer":      "obo | roe | killswitch | destruction | scope | zone | budget | rate | audit",
  "audit_ref":  "evt_01H...",            # the WORM event id this decision was written as (BEFORE this reply)
  "capability": {                        # PRESENT ONLY ON ALLOW
     "gateway_token": "<JWS>",           # a signed, single-action token the egress-gateway checks
     "ttl_seconds": 60
  }
}
```

### 5.3 How the worker's client maps to this

`GovernanceClient.authorize(action_class, summary, payload)` returns a
`Decision(allow, reason, audit_ref)`. The mapping:

| Wire `decision` | `Decision.allow` | What the worker does |
|-----------------|------------------|----------------------|
| `ALLOW` | `True` | Proceed — and attach `capability.gateway_token` to the actual egress call, `audit_ref` to the evidence record. |
| `DENY` | `False` | Do not act. Record the block, move on / re-plan. |
| `PAUSE_FOR_APPROVAL` | `False` (headless) | In a **baseline/headless** run, a pause the human can't answer resolves as a block. In an **interactive** run, it surfaces as a decision card and the run waits (§6). |

> The prod client (`_decide_remote`) is the real thing; `_decide_dev` is a legible local
> stub (READ→allow, CHANGE→allow-if-RoE, else deny) so the harness runs offline. **The
> shape of `authorize()` never changes between dev and prod** — only where the decision
> comes from.

---

## 6. The decision pipeline (the exact order, and why the order matters)

Governance runs these checks **in this order**, and the order is a security property:
the cheapest, most absolute bans come first, so nothing expensive or bypassable runs
before them. Every branch is **fail-closed** (its fallback is deny).

```python
def authorize(req) -> Decision:

    # 0. Attribution — is there a named human behind this? (fail-closed OBO)
    if not req.obo_subject:
        return deny("no attributable authority", layer="obo")

    # 1. RoE — is the run's scope valid, current, and untampered?
    roe = verify_roe(req.roe_token)          # signature + not-expired + not-superseded
    if not roe:                              #   + scope_hash matches the CURRENT approved record
        return deny("invalid_roe", layer="roe")

    # 2. Kill-switch — has this run/engagement been stopped? (checked before ANY allow)
    if killswitch_state(req.run_id) != ARMED:
        return deny("killswitch_triggered", layer="killswitch")

    # 3. Destruction ban — platform-wide, RoE-INDEPENDENT, deny-wins
    if destruction_registry.matches(req.action):
        return deny("destructive_action_denied", layer="destruction")

    # 4. Scope — is the target actually in bounds? (resolved IP AND hostname)
    if not target_in_scope(req.target, roe):
        return deny("out_of_scope", layer="scope")

    # 5. Environment/zone — does this zone permit this action class?
    if not roe.zone_permits(req.action_class):
        return deny("zone_violation", layer="zone")

    # 6. HITL — does this action need a human's yes it doesn't yet have?
    if requires_hitl(req.action_class, roe.zone) and not has_prior_approval(req):
        return pause_for_approval(req)       # a decision card, never a silent allow

    # 7. Budget — is there room left in the run's cost envelope?
    reservation = reserve_budget(req.run_id, cost(req.action))
    if not reservation:
        return deny("budget_exhausted", layer="budget")

    # 8. Rate — are we hammering the target?
    if rate_limited(req.run_id):
        release_budget(reservation)
        return deny("rate_limited", layer="rate")

    # 9. ALLOW — but only after the fact is durably logged (DEC-G5)
    decision = allow(req, ttl_seconds=60, reservation=reservation)
    if not durably_append_event(decision):   # unaudited allow is worse than a false deny
        release_budget(reservation)
        return deny("audit_unavailable", layer="audit")
    return decision
```

**Why this order, in plain terms:**

1. **Attribution first** — no point checking anything if we don't even know whose
   authority this is. Anonymous → out immediately.
2. **RoE next** — the RoE is the *only* source of "what's allowed for this run." If it's
   forged, expired, or a stale version that was superseded, everything downstream is
   meaningless.
3. **Kill-switch before any allow** — a stopped run gets **zero** further allows, period,
   no matter what else is true. This is the emergency brake.
4. **Destruction ban before RoE's own allow-list** — this is deny-**wins**. We check the
   platform ban *before* consulting what the run is permitted, so no engagement can ever
   scope itself into deleting data. (SWE analogy: a global `DENY` ACL that's evaluated
   before any `ALLOW` rule.)
5. **Scope on resolved-IP *and* hostname** — checking the hostname alone lets a target
   re-point DNS mid-run to something out of scope (DNS-rebinding). We check what it
   *actually resolved to*, too.
6–8. **Zone → HITL → budget → rate** — the graded, per-run rules.
9. **Log-then-allow** — the decision is a durable fact before the caller can act on it.

---

## 7. The 60-second capability token (the subtle, important bit)

An *allow* doesn't just say "yes." It hands back a **signed token that's good for one
action and expires in 60 seconds.** The egress-gateway won't let the worker's traffic
out unless it presents a valid, unexpired token for exactly that action.

**Why bother?** It closes the window between *decision* and *deed*:

- **SWE analogy:** it's a **pre-signed URL** or a **short-lived scoped OAuth token**. You
  don't get standing access to the bucket; you get a signed link to do *one* thing that
  stops working in a minute.
- Even if the RoE is revoked or the run is killed a moment later, an in-flight token
  self-expires almost immediately — bounded, independently, at a second layer (the
  gateway), not just in governance's own memory.
- The token is **never a credential or a key** — it's permission to make *one* scoped
  call. The worst it can leak is a single, already-authorized action.

So there are **two independent gates** on every outbound action: governance said yes
(decision), *and* the gateway holds a live token (capability). Belt and suspenders.

---

## 8. What this service does NOT do

Being strict about scope is what keeps the wall auditable.

- **It does not run pentest logic.** It never picks a technique, never crafts a payload.
  It only says yes/no to actions the agent proposes.
- **It does not touch targets.** It has no egress path. It authorizes; the gateway acts.
- **It does not see raw payloads.** Only hashes and bounded types. Attacker bytes never
  reach it.
- **It does not write findings.** Only the **Validator** writes findings (refute-by-default).
  Governance authorizes *actions*, not *conclusions*.
- **It does not do content hygiene.** Prompt-injection filtering and output sanity are
  **Guardrails** — a separate, softer layer. A passed guardrail is not an authorization
  (DEC-G7).
- **It does not author or approve RoE.** It *verifies* a signed RoE; authoring/signing/
  versioning is the RoE lifecycle (L2). (These share data and a trust boundary, but the
  authoring UI is not this hot-path decision engine.)
- **It does not store per-decision state.** Each call is a fresh, self-contained
  evaluation. It *reads* durable state (budget counters, kill-switch flag, the signed
  RoE) but the decision itself is stateless and reproducible from its inputs.

---

## 9. Failure modes (all resolve to *deny*)

| Situation | Result | Layer |
|-----------|--------|-------|
| No `obo_subject` on the request | `DENY` | `obo` |
| RoE token bad signature / expired / superseded / scope-hash mismatch | `DENY` | `roe` |
| Run/engagement kill-switch tripped | `DENY` | `killswitch` |
| Action matches the destruction ban | `DENY` | `destruction` |
| Target host or resolved-IP out of the RoE allow-list | `DENY` | `scope` |
| Action class not permitted in this zone | `DENY` | `zone` |
| Action needs HITL and has no prior approval | `PAUSE_FOR_APPROVAL` | `zone` |
| Per-run budget exhausted | `DENY` | `budget` |
| Per-target rate limit hit | `DENY` | `rate` |
| **Audit log unwritable** (can't record the allow) | `DENY` | `audit` |
| Governance itself unreachable / times out | worker treats as `DENY` (fail-closed) | — |

The last two are the important ones: **when in doubt, or when broken, the answer is no.**

---

## 10. Where it sits (dependencies)

```
worker (untrusted plane)                 governance (trusted control plane)
  │                                         ▲
  │  authorize(action)                      │  reads:  signed RoE (L2)
  ▼                                         │          budget counters (Postgres)
GovernanceClient ──── Run Broker ───────────┘          kill-switch flag (Postgres)
 (the phone)          (the ONLY door)       │  writes: decision event → WORM (Cosmos) FIRST
                                            ▼
                            egress-gateway checks the 60s capability token
                                            │
                                            ▼
                                          target
```

- **Run Broker (L4):** the single inward door; the only network path from worker to
  governance. Every call is logged at this boundary too.
- **RoE / Case model (L2):** supplies the signed RoE the decision reads. *This is the
  main open dependency* — the RoE schema and signing lifecycle need to be pinned (A2 on
  the backlog).
- **Postgres (L6):** budget counters and the kill-switch flag.
- **Cosmos / WORM (L6):** the append-only audit log the decision is written to *before*
  it returns.
- **egress-gateway (L7):** the second gate — validates the capability token.

---

## 11. Open follow-ups

| # | Item | Note |
|---|------|------|
| OF-1 | **RoE schema + signing lifecycle** (with L2) | The decision is only as good as the RoE it reads. Pin the JWS format, the `scope_hash` supersession rule, and who signs. Blocks full build. |
| OF-2 | **Fine-grained action sub-classes** | Optional refinement of the 4 coarse classes into `read_only_recon / state_changing / privilege_escalation / lateral_movement / prod_confirm`. Only if the coarse set proves too blunt. |
| OF-3 | **Destruction registry contents** | The exact deny-list of destructive action signatures. Deny-wins, RoE-independent. Needs a first authored list + a change process. |
| OF-4 | **HITL approval channel** | Where the `PAUSE_FOR_APPROVAL` decision card surfaces and how the human's yes/no returns. Ties to the interactive-run design (L4.22). |
| OF-5 | **Budget model** | Per-run cost unit (token / time / action) and the reserve/release mechanics. Overlaps the cost rail (L8) and XBOW's per-call budgets (ADOPT-4). |
| OF-6 | **Sidecar decision cache** | Perf option: a read-only compiled RoE snapshot next to the worker for the hottest read-only checks, so not every action needs a central round-trip. Central service still owns every allow. Only if latency demands it. |
| OF-7 | **Kill-switch propagation** | How a trip reaches a *live* worker mid-action (not just DB-only). Ties to L8.6 on the backlog. |

---

## 12. One-paragraph summary (for the deck)

Governance is AEGIS's authorization wall: a small, deny-by-default service, living outside
the agent and reached through a single door, that answers one question before every action
— *allow*, *deny*, or *pause for a human*. It checks, in a fixed fail-closed order, that a
named human stands behind the run, that the run's signed scope is valid and current, that
the run hasn't been killed, that the action isn't on the platform-wide destruction ban,
that the target is in bounds, that the zone permits the action's danger class, that there's
budget and rate headroom — and it writes the decision to a tamper-evident log *before* it
answers. An *allow* is not a standing grant; it's a 60-second, single-action token the
egress-gateway independently checks. A compromised agent can ask this wall anything and, at
worst, get a wrong *no* — it can never manufacture a *yes*.
