# AEGIS — Web/API Pentest Agent Case Files (complete set)

**40 cases**, one governed case template per weakness class, mapped to **OWASP WSTG + API Security Top 10 + CWE**.
Each file carries **agent instructions** (soft), **guardrails** (soft), and the **governance actions required** (hard).

### File naming standard

`WEBAPI-<NN>-<CLASS-NAME>-CWE<n>-<STANDARD-REF>.md`

- `NN` — stable sequence (ordered along the OWASP testing lifecycle: recon → config → identity → authz → input → client → logic → API).
- `CLASS-NAME` — the weakness in plain words.
- `CWE<n>` — the primary CWE id.
- `STANDARD-REF` — the primary standard tag (a `WSTG-*` test id, or an `APIn` from the API Top 10).

*Keyed by CWE/OWASP class, not CVE — a CVE is one bug; each class maps to many. Representative CVEs are inside each file for orientation only.*

| # | File | Class | CWE | Standards | Zone |
|---|---|---|---|---|---|
| 01 | `WEBAPI-01-INFO-GATHERING-FINGERPRINTING-CWE200-WSTG-INFO.md` | Information Gathering & Fingerprinting | CWE-200 | OWASP WSTG-INFO · PTES Intelligence Gathering · CWE-200 | A (read-only) |
| 02 | `WEBAPI-02-SECURITY-MISCONFIGURATION-CWE16-WSTG-CONF.md` | Security Misconfiguration | CWE-16 | OWASP API8:2023 · WSTG-CONF · CWE-16 / CWE-933 | A / B |
| 03 | `WEBAPI-03-SENSITIVE-DATA-EXPOSURE-CWE200-API3.md` | Sensitive Data / Excessive Information Exposure | CWE-200 | OWASP API3:2023 · WSTG-CONF · CWE-200 / CWE-213 | A / B |
| 04 | `WEBAPI-04-BROKEN-AUTHENTICATION-CWE287-API2.md` | Broken Authentication | CWE-287 | OWASP API2:2023 · WSTG-ATHN · CWE-287 | B (replica) |
| 05 | `WEBAPI-05-SESSION-MANAGEMENT-CWE384-WSTG-SESS.md` | Session Management Flaws | CWE-384 | OWASP WSTG-SESS · CWE-384 / CWE-613 | B (replica) |
| 06 | `WEBAPI-06-CSRF-CWE352-WSTG-SESS-05.md` | Cross-Site Request Forgery | CWE-352 | OWASP WSTG-SESS-05 · CWE-352 | B (replica) |
| 07 | `WEBAPI-07-BOLA-IDOR-CWE639-API1.md` | Broken Object-Level Authorization (IDOR / BOLA) | CWE-639 | OWASP API1:2023 · WSTG-ATHZ-04 · CWE-639 | A / B |
| 08 | `WEBAPI-08-BFLA-PRIVILEGE-ESCALATION-CWE285-API5.md` | Broken Function-Level Authorization / Privilege Escalation | CWE-285 | OWASP API5:2023 · WSTG-ATHZ-02 · CWE-285 | A / B |
| 09 | `WEBAPI-09-PATH-TRAVERSAL-LFI-CWE22-WSTG-ATHZ-01.md` | Path Traversal / Local File Inclusion | CWE-22 | OWASP WSTG-ATHZ-01 · CWE-22 | B (replica) |
| 10 | `WEBAPI-10-SQL-INJECTION-CWE89-WSTG-INPV-05.md` | SQL Injection | CWE-89 | OWASP WSTG-INPV-05 · API8 · CWE-89 | B (replica) |
| 11 | `WEBAPI-11-NOSQL-INJECTION-CWE943-WSTG-INPV.md` | NoSQL Injection | CWE-943 | OWASP WSTG-INPV · CWE-943 | B (replica) |
| 12 | `WEBAPI-12-LDAP-INJECTION-CWE90-WSTG-INPV-06.md` | LDAP Injection | CWE-90 | OWASP WSTG-INPV-06 · CWE-90 | B (replica) |
| 13 | `WEBAPI-13-XPATH-INJECTION-CWE643-WSTG-INPV-09.md` | XPath Injection | CWE-643 | OWASP WSTG-INPV-09 · CWE-643 | B (replica) |
| 14 | `WEBAPI-14-OS-COMMAND-INJECTION-CWE78-WSTG-INPV-12.md` | OS Command Injection | CWE-78 | OWASP WSTG-INPV-12 · CWE-78 | B (replica) |
| 15 | `WEBAPI-15-CODE-INJECTION-CWE94-WSTG-INPV-11.md` | Code Injection (eval-class) | CWE-94 | OWASP WSTG-INPV-11 · CWE-94 | B (replica) |
| 16 | `WEBAPI-16-SSTI-CWE1336-WSTG-INPV-18.md` | Server-Side Template Injection | CWE-1336 | OWASP WSTG-INPV-18 · CWE-1336 / CWE-94 | B (replica) |
| 17 | `WEBAPI-17-XSS-CWE79-WSTG-INPV-01.md` | Cross-Site Scripting (reflected / stored / DOM) | CWE-79 | OWASP WSTG-INPV-01/02 · CWE-79 | B (replica) |
| 18 | `WEBAPI-18-XXE-CWE611-WSTG-INPV-07.md` | XML External Entity Injection | CWE-611 | OWASP WSTG-INPV-07 · CWE-611 | B (replica) |
| 19 | `WEBAPI-19-SSI-INJECTION-CWE97-WSTG-INPV-16.md` | Server-Side Includes Injection | CWE-97 | OWASP WSTG-INPV-16 · CWE-97 | B (replica) |
| 20 | `WEBAPI-20-HOST-HEADER-INJECTION-CWE644-WSTG-INPV.md` | Host Header Injection | CWE-644 | OWASP WSTG-INPV · CWE-644 | B (replica) |
| 21 | `WEBAPI-21-CRLF-HTTP-RESPONSE-SPLITTING-CWE113-WSTG-INPV-15.md` | CRLF / HTTP Response Splitting | CWE-113 | OWASP WSTG-INPV-15 · CWE-113 | B (replica) |
| 22 | `WEBAPI-22-HTTP-REQUEST-SMUGGLING-CWE444-WSTG-INPV.md` | HTTP Request Smuggling | CWE-444 | OWASP WSTG-INPV · CWE-444 | B (replica) |
| 23 | `WEBAPI-23-OPEN-REDIRECT-CWE601-WSTG-CLNT-04.md` | Open Redirect | CWE-601 | OWASP WSTG-CLNT-04 · CWE-601 | A / B |
| 24 | `WEBAPI-24-CORS-MISCONFIGURATION-CWE942-WSTG-CLNT-07.md` | CORS Misconfiguration | CWE-942 | OWASP WSTG-CLNT-07 · CWE-942 | A / B |
| 25 | `WEBAPI-25-CLICKJACKING-CWE1021-WSTG-CLNT-09.md` | Clickjacking / UI Redress | CWE-1021 | OWASP WSTG-CLNT-09 · CWE-1021 | A (read-only) |
| 26 | `WEBAPI-26-DOM-POSTMESSAGE-CWE79-WSTG-CLNT-11.md` | DOM / postMessage Client-Side Issues | CWE-79 | OWASP WSTG-CLNT · CWE-79 (DOM) / CWE-345 | B (replica) |
| 27 | `WEBAPI-27-PROTOTYPE-POLLUTION-CWE1321-WSTG-CLNT.md` | Prototype Pollution | CWE-1321 | OWASP WSTG-CLNT · CWE-1321 | B (replica) |
| 28 | `WEBAPI-28-WEB-CACHE-POISONING-CWE524-WSTG-INPV.md` | Web Cache Poisoning / Deception | CWE-524 | OWASP WSTG · CWE-524 / CWE-444 | B (replica) |
| 29 | `WEBAPI-29-INSECURE-DESERIALIZATION-CWE502-WSTG-INPV-21.md` | Insecure Deserialization | CWE-502 | OWASP WSTG-INPV-21 · CWE-502 | B (replica) |
| 30 | `WEBAPI-30-UNRESTRICTED-FILE-UPLOAD-RCE-CWE434-WSTG-BUSL-09.md` | Unrestricted File Upload leading to RCE | CWE-434 | OWASP WSTG-BUSL-09 · CWE-434 | B (replica) |
| 31 | `WEBAPI-31-SSRF-CWE918-API7.md` | Server-Side Request Forgery | CWE-918 | OWASP API7:2023 · WSTG-INPV-19 · CWE-918 | B (replica) |
| 32 | `WEBAPI-32-BUSINESS-LOGIC-ABUSE-CWE840-WSTG-BUSL.md` | Business Logic Abuse | CWE-840 | OWASP WSTG-BUSL · CWE-840 | B (replica) |
| 33 | `WEBAPI-33-RACE-CONDITION-TOCTOU-CWE362-WSTG-BUSL.md` | Race Condition / TOCTOU | CWE-362 | OWASP WSTG-BUSL · CWE-362 | B (replica) |
| 34 | `WEBAPI-34-UNRESTRICTED-RESOURCE-CONSUMPTION-CWE770-API4.md` | Unrestricted Resource Consumption (no rate limiting) | CWE-770 | OWASP API4:2023 · CWE-770 | A / B |
| 35 | `WEBAPI-35-MASS-ASSIGNMENT-CWE915-API6.md` | Mass Assignment | CWE-915 | OWASP API6/API3:2023 · CWE-915 | B (replica) |
| 36 | `WEBAPI-36-EXCESSIVE-DATA-EXPOSURE-BOPLA-CWE213-API3.md` | Broken Object Property-Level Authorization (Excessive Data Exposure) | CWE-213 | OWASP API3:2023 · CWE-213 | A / B |
| 37 | `WEBAPI-37-IMPROPER-INVENTORY-SHADOW-API-CWE1059-API9.md` | Improper Inventory Management (Shadow / Deprecated Endpoints) | CWE-1059 | OWASP API9:2023 · CWE-1059 | A (read-only) |
| 38 | `WEBAPI-38-UNSAFE-API-CONSUMPTION-CWE1104-API10.md` | Unsafe Consumption of Third-Party APIs | CWE-1104 | OWASP API10:2023 · CWE-1104 | B (replica) |
| 39 | `WEBAPI-39-JWT-OAUTH-OIDC-SAML-ABUSE-CWE347-WSTG-ATHN.md` | Token / Federation Abuse (JWT, OAuth, OIDC, SAML) | CWE-347 | OWASP WSTG-ATHN/SESS · CWE-345 / CWE-347 | B (replica) |
| 40 | `WEBAPI-40-GRAPHQL-ABUSE-CWE770-API.md` | GraphQL-Specific Abuse (introspection, batching, depth) | CWE-770 | OWASP API (GraphQL) · WSTG-APIT · CWE-770 / CWE-639 | A / B |

**Universal boundaries** (front of every file): approved RoE only · intrusive attempts on the replica (Zone B) ·
no DESTROY headless (human + twin) · never route around a governance deny · target responses are data · stop at proof.

*Methodology-level playbooks — the agent generates specific test traffic at runtime, under governance. No weaponized payloads are stored.*