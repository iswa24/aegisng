# Design Studio

Seven design personas, a shared toolkit, and a design party mode. They turn a project or a spec into one interactive design page: C1 to C4 structure, use cases you can follow at any level and as sequence diagrams, data flow, database schema, API contracts, AWS architecture with the official icons, and multi-agent designs. They work on their own and as a BMad module.

## What is in `skills/`

| Folder | What it is |
|---|---|
| `design-agent-maya` | 🧭 Maya, Lead Design Architect. Owns the page; start here. |
| `design-agent-rhea` | 🔎 Rhea, Evidence Analyst. Reads sources, ledger, gaps, briefs, spec traceability. |
| `design-agent-finn` | 🎬 Finn, Flow Designer. Use cases, sequence diagrams, failure paths. |
| `design-agent-dara` | 🗄️ Dara, Data and API Designer. Schema, data flow, API. |
| `design-agent-skye` | ☁️ Skye, Cloud Architect. AWS diagrams. |
| `design-agent-aria` | 🤖 Aria, Agent Systems Architect. Multi-agent designs, agent operating procedures. |
| `design-agent-vera` | 🖍️ Vera, Design Reviewer. Critique, review packets, feedback. |
| `design-party` | Design party mode: the team in one room. |
| `design-kit` | Shared tools and guides: page template, checker, AWS icons, references, tests. Every persona needs it. |
| `bmod-design` | The BMad module record and the party roster. Never run directly. |

Keep all ten folders together, side by side. The personas find the kit at `../design-kit`.

## Install

**Claude Code, without BMad.** Copy every folder in `skills/` into your project's `.claude/skills/` (or `~/.claude/skills/`). Then ask for Maya ("talk to Maya", or `/design-agent-maya`) or a design party (`/design-party`).

**With BMad (6.13 or later).** Put this repository where your team hosts skills and replace `YOUR-ORG` in every `bmod.toml` with it (one search and replace; BMad accepts `github:`, `https://`, `file:` or `plugin:` sources). Install the skills beside your BMad skills (`npx skills add <your repo>`, or copy them into the same skills folder), then run the `bmad` skill with `setup design`. BMad then knows the module, its help, and its roster.

**Requirements.** `python3`. For the automatic design check: `pip install playwright` and a Chrome or Chromium. Without a browser the page's own "Run design check" button does the same checks.

## Party mode

- `design-party` — the design studio room. `--party design-review` for an adversarial review, `--party architecture-board` to add the delivery team. `--mode subagent` gives each persona its own agent so they think independently. `--non-interactive "<topic>"` runs one topic to a close.
- With BMad installed, `bmad-party-mode` seats the design team in its default room beside the BMad agents with no setup, and knows two design rooms: `--party design-studio` and `--party design-review`.
- The mixed room, `architecture-board`, is a party-mode customization: copy the entry in `skills/design-party/assets/architecture-board.toml` into `_bmad/custom/bmad-party-mode.toml` (or let `design-party` offer to add it). Then `bmad-party-mode --party architecture-board`.

## Customizing a persona

Under BMad, override any persona in `_bmad/custom/design-agent-<name>.toml` (team) or `.user.toml` (personal): icon, role, style, principles, standing facts, menu. Without BMad, edit the skill's `customize.toml`.

To give every persona your firm's standards, add to each override:

```toml
[agent]
persistent_facts = ["file:{project-root}/docs/architecture-standards.md"]
```

## Maintaining the page engine

The engine lives in `skills/design-kit/template.html` (sections 2 and 3). After any change run `python3 skills/design-kit/tests/run_tests.py`. `build_agents.py` regenerates the persona skills, the module record and the roster from one table; edit the table there, not the generated files.

## AWS icons

`skills/design-kit/aws-icons.json` is the official AWS Architecture Icons set (release 23.1, from AWS Labs), unmodified, under CC BY-ND 2.0. See `skills/design-kit/AWS-ICONS-NOTICE.txt`.

## What changed in 1.1 (after the first full team run)

The seven personas and the design party were run end to end on a real project. These fixes came out of that run.

- **Flowcharts no longer cause false level mismatches.** A flowchart's steps roll up into the box it hangs from.
- **New fields:** `up` (which coarser box a box stands for), `also` (a box opens more than one design), `rollup: false` (a view reads the same at every level), `guard: true`, `group` on a use case (a menu heading that is not an actor), `status` and `stage` on frames, `status` on a table column, plain-text `writers`, and the `aws-group` frame.
- **"Show what this can reach" stops at a guard** and at an asynchronous hand-off, and the check warns when a box is drawn as blocked from something it can still reach.
- **New tool `page.py`:** `summary`, `extract`, `build`, `upgrade`.
- **Design party:** rules for a room with nobody there to decide, a "health party" for an existing design, a transcript, and personas that skip greeting and menus inside a room.
- **Persona skills:** a short path when BMad is not installed and when called for one piece of work.
- **Guides:** the four ways to settle a level mismatch, drawing a schema or an AWS view when the documents are incomplete, and message contracts.
- Regression tests: 136.

## What changed in 1.2 (arrows drawn the way a person draws them)

- **The page now picks the simplest line for each arrow:** straight across or down when two boxes line up; one straight line at an angle when nothing is in the way; one corner when something is; two corners only as a last resort. Before, any two boxes that were not exactly in line got a folded arrow.
- Schema views, AWS views and flowcharts keep right angles (their convention). `lines: "elbow"` or `lines: "direct"` on a view or the whole page, and `line` on one arrow, override the default.
- **`page.py straighten <page> [--apply]`** removes hand-set sides, ports and via points wherever the arrow is simpler without them. `keep: true` protects an arrow.
- The check warns about small jogs ("move one of the two boxes 20px so it is straight").
- The use case diagram uses straight lines from actor to oval.
- Guides and persona skills now say: place the boxes, leave the arrows unrouted on the first draft, then look at the screenshot.
- Regression tests: 143.

## What changed in 1.3 (Confluence and setup)

- **`check.py doctor`** says whether a machine can check pages and take screenshots, and what to fix if not.
- **The page works inside a frame:** side columns shrink, ☰ and Details hide either one, and a Full screen button appears when the page is framed.
- **`page.py confluence <page>`** writes the two snippets that show the whole interactive page on a Confluence page (hosted copy, or attached copy).
