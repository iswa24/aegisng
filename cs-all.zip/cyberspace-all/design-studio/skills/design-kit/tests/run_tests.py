#!/usr/bin/env python3
"""Regression tests for the design page engine (template.html).

Run after any change to the engine (sections 2 and 3 of template.html):
  python3 tests/run_tests.py [path/to/template.html]

Needs playwright and a Chrome/Chromium (set CHROME=/path if not found). Exit code 1 on any failure.
The tests use the worked example in template.html, so keep that example exercising every feature.
"""
import os, sys, shutil, pathlib
from playwright.sync_api import sync_playwright

PAGE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent.parent / "template.html").resolve()
fails, passed = [], 0
def ok(name, cond, detail=""):
    global passed
    if cond: passed += 1
    else: fails.append(f"{name} {detail}".strip())

def main():
    chrome = os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(viewport={"width": 1800, "height": 950}); errs = []
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(PAGE.as_uri()); ev = pg.evaluate; act = lambda a, i=None: ev("([a,i]) => act(a,i)", [a, i])
        views = ev("DIAGRAM.views.map(v=>v.id)"); flows = ev("DIAGRAM.flows.map(f=>[f.id,f.steps.length])")

        # the built-in design check finds nothing wrong with the example
        res = ev("MAYA_CHECK()"); ok("design check: no problems", not [r for r in res if r["level"] == "error"], str([r["msg"] for r in res if r["level"] == "error"][:3]))
        ok("design check: no warnings", not [r for r in res if r["level"] == "warn"], str([r["msg"] for r in res if r["level"] == "warn"][:3]))

        # every design draws; every use case walks to its end, on the map and as a sequence, at every level
        for v in views:
            act("view", v); ok(f"view {v} draws", ev("document.querySelectorAll('#svg .node').length") > 0)
        levels = ev("LEVELS")
        ok("levels C1..C4 present", levels == [1, 2, 3, 4], str(levels))
        for fid, n in flows:
            for lv in [""] + [str(l) for l in levels]:
                act("flow", fid); act("level", lv)
                m = ev("stepsOf(F(S.flow)).length")
                for _ in range(m - 1): act("next")
                ok(f"flow {fid} @ {lv or 'drawn'} walks", ev("S.step") == m - 1)
                act("seq", "1"); ok(f"flow {fid} @ {lv or 'drawn'} sequence draws", ev("document.querySelectorAll('#svg [data-step]').length") == m); act("seq", "0")
        act("level", ""); act("clear")

        # roll-up: a detailed use case gets shorter, and lands on the coarser design
        act("flow", "inside"); act("level", "2"); ok("roll-up to C2 lands on containers", ev("S.view") == "containers"); ok("roll-up to C2 merges steps", ev("stepsOf(F('inside')).length") < 8)
        act("level", "1"); ok("roll-up to C1 lands on context", ev("S.view") == "context"); act("level", ""); act("clear")

        # level switch navigates when no use case is selected
        act("view", "context")
        for lv, want in [("2", "containers"), ("3", "internals"), ("4", "schema"), ("1", "context")]:
            pg.click(f'#legend [data-act=level][data-id="{lv}"]'); ok(f"level switch to C{lv}", ev("S.view") == want, ev("S.view"))

        # drill-down, node click, arrow click
        act("view", "containers"); pg.click("[data-node=pay]"); ok("box click selects", ev("S.node") == "pay")
        pg.wait_for_timeout(60); pg.click("[data-node=pay]"); ok("double-click drills down", ev("S.view") == "internals")
        act("view", "containers"); pg.click('g.ehit[data-edge="gw>pay"]'); ok("arrow click selects", ev("S.edge") == "gw>pay"); ok("arrow shows its API call", pg.locator("details.ep[open]").count() == 1)

        # API, schema, agents, AWS, data flow
        pg.click("[data-node=pay]"); ok("service shows API list", pg.locator("#panel details.ep").count() == 3)
        act("clear"); pg.click("[data-act=apis]"); ok("API catalogue opens", "API catalogue" in pg.inner_text("#panel") or "API CATALOGUE" in pg.inner_text("#panel"))
        act("view", "schema"); pg.click("[data-node=payment]"); t = pg.inner_text("#panel"); ok("table shows columns and writer", "idempotency_key" in t and "Ledger repository" in t)
        act("view", "agents"); pg.click("[data-node=fraud]"); pg.click("[data-act=reach]"); t = pg.inner_text("#panel"); ok("reach lists reachable and blocked", "Ledger lookup tool" in t and "Card data tool" in t)
        act("view", "aws"); ok("AWS icons are embedded", ev("document.querySelectorAll('#svg svg').length") >= 11); ok("AWS frames drawn", ev("V('aws').groups.length") == 12)
        act("view", "containers"); act("mode", "data"); ok("data flow mode", ev("modeOf(V('containers'))") == "data"); act("mode", "structure")
        act("view", "_usecases"); ok("use case diagram generated", ev("document.querySelectorAll('#svg ellipse').length") == len(flows)); pg.click("[data-node=uc_pay]"); ok("oval opens its use case", ev("S.flow") == "pay")

        # open items, lenses, search, design check panel, deep link
        act("clear"); act("view", "containers"); pg.click("[data-act=item][data-id=c1]"); ok("item opens with positions", "Runbook" in pg.inner_text("#panel"))
        pg.click("[data-act=itemview][data-id=timeout]"); ok("item jumps across designs", ev("S.view") == "timeout" and ev("S.item") == "c1")
        act("clear"); act("view", "containers"); act("lens", "gaps"); ok("lens highlights", ev("document.querySelectorAll('#svg .node.on').length") > 0); act("clear")
        pg.fill("#q", "refund"); ok("search finds boxes, use cases, endpoints", pg.locator("#results div").count() >= 3)
        pg.click("[data-act=check]"); ok("design check panel", "Design check" in pg.inner_text("#panel") or "DESIGN CHECK" in pg.inner_text("#panel"))
        pg.goto(PAGE.as_uri() + "#containers/flow/pay/3/seq/c2"); pg.reload(); ok("deep link restores use case, step, sequence, level", ev("[S.flow,S.step,S.seq,S.level].join()") == "pay,3,true,2")
        r = ev("(r => ({can: r.can, beyond: r.beyond, both: r.both}))(reachOf(V('agents'), 'orch'))")
        ok("reach stops at a guard", "limit" in r["can"] and "gw" not in r["can"] and "gw" in r["beyond"] and "lead" in r["beyond"], str(r))
        ok("menu headings are not drawn as actors", ev("!V('_usecases').nodes.some(n => n.label === 'Failure paths')") and "Failure paths" in pg.inner_text("#nav"))
        ok("a flowchart rolls up into its box, with no false mismatch", ev("rolled(F('cardslow'), 2).every(k => !k.missing) && rolled(F('cardslow'), 1).every(k => !k.missing)"))
        ok("`up` names the coarser box", ev("(() => { const v = V('aws'), n = v.nodes[0], was = n.up; n.up = 'gw'; const got = mapUp(v, n.id, upOf(v)); n.up = was; return got; })()") == "gw")
        ok("`rollup: false` keeps a view's steps at every level", ev("(() => { const v = V('aws'); v.rollup = false; for (const k in rollCache) delete rollCache[k]; const same = rolled(F('awspath'), 1).length === F('awspath').steps.length; delete v.rollup; for (const k in rollCache) delete rollCache[k]; return same; })()"))
        ok("a frame shows its status", "UNKNOWN?" in ev("groupTitle({ kind: 'boundary', label: 'x', status: 'unknown', x: 0, y: 0, w: 100, h: 100 }).txt") and "proposed" in ev("groupTitle({ kind: 'vpc', label: 'x', stage: 'proposed', x: 0, y: 0, w: 100, h: 100 }).txt"))
        ev("set({ view: 'schema', node: 'outbox' })"); ok("a writer no view draws is listed as text", "not drawn" in pg.inner_text("#panel").lower())
        ok("`also` opens a second design and counts as a drill-down", ev("(() => { const n = V('context').nodes.find(k => k.child); n.also = ['aws']; set({ view: 'context', node: n.id }); const has = document.querySelector('#panel').innerText.includes('Also open'); delete n.also; return has; })()"))
        r = ev("(() => { const L = layout(V('context'), 'structure'); return L.E.map(x => [x.pts.length, !!x.direct]); })()")
        ok("five boxes: every arrow is one straight line", all(n == 2 for n, _ in r), str(r))
        r = ev("(() => { const v = V('containers'), L = layout(v, 'structure'); return [L.E.filter(x => x.pts.length === 2).length, L.E.length]; })()")
        ok("boxes in a row or column are joined by straight arrows", r[0] >= r[1] - 2, str(r))
        ok("schema, AWS and flowchart views keep right angles", ev("['schema','aws','timeout'].every(id => layout(V(id), 'structure').E.every(x => !x.direct))"))
        ok("`lines: 'elbow'` on a view turns angled lines off", ev("(() => { const v = V('context'); v.lines = 'elbow'; const none = layout(v, 'structure').E.every(x => !x.direct); delete v.lines; return none; })()"))
        ok("an angled line never passes through a box", ev("DIAGRAM.views.filter(v => !v.auto).every(v => { const L = layout(v, 'structure'); return L.E.filter(x => x.direct).every(x => !v.nodes.some(n => n !== x.a && n !== x.b && n.type !== 'note' && segHit(x.pts[0], x.pts[1], n, 0))); })"))
        ok("use case diagram: straight lines from actor to oval", ev("layout(V('_usecases'), 'structure').E.every(x => x.pts.length === 2)"))
        ok("straighten finds nothing to undo in the sample", ev("MAYA_RELAX().length") == 0)
        ok("no page errors", not errs, str(errs[:3]))
        b.close()
    print(f"{passed} passed, {len(fails)} failed")
    for f in fails: print("  FAIL", f)
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
