# Structure: views, levels, diagram types

Read `core.md` first. This is Maya's main reference.

### Choose the views

Build a hierarchy the reader can drill through, plus flow views:

- **C0 Whole picture** (only when the project has several systems): each system as one box, the people who use them, and the things they share. Each system box drills into its own hierarchy.
- **C1 System context:** one system as a box, its personas, its external systems.
- **C2 Containers:** deployable parts, stores, queues, boundaries.
- **C3 Components:** inside one container, only where the detail matters.
- **C4 Code:** the most detailed level, where it earns its place: a database schema, the classes or modules of one component, an API's shape. Most boxes never need one.

Set each of these views' `level` to exactly `"C0"`, `"C1"`, `"C2"`, `"C3"` or `"C4"`. The page uses it for the level switch and for showing a use case at any level (see `levels.md`). Other views carry a descriptive level such as `"Flow"`, `"AWS"`, `"Agents"` and count as one step more detailed than their parent.
- **Flow views:** a failure path, a decision flow, a lifecycle. Child of the view they relate to. Set `level: "Flow"`. Hang it from the one box it explains (`child` on that box); its boxes are states and decisions, not components (`levels.md`).
- **Cross-cutting views** (level `Cross`): one concern across all systems, for example "everywhere a model is called" or "everywhere data crosses a boundary". Use these when Phase 2 found a rule with exceptions.
- **Alternative or vision views** (level `Option`): a proposed alternative or a future state, clearly named as such.

Link parent to child with `child: "<view id>"` on the box and `parent: "<view id>"` on the child view. Every view except the first should be reachable by drilling into a box.

**Size limits that keep text readable:** at most about 5 columns of boxes and 16 boxes per view. Width is the binding limit, not box count. When a view outgrows it, push detail into a child design or collapse repeats into one box ("A source" for eleven similar sources) and keep the detail in that box's evidence.

### Diagram types you can produce on request

When someone asks for a specific kind of diagram, this is what you deliver. Three of them the page draws for you from data you already keep, so they can never drift out of step with the design.

| Asked for | What you do | Where the reader finds it |
|---|---|---|
| **Architecture / C4** (context, container, component, code) | Draw views at C1 to C4 (C0 above them for several systems), linked by drill-down | "Designs" menu, or the C1 · C2 · C3 · C4 switch under the canvas |
| **Use case diagram** (who uses the system for what) | Nothing extra: define the use cases (flows) with the right `actor`. The page draws actors, ovals and the system boundary. | "Use case diagram" at the top of the "Use cases" menu; each oval opens its use case |
| **Sequence diagram** (who calls whom, in time order) | Nothing extra: every use case has one. Make it a good one by adding `reply`, `when` and self-steps (below). | Open a use case, press "Sequence diagram" |
| **Data flow diagram** (what data moves where) | Put `data` on the arrows of a view (and `sensitive: true` where it applies). For a diagram that is only about data, add a view with `kind: "dataflow"`. | "Structure / Data flow" switch under the canvas; lens "Sensitive data" |
| **Database schema** (tables, columns, keys, relationships) | A view with `kind: "schema"` made of `table` boxes and relationship lines. Link it from the database box with `child`. | Drill into the database box; click a table for its columns and who writes it |
| **API design** (endpoints, requests, responses, errors) | Put an `api` list on the service box. Put `api: "POST /pay"` on each arrow that calls an endpoint. | Click the service; "API catalogue" button; click an arrow to see the endpoint it calls; the sequence diagram shows the endpoint on each call |
| **Multi-agent orchestration** | A view using `agent`, `tool` and `model` boxes, arrow `kind`s, and `parallel` / `loop` frames. Use cases over it give the run order. | "Designs" menu; "Show what this can reach" on any box |
| **AWS architecture diagram** | A view of `aws` boxes with official icons inside nested AWS frames (cloud, account, Region, VPC, Availability Zone, subnet). Embed the icons with `aws_icons.py`. | "Designs" menu; drill in from the box it deploys |
| **Flowchart / decision flow** | A flow view using `decision` diamonds | "Designs" menu |
| **Failure or containment path** | A flow view plus a use case under "Failure paths"; `blocked` arrows for what cannot happen | Both menus |

If asked for a kind the page has no notation for (class diagram, state machine, Gantt), say so plainly. Offer the closest honest form using boxes and arrows, or keep it as a table in the box's evidence. Do not fake a notation.

### Nuance checklist

For each item: show it, note it, or decide it does not apply.

- **Boundaries:** trust zones, accounts, networks, regions, team ownership, what is external.
- **Communication:** sync vs async for every arrow; protocol; who initiates; timeouts; what is blocked.
- **Data:** one owner per store; system of record; caches and staleness; data classification.
- **Failure:** timeouts, retries and backoff, idempotency, dead-letter queues, circuit breakers, fallbacks.
- **Consistency:** where a transaction ends; where eventual consistency begins; ordering and duplicates.
- **Scale:** hot path, bottleneck, fan-out, volumes, cost per unit of work.
- **Security:** where authentication and authorization happen; secrets; encryption; audit trail; kill switch.
- **Operations:** logs, metrics, traces, deployment, rollback, recovery targets, who runs it.
- **State:** what is stateless; where session or workflow state lives.
- **Human steps:** approvals, manual review, support tooling.
