# Flows: use cases, sequence diagrams, flowcharts

Read `core.md` first, then `levels.md`. This is Finn's main reference.

### Choose the use cases (flows)

A flow is an ordered list of arrows that tells one story. Clicking it lights up just that path and numbers the steps. Always consider:

- One happy path **per persona**. A persona on a top-level view counts as covered if a flow passes through them in any view.
- One per **external input**: webhook, file drop, scheduled job, event from another system.
- The **failure and containment paths** that matter: timeout, duplicate, poison message, partial failure, kill switch, refused request.
- **Operations:** support or admin actions, reprocessing, manual review, approvals.
- **Data lifecycle:** where a sensitive record is created, copied and deleted.
- A **guided tour** when the project is large: a short flow across the top view that introduces each system.

If a persona is implied but no design for them exists, draw the box, mark it `unknown`, and open a question; do not invent a flow.

A flow may cross views. Give every step a one-line note in plain words. A flow step lands on an arrow, so a "refused" ending needs an arrow into a box such as "Refuse the request".

**Making sequence diagrams good.** A sequence diagram is drawn from the use case's steps, in order, one lifeline per box. Optional fields on a step:

- `reply: "token valid"` — draws the return arrow. Use it on synchronous calls where the answer matters.
- `when: "only if no reply in 2s"` — a condition shown above the step. Use it for branches; for a long alternative path, make a separate use case.
- A self-step, for work a box does on its own: `{ view, at: "<boxId>", label: "check idempotency key", note }` in place of `edge`.

Keep one use case to about 12 steps and 8 participants; split longer stories. A use case may walk a flowchart view (decision diamonds); it reads better as a map than as a sequence, and at coarser levels the whole walk becomes one "work inside this box" step (`levels.md`). So a story that crosses components is told on the container or component view, with the flowchart as the detail of one box, not the other way round. Use the same box id for the same component in every view, so it is one lifeline when a use case crosses designs.

**Making use case diagrams good.** Name use cases as goals from the actor's side ("Refund a payment", not "POST /refund"). `actor` is the person or outside system that starts it, and nothing else; use `actors: ["A", "B"]` when two take part. To put use cases under a menu heading that is not an actor ("Failure paths", "Data lifecycle", "Scheduled jobs"), set `group: "Failure paths"`; keep the real `actor` too if there is one. A heading used as `actor` is drawn on the use case diagram as if it were a party to the system.

**Making flowcharts and failure paths good.** A flow view is a small design of its own, child of the view it explains, with `decision` diamonds for each choice. Label every way out of a diamond ("yes", "no", "over limit"). Fan the exits from different sides. Give each failure path a use case with `group: "Failure paths"`, so it has a sequence diagram too. For each one say: what detects the failure, what the system does without a person, when a person is told, and what state things are left in. Use `blocked` arrows for what must not happen even in failure.

**Finding the use cases.** Walk the design once per persona and once per external input, asking "what do they start, and where does it end?" Then walk it once per dependency asking "what happens when this is slow, down, or wrong?" Each answer is a use case or an open question. A persona with no use case, and a box no use case passes through, are both worth a question.
