# The DIAGRAM data: every field

Read `core.md` first. The worked example is section 1 of `template.html`.

### Data schema

```
DIAGRAM = {
  title, version,
  defaultStage?,                                 // proposed | decided | built
  views: [{
    id, name, level?, parent?, question, defaultStage?, kind?, rollup?, lines?,
    groups: [{ label, x, y, w, h, kind?, labelPos?, status?, stage? }],
    nodes:  [{ id, type, cat, x, y, w?, h?, label, sub?, child?, also?, up?, guard?,
               status?, stage?, changed?, tags?, details?, facts?,
               icon?,                                 // "aws:<key>" from aws_icons.py; type "aws" shows it as a tile
               api?,                                  // service: [{ method, path, summary, auth?, idempotency?, limits?, request?, response?, errors?, notes? }]
               columns?, writers?, readers?,          // table:   columns [{ name, type?, key?, note?, ref?, nullable?, status? }]
               lead?, sees?, blind? }],               // agent
    edges:  [{ from, to, label?, style?, kind?, api?, rel?, fromCol?, toCol?, data?, sensitive?,
               status?, stage?, changed?, tags?, details?, facts?,
               fromSide?, toSide?, fromPort?, toPort?, via?, labelAt?, line?, keep?, id? }]
  }],
  flows:  [{ id, name, actor?, actors?, group?, description,
             steps: [{ view, edge: "fromId>toId", note, reply?, when? }      // a call or message
                   | { view, at: "boxId", label, note, when? }] }],          // something a box does itself
  lenses: [{ id, name, tag }],
  items:  [{ id, kind, status, owner, text, refs: ["viewId/nodeId", ...],
             positions?: [{ who, says, source }], drawn?, decider?, answer?, brief?, ledger?: ["E12"] }],
  missing: [{ name, citedBy }],
  changes: [{ version, date, text }],
  notes:  { "Assumptions": [...], "Key decisions": [...] }
}
```

- `status`: confirmed (default) | assumed | unknown. `stage`: proposed | decided | built | disputed | deferred | superseded.
- Box `type`: service | db | queue | external | actor | decision | note | table | agent | tool | model | aws. Box `cat`: client | edge | service | data | messaging | external | agent | tool | model | guard | note.
- `style`: omitted (synchronous) | `async` | `blocked` | `rel` (a table relationship, no arrowhead).
- `kind` (agent designs): `handoff` | `tool` | `model` | `memory`.
- Group `kind`: `boundary` | `parallel` | `loop`, or an AWS frame: `aws-cloud` | `aws-account` | `region` | `vpc` | `az` | `public-subnet` | `private-subnet` | `security-group` | `asg` | `aws-group` | `datacenter`. Frames may nest and may carry `status` and `stage`.
- The block between `AWS-ICONS:BEGIN` and `AWS-ICONS:END` in section 1 holds the embedded icons. Never edit it by hand; `aws_icons.py embed` writes it.
- A view with `kind: "schema"` holds tables.
- `data`: what moves along the arrow, for the data flow view. `sensitive: true` marks restricted data.
- A view with `kind: "dataflow"` opens in data flow mode.
- The use case diagram is generated; set `useCaseDiagram: false` on `DIAGRAM` only if the project has no meaningful actors.
- `details`: an object of label/value pairs. `facts`: `[{ text, source, ledger? }]`.
- An item's `refs` name boxes as `viewId/nodeId`, or arrows as `viewId/fromId>toId`, and can span several designs. Clicking the item lets the reader jump between them. When the item is open on a design where it has no ref, the page moves to the first design it names.
- A flow step's `edge` is `fromId>toId`, or the arrow's `id` if you gave it one.
- `fromPort` / `toPort`: pixels from the centre of that side, only if you need to override the automatic spreading.
- Use `\n` in a label only when you want to force a line break; otherwise let the page wrap.
- Labels on the page should not carry person names or firm-internal identifiers unless the owner wants them there.

- Item `kind` is `question` | `risk` | `conflict`, or `requirement` for a requirement the design does not yet cover (see `discover.md`). Item `status` is `open` | `answered`, or for requirements `uncovered` | `partial` | `covered`.

- `also`: more designs a box opens, besides `child`. `up`: the id of the box one level up that this box stands for, when the names differ. `rollup: false` on a view: its use cases are shown as drawn at every level. `guard: true` on a box: "what this can reach" stops there. All four are explained in `levels.md` and `agents.md`.
- A flow's `actor` is a real person or outside system; `group` is only a menu heading.
- `writers` / `readers` entries are `"viewId/boxId"`, or plain text for a part no view draws.
- `lines` (on `DIAGRAM` or a view) and `line` (on one arrow): `"direct"` lets an arrow be one straight line at an angle; `"elbow"` keeps right angles. Default: direct, except schema views, AWS views and flowcharts. `keep: true` on an arrow protects its hand-set route from `page.py straighten`. See "Layout rules" in `page.md`.
