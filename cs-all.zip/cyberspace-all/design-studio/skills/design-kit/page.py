#!/usr/bin/env python3
"""Work with a design page without opening it by hand.

  python3 page.py summary <page.html>              what is on the page: designs, use cases, open items, last change
  python3 page.py extract <page.html> <data.js>    write the page's data (section 1, the DIAGRAM block) to a file
  python3 page.py build   <data.js> <page.html>    make a page from a data file and this kit's template
  python3 page.py upgrade <page.html>              keep the page's data, replace its engine with this kit's template
  python3 page.py straighten <page.html> [--apply] find arrows whose hand-set sides, ports or via points make them bend more than
                                                   they need to; with --apply, drop those hints and save (the data is rewritten
                                                   as JSON, so comments inside the data block are lost; the icons are kept)

  python3 page.py confluence <page.html>           write the two snippets that show the whole interactive page inside a
                                                   Confluence page (one for a hosted copy, one for an attached copy)

`summary` and `straighten` need playwright and a Chrome/Chromium (same as check.py). The others need nothing.
"""
import os, re, sys, json, shutil, pathlib

A, B = "/* ============ 1. DIAGRAM DATA", "/* ============ 2. VISUAL LANGUAGE"
KIT = pathlib.Path(__file__).resolve().parent

def split(text, name):
    if A not in text or B not in text: sys.exit(f"{name}: not a design page (section markers not found)")
    a, b = text.index(A), text.index(B)
    return text[:a], text[a:b], text[b:]

def extract(page, out):
    _, data, _ = split(pathlib.Path(page).read_text(encoding="utf-8"), page)
    pathlib.Path(out).write_text(data, encoding="utf-8"); print(f"wrote {out} ({len(data):,} characters)")

def build(data_file, out, title=None):
    data = pathlib.Path(data_file).read_text(encoding="utf-8")
    if not data.lstrip().startswith(A): sys.exit(f"{data_file}: must start with the section 1 marker line, as written by `extract`")
    head, _, engine = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")
    if title is None:
        m = re.search(r'"?title"?:\s*"((?:[^"\\]|\\.)*)"', data); title = (m.group(1) if m else "System design") + " — system design"
    head = re.sub(r"<title>.*?</title>", lambda _: "<title>" + title + "</title>", head, count=1, flags=re.S)
    pathlib.Path(out).write_text(head + data + engine, encoding="utf-8"); print(f"wrote {out}")

def upgrade(page):
    text = pathlib.Path(page).read_text(encoding="utf-8"); _, data, old = split(text, page)
    _, _, engine = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")
    khead = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")[0]; strip = lambda h: re.sub(r"<title>.*?</title>", "", h, flags=re.S)
    if old == engine and strip(text[:text.index(A)]) == strip(khead): print("already on this kit's engine"); return
    t = re.search(r"<title>(.*?)</title>", text, flags=re.S)
    tmp = pathlib.Path(page).with_suffix(".data.tmp.js"); tmp.write_text(data, encoding="utf-8")
    build(tmp, page, t.group(1) if t else None); tmp.unlink(); print("engine replaced; data untouched. Now run check.py")

def summary(page):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        d = pg.evaluate("""() => ({ title: DIAGRAM.title, version: DIAGRAM.version, defaultStage: DIAGRAM.defaultStage || null,
          views: DIAGRAM.views.filter(v => !v.auto).map(v => ({ id: v.id, name: v.name, level: v.level || "", parent: v.parent || "", boxes: v.nodes.length, arrows: v.edges.length,
            frames: v.groups.length, gaps: [...v.nodes, ...v.edges].filter(x => x.status === "assumed" || x.status === "unknown").length,
            open: DIAGRAM.items.filter(it => !["answered","covered","closed"].includes(it.status) && [it.view, ...it.where.map(w => w.view)].includes(v.id)).length })),
          flows: DIAGRAM.flows.map(f => ({ id: f.id, name: f.name, who: f.actor || (f.actors || []).join(", ") || "", group: f.group || "", steps: f.steps.length, views: [...new Set(f.steps.map(s => s.view))] })),
          items: DIAGRAM.items.map(it => ({ id: it.id, kind: it.kind, status: it.status, owner: it.owner || "", text: it.text })),
          changes: (DIAGRAM.changes || []).slice(0, 3), check: MAYA_CHECK().reduce((a, r) => (a[r.level] = (a[r.level] || 0) + 1, a), {}) })""")
        b.close()
    if "--json" in sys.argv: print(json.dumps(d, indent=1)); return
    print(f"{d['title']}   {d['version']}   (unmarked parts are: {d['defaultStage'] or 'not stated'})")
    print(f"\nDESIGNS ({len(d['views'])})   id · level · boxes/arrows · assumed-or-unknown · open items")
    by = {v["id"]: v for v in d["views"]}
    for v in d["views"]:
        n, cur, seen = 0, v, set()
        while cur["parent"] in by and cur["id"] not in seen: seen.add(cur["id"]); cur = by[cur["parent"]]; n += 1
        print(f"  {'  ' * n}{v['name']}  [{v['id']} · {v['level'] or '-'} · {v['boxes']}/{v['arrows']} · {v['gaps']} · {v['open']}]")
    print(f"\nUSE CASES ({len(d['flows'])})")
    for f in d["flows"]: print(f"  {f['name']}  [{f['id']} · {f['steps']} steps · {f['who'] or 'no actor'}{' · ' + f['group'] if f['group'] else ''} · on: {', '.join(f['views'])}]")
    kinds = {}
    for it in d["items"]: kinds.setdefault(it["kind"], []).append(it)
    openn = [it for it in d["items"] if it["status"] not in ("answered", "covered", "closed")]
    print(f"\nITEMS ({len(d['items'])}, {len(openn)} still open)   " + "   ".join(f"{k}: {len(v)}" for k, v in kinds.items()))
    if "--items" in sys.argv:
        for it in d["items"]: print(f"  {it['id']:<6} {it['kind']:<11} {it['status']:<9} {it['owner'][:28]:<28} {it['text'][:110]}")
    else: print("  (add --items to list them, --json for everything)")
    print("\nLAST CHANGES")
    for c in d["changes"]: print(f"  {c.get('version', '')} {c.get('date', '')}  {c.get('text', '')[:160]}")
    print(f"\nDESIGN CHECK   problems: {d['check'].get('error', 0)}   warnings: {d['check'].get('warn', 0)}   (run check.py for the list and screenshots)")

def straighten(page, apply):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        if not pg.evaluate("typeof MAYA_RELAX === 'function'"): sys.exit("This page is on an older engine. Run: python3 page.py upgrade " + page)
        done = pg.evaluate("MAYA_RELAX()"); data = pg.evaluate("MAYA_DATA()"); b.close()
    if not done: print("Nothing to straighten: no hand-set hint is making an arrow bend more than it needs to."); return
    for d in done: print(f"  [{d['view']}] {d['arrow']}: without {', '.join(d['dropped'])} it has {d['saved']} fewer corner(s)")
    print(f"{len(done)} arrow(s), {sum(d['saved'] for d in done)} corner(s) fewer.")
    if not apply: print("Nothing saved. Add --apply to save, or remove those fields yourself."); return
    text = pathlib.Path(page).read_text(encoding="utf-8"); head, blk, engine = split(text, page)
    i = blk.index("const DIAGRAM = "); j = blk.find("/* AWS-ICONS:BEGIN")
    blk = blk[:i] + "const DIAGRAM = " + data + ";\n\n" + (blk[j:] if j >= 0 else "")
    pathlib.Path(page).write_text(head + blk + engine, encoding="utf-8"); print(f"saved {page}. Now run check.py and look at the screenshots.")

FRAME = 'allowfullscreen style="width:100%;height:85vh;min-height:720px;border:1px solid #dfe1e6;border-radius:6px"'
def confluence(page):
    p = pathlib.Path(page); name = p.name; stem = p.with_suffix("")
    hosted = f"""<!-- Paste into an HTML macro (or use the iframe macro with the same address).
     Replace the address with where {name} is hosted inside your firm.
     Add #<view id> to the address to open on one design, for example .../{name}#scan -->
<iframe src="https://YOUR-INTERNAL-HOST/path/{name}" {FRAME}></iframe>
"""
    attached = f"""<!-- 1. Attach {name} to this Confluence page.  2. Paste all of this into an HTML macro on the same page.
     To publish a new version later, attach the new file under the same name. Nothing else changes. -->
<iframe id="design-frame" {FRAME}></iframe>
<script>
(function () {{
  var file = "{name}";
  var meta = document.querySelector('meta[name="ajs-page-id"]');
  var pageId = (window.AJS && AJS.params && AJS.params.pageId) || (meta && meta.content);
  var base = (window.AJS && AJS.contextPath && AJS.contextPath()) || "";
  var frame = document.getElementById("design-frame");
  fetch(base + "/download/attachments/" + pageId + "/" + encodeURIComponent(file), {{ credentials: "same-origin" }})
    .then(function (r) {{ if (!r.ok) throw new Error("status " + r.status); return r.text(); }})
    .then(function (t) {{ frame.srcdoc = t; }})
    .catch(function (e) {{ frame.outerHTML = "<p>Could not load the design (" + e.message + "). Is " + file + " attached to this page?</p>"; }});
}})();
</script>
"""
    a = pathlib.Path(str(stem) + ".confluence-hosted.html"); b = pathlib.Path(str(stem) + ".confluence-attached.html")
    a.write_text(hosted, encoding="utf-8"); b.write_text(attached, encoding="utf-8")
    print(f"""wrote {a.name} and {b.name}

Confluence does not run an HTML file as a page, so the design is shown in a frame inside a Confluence page.
Which way works depends on what your Confluence allows:

  A. The file is hosted on an internal web address, and Confluence has an HTML or iframe macro
     -> paste {a.name}. Links to one design or use case work (the address ends in #...).
  B. No hosting, but the HTML macro is enabled
     -> attach {name} to the page and paste {b.name}. Everything works except links to one design.
  C. Neither macro is available
     -> the interactive page cannot be shown inside Confluence. Attach {name} so people can download and open it,
        and put screenshots on the page (python3 check.py {name} shots).

To find out: edit any Confluence page, type {{html and {{iframe, and see which macros are offered.""")

def main():
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == "summary": summary(a[1])
    elif len(a) == 3 and a[0] == "extract": extract(a[1], a[2])
    elif len(a) == 3 and a[0] == "build": build(a[1], a[2])
    elif len(a) == 2 and a[0] == "upgrade": upgrade(a[1])
    elif len(a) >= 2 and a[0] == "straighten": straighten(a[1], "--apply" in a)
    elif len(a) == 2 and a[0] == "confluence": confluence(a[1])
    else: sys.exit(__doc__)

if __name__ == "__main__":
    main()
