# Cyberspace: everything in one place

24 November 2026. Nothing in here is a decision: the design is proposed and waits for the owner.

## Start here

Open `design/cyberspace-design-v4.html` in a browser. It is one file and needs nothing else. It opens on the proposed platform landscape.

## What is in each folder

| Folder | What it holds |
|---|---|
| `design/` | The interactive design page (version 4) and the files behind it: evidence ledger, open items, requirements, change log, party notes, the two reviews, and the research briefs. |
| `party/` | The design party. `party-record.md` is the whole argument in one file. The separate rounds are beside it: the brief, five positions, the lead's draft and nine conflicts, five answers, the outcome. |
| `screenshots/` | Pictures of the three new designs: the landscape, what must not cross between zones, and a change's path. |
| `confluence/` | Two snippets for showing the page inside a Confluence page: one for an attached copy, one for a hosted copy. Both name `cyberspace-design-v4.html`. |
| `design-studio/` | The skills package: seven design personas, the design party, and the shared design kit. See its own `README.md`. |

## Three things to know

- The architects worked from the 195 facts already taken from the project documents; they could not open the documents themselves.
- The Confluence snippets were tested in a stand-in page, not in a real Confluence.
- In `design-studio/`, each skill's source still says `YOUR-ORG`; replace it with where the package will be hosted.
