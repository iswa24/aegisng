# AEGIS Arc — Lucid diagram set (canonical order)

One Lucid doc. Use frames/pages titled 1..10. For each: Insert -> Mermaid -> paste the .mmd.
Draw most-zoomed-out to most-zoomed-in (C4), then the 4+1 supporting views, then the planning boards.

## Order (first -> last)
1. `aegis-context.mmd`      — System Context (C4 L1): who/what touches the sandbox
2. `aegis-container.mmd`    — Container (C4 L2): deployable units + tech + protocols
3. `aegis-component.mmd`    — Component (C4 L3): internal components of the sandbox
4. `aegis-sequence.mmd`     — Sequence (dynamic): one headless run end-to-end
5. `aegis-flow.mmd`         — Flow: triggers -> run -> escalation -> result -> authoring loop
6. `aegis-deployment.mmd`   — Deployment (physical): AWS account / VPC / subnets / multi-AZ
7. `aegis-dataflow.mmd`     — Data-flow: ephemeral vs durable vs pointer-only (WORM)
8. `aegis-identity.mmd`     — Identity: SID (person) -> FID (workload), attribution preserved
9. `aegis-action-items.mmd` — MD-session action items (grouped, owners, status)
10.`aegis-roadmap-board.mmd`— Open Questions | POC | Near-term | Long-term

Architecture (1-8) on one side of the canvas; planning boards (9-10) on the other.
SVG previews for every diagram are included.

## Audience guide
Execs -> 1-2. Engineers -> 3-6. Security/reviewers -> 4, 7, 8. Delivery leads -> 9-10.

## Confirm internal terms before circulating
G3S/G34/G35, galaxy, udocker, V7 harness, SmartSDK/SmartTask, VDI, SJAR, and VM Ops terms
(JVE, VINES, Mobius, AMS) are best-guess labels — edit the .mmd to your exact names.
Malware node stays scoped to CONTAINED detonation/analysis, owned by CyberOps + Review.
