# AEGIS diagrams — color standard (v1)

Apply the SAME palette to every diagram (Mermaid classDef names in parentheses).

| Meaning | Color | Fill / Stroke | classDef |
|---|---|---|---|
| Foundation & its services (Foundation, Portico, Kestra, Cosmos, SDLC) | Green | #eaf7ef / #2f8f5b | `foundation` |
| VM Ops (VINES, VM Risk Score) | Purple | #efe6fd / #7c3aed | `vmops` |
| Human / interactive (Pentester, VDI, Console, API) | Blue | #eaf1fe / #2563eb | `human` |
| Version control (G3S / Git) | Teal | #e5f6f6 / #0e8f97 | `vcs` |
| AEGIS core / secure chokepoint (sandbox, governance, egress) | Navy | #102a3f | `core` |
| Per-run runtime (baseline / interactive task) | Amber | #fdf6e9 / #b7791f | `runtime` |
| Risk / destructive / targets (dev/test/prod, twin, malware) | Red | #fde2e2 / #a23b3b | `risk` |
| FUTURE / long-term | Grey | #eceff3 / #9aa7b4 | `future` |
| Model access (Bedrock Mantle) | Slate | #e7edf3 / #64748b | `model` |
| Note callout | Cream | #fffdf5 / #d9be5a | `note` |

## Standing rules
- **Foundation is always green**; **version control is always teal**; **future is always grey**.
- **No break-glass** anywhere — modes are only **headless (auto)** and **interactive (human)**.
- **Bedrock Mantle** serves **standard models now**; **frontier models are a future (grey) plug-in**.
- Every diagram carries this legend + short notes.
