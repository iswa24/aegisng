# web-console

*The operator UI — React/TypeScript; talks only to api-gateway over REST + SSE.*

| | |
|---|---|
| **Plane** | EDGE — Edge / ingress |
| **Trust zone** | Trusted (browser-facing); no direct backend access |
| **Deployment** | Standalone SPA from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The single human surface onto ARC. Six role-separated personas (Scanner eng, Pentester, Reporting, Dev, Risk & Audit, Admin) each see only what their role permits. It renders findings, engagement state, the attack-path graph, approvals, and the audit trail — but holds no authority and no data of its own; everything is fetched live through the one public contract.

## 2. Responsibilities

- Render engagement launch, live run state, findings (dev + reporting views), the cross-surface attack-path graph, HITL approval prompts, and audit views.
- Enforce persona-scoped UI: a role never sees a control it cannot exercise.
- Stream live updates over SSE; never poll the backend directly.
- Treat every finding field as untrusted, adversary-authored data — render-escape all of it.

## 3. Interfaces

**Synchronous**

- Consumes `api-gateway` REST `/v1/...` only; no other backend is reachable from the browser.
- Receives server-sent events (SSE) relayed by `api-gateway`.

## 4. Owned data

- None durable. Session state and per-viewer UI preferences only.

## 5. Dependencies

`api-gateway`

## 6. Runtime & scaling

Static assets on S3 + CloudFront. Stateless; scales with CDN. No server-side session store.

## 7. Security posture

- Strict CSP + render-time output escaping — the source data is adversary-authored by design, so a hostile finding body can never execute in a reporting user's browser.
- No client-side eval of finding content; no secrets in the bundle.
- AuthN via `identity-authz` (IAM Identity Center federation); the browser holds only a short-lived session token.

## 8. Key design decisions

- The browser talks to exactly one backend (api-gateway) — no fan-out from the client, so the public attack surface is one contract.
- Persona separation is enforced server-side too; the UI restriction is defense-in-depth, not the control.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*