# agent-runtime

*The APEX pentest engine — ephemeral agent pods; plan→act→observe→reflect against authorized in-scope targets; every action gated.*

| | |
|---|---|
| **Plane** | UP — Untrusted execution |
| **Trust zone** | Untrusted execution |
| **Deployment** | Standalone engine from stage 1; estate fleet + surface hunters at stage 4→full |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The autonomous pentest engine (APEX), productionized. Ephemeral agent pods run the plan→act→observe→reflect loop against authorized, in-scope, first-party targets (staging by default). Every tool call is authorized by the policy gate before it runs; egress is deny-all with a per-task lease; results propose through the one door. From stage 4 it grows cloud/AD/k8s surface hunters.

## 2. Responsibilities

- Run the agent loop against in-scope targets; authorize every action through the policy gate first.
- Capture exploit proof; propose findings/evidence through `broker-parser`.
- Grow surface hunters (web → +cloud/AD/k8s) as gated tools in a declared lab environment.
- Egress only through the leased `egress-gateway`.

## 3. Interfaces

**Synchronous**

- Dispatch from `orchestrator` (governance-relayed); proposals to `broker-parser`; egress via `egress-gateway`.

## 4. Owned data

- None durable in-plane; scratch in a single emptyDir on read-only rootfs.

## 5. Dependencies

`broker-parser`, `egress-gateway`, `model-router`, `governance-service`

## 6. Runtime & scaling

Ephemeral microVM/agent pod per PoC (Fargate/Karpenter); estate fleet at full ARC. Destroyed on completion.

## 7. Security posture

- Untrusted plane, Invariant I: no authority/key/route; a compromised or injected agent has no path to the bank.
- Every action gated by the policy gate; egress deny-all + ≤2s lease; kill = lease withheld = network-deny.
- One PoC = one ephemeral microVM, never reused across engagements; per-engagement memory partition.

## 8. Key design decisions

- Authority is external to the engine — the LLM reading hostile bytes never also holds the veto.
- Prod contact (from stage 4) is detect-only and IAM-boundaried per vuln-class, not an app flag.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*