# run-controllers

*Split least-privilege controllers — lease-controller (HA dead-man lease), cred-vendor (scoped STS), twin-provisioner.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone (split least-privilege) from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

Holds the mechanical levers that bound a run in time and privilege. The lease-controller issues the ≤2s dead-man lease whose lapse is the prompt network-deny stop; the cred-vendor issues per-run scoped STS credentials; the twin-provisioner stands up digital-twin targets. Split so no single controller holds all the authority.

## 2. Responsibilities

- Issue and renew the dead-man lease; withhold/restore it on a governance instruction (the kill/pause mechanism).
- Vend per-run scoped STS credentials (session-tagged, non-replayable).
- Provision/destroy digital-twin targets.

## 3. Interfaces

**Synchronous**

- gRPC from `governance-service` (lease withhold/restore) and `engagement-operator`.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `lease.granted`, `lease.renewed`, `lease.expired`, `cred.issued`, `cred.revoked`, `twin.provisioned`, `twin.destroyed`
- Consumes: `governance.decision`

## 4. Owned data

- Lease state per run; issued-credential registry.

## 5. Dependencies

`governance-service`, `iam-identity-and-key-custody`

## 6. Runtime & scaling

HA lease-controller (leader-elected); Fargate. Lease renewal is the hot path — sized for sub-second decisions.

## 7. Security posture

- Lease lapse = egress-gateway closes = NETWORK-DENY: the mechanical stop that doesn't depend on the agent cooperating.
- One canonical ≤2s lifetime shared with token and sidecar cache.
- Split least-privilege — lease, credential, and twin authorities are separate roles.

## 8. Key design decisions

- The lease is a dead-man switch: the default is 'stop' and it takes continuous authorized renewal to keep running.
- Kill is enacted by withholding a lease, not by asking the agent to halt.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*