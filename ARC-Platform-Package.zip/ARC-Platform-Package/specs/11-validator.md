# validator

*Refute-by-default proof gate — two-grader, sandbox re-exploit, the evidence ladder; the sole proof authority for both engines.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone (core) from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The service that decides whether a hypothesis is real. It is refute-by-default: a claim is assumed false until proven. It re-exploits in a sandbox, runs a two-grader check with model-family diversity to kill false positives, and assigns an evidence-ladder rung (proven / reached / blocked) that maps to the shipped finding events. It is the single proof authority for both engines, so 'Confirmed' means one thing.

## 2. Responsibilities

- Consume hypotheses (`finding.hypothesized`) and pentest proof; re-exploit in sandbox; assign a ladder rung.
- Two-grader false-positive kill with model-family diversity.
- Emit shipped finding events with `{vuln_id, source, ladder_rung, cvss_vector, cvss_score, evidence_ref}` (CVSS 3.1).
- Re-verify on rescan; emit `finding.rescan_completed`.

## 3. Interfaces

**Synchronous**

- gRPC proof-status APIs.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `finding.static_only`, `finding.replica_proven`, `finding.live_confirmed`, `finding.refuted`, `finding.rescan_completed`
- Consumes: `finding.hypothesized`, `validation.evidence_captured`

## 4. Owned data

- Evidence artifacts (refs into S3); proof state per `vuln_id`.

## 5. Dependencies

`model-router`, `chain-service`

## 6. Runtime & scaling

Sandbox re-exploit runs as ephemeral microVM jobs; Fargate/Karpenter. Scales with hypothesis volume.

## 7. Security posture

- Refute-by-default: no rung without evidence.
- Runs re-exploit in the same contained microVM model as the engines.
- Grader diversity so one injection can't fool both graders identically.

## 8. Key design decisions

- One proof authority for both engines — 'Confirmed' is not two different bars.
- The fine-grained ladder is a field inside the event, not a proliferation of event names.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*