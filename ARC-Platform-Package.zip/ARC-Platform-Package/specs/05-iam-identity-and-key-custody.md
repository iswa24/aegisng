# iam-identity-and-key-custody

*AWS-native workload identity (IRSA), per-run scoped STS roles, human OBO token exchange; provenance/CA keys non-exportable in KMS/CloudHSM.*

| | |
|---|---|
| **Plane** | TC — Trusted control |
| **Trust zone** | Trusted control — key custody |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The root of machine identity and cryptographic custody. Every service runs under an IRSA role; every run gets a scoped STS role whose session tags (`engagement_id`, `tenant_id`, `obo_subject`) make credentials non-replayable across engagements. The provenance-signing key and any CA key are non-exportable in KMS/CloudHSM — `broker-signer` holds only `kms:Sign` on the one key.

## 2. Responsibilities

- Issue workload identity via IRSA (K8s SA → EKS OIDC → `AssumeRoleWithWebIdentity` → least-privilege role).
- Mint per-run scoped STS roles with `engagement_id`/`tenant_id`/`obo_subject` session tags; resource policies condition on `aws:PrincipalTag/engagement_id`.
- Custody the provenance-signing key and CA key — non-exportable, KMS/CloudHSM, rotation retains old versions for multi-year audit verification.
- Back the door's caller authentication (signed `sts:GetCallerIdentity` replay).

## 3. Interfaces

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `identity.key_rotated`

## 4. Owned data

- IAM role definitions; STS session-tag policy; KMS/CloudHSM key hierarchy and rotation state.

## 5. Dependencies

_None (leaf service)._

## 6. Runtime & scaling

Thin control-plane service over AWS STS/KMS; effectively scales with AWS. Fargate service.

## 7. Security posture

- Keys are non-exportable — even a full control-plane compromise cannot exfiltrate the signing key, only request signatures under policy.
- Per-run credentials are non-replayable across engagements by session-tag condition.
- Two-named-approver break-glass for key-policy changes; CloudTrail Sign-rate anomalies feed the kill-switch.

## 8. Key design decisions

- Identity is AWS-IAM-native (D-43) — no SPIRE server, no SPIFFE SVID.
- Key custody is separated from human identity and from the signer that uses the key.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*