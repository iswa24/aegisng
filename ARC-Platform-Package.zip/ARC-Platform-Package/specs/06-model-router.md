# model-router

*The only path to Bedrock — tiered routing, batch/live quota pools with 429 backpressure, champion/challenger A/B on scoring.*

| | |
|---|---|
| **Plane** | TC — Trusted control |
| **Trust zone** | Trusted control |
| **Deployment** | Module stage 1; standalone at stage 3 |
| **First appears** | Stage 3 · Models & A/B |

## 1. Why it exists

Every model call in the platform goes through one service, so model access is governed, in-perimeter, and observable. It routes to the right tier, manages live vs batch quota pools with backpressure, pins one model per engagement for reproducibility, and runs the challenger-in-shadow A/B — where a new model scores in parallel but never drives a real action until it provably beats the incumbent with no regression.

## 2. Responsibilities

- Be the sole path to Bedrock (PrivateLink, zero egress); no other service calls a model directly.
- Tiered routing; live/batch quota pools with 429 backpressure.
- Per-engagement immutable model pin (version/ARN, not a moving alias).
- Champion/challenger shadow scoring; report consumption to `governance-service` for budgeting.
- Provide `Embed()` for memory and findings services.

## 3. Interfaces

**Synchronous**

- gRPC: `Route`/`Complete`, `Embed`; `ReserveBudget` report path to governance.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `model.call_completed`, `model.call_failed`, `quota.pool_saturated`
- Consumes: `killswitch.triggered`, `budget.exhausted`, `eval.regression_failed`

## 4. Owned data

- Model registry (champion + challenger versions/ARNs); per-engagement pins; quota-pool state.

## 5. Dependencies

`governance-service`, `eval-service`, `iam-identity-and-key-custody`

## 6. Runtime & scaling

Fargate service; scales with call volume. Batch tier uses Bedrock batch inference; default 10–20% shadow sampling, not 100%, capped by a per-tier ceiling + CloudWatch billing alarm.

## 7. Security posture

- Bedrock via PrivateLink only — model calls never leave the perimeter.
- A/B is on scoring, never on acting — the challenger has zero door-write permission and no route to production actions.
- Pinned model ARNs — no arbitrary model load path at runtime.

## 8. Key design decisions

- One path to models = one place to govern, meter, and pin them.
- Silent model swaps are structurally blocked: an unreviewed behavior change cannot reach production, even behind an alias.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*