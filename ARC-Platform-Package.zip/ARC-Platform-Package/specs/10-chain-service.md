# chain-service

*Joins both engines on vuln_id — reconciliation into Confirmed / Scanner-only / Testing-only; net-new diff; OSS verdict KB.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone (core) from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The reconciliation layer that makes ARC more than two tools. It joins the code-scanner and pentest results on the host-independent `vuln_id` into three buckets — Confirmed (both), Scanner-only, Testing-only — and computes net-new vs baseline. Because the two engines run blind and reconcile only on a shared key, their errors are anti-correlated: agreement is strong evidence.

## 2. Responsibilities

- Consume validator finding events (both sources) + scan-completion coverage; emit `chain.reconciled` on `vuln_id`.
- Bucket every finding: Confirmed / Scanner-only / Testing-only; compute app-scoped net-new diff.
- Own the authoritative OSS component-verdict KB (graph), exported as a read-only S3 snapshot for untrusted scanner workers.

## 3. Interfaces

**Synchronous**

- gRPC read APIs for `findings-service`/`orchestrator`.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `chain.reconciled`
- Consumes: `finding.static_only`, `finding.replica_proven`, `finding.live_confirmed`, `finding.refuted`, `scan.completed`

## 4. Owned data

- The reconciliation graph and OSS verdict KB (Aurora, FORCE RLS); app-scoped baselines.

## 5. Dependencies

`validator`, `memory-service`

## 6. Runtime & scaling

Reconcile/uniqueness writes funnel to one Aurora writer; replicas scale reads. Fargate service.

## 7. Security posture

- `validator` is the single proof authority for both engines — the scanner's internal two-grader is a pre-proposal noise filter, not final proof.
- `vuln_id` uniqueness is enforced before it becomes a Confirmed record.

## 8. Key design decisions

- Both engines run blind and reconcile only on `vuln_id` — anti-correlated error is the whole value.
- The join key is one versioned contract shared with the graph, buckets, audit, and coverage.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*