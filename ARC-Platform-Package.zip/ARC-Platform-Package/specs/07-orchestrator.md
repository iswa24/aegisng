# orchestrator

*Drives pentest runs — the planning loop; owns the cross-surface attack-path graph; multi-agent coordination.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone (core) from stage 1; grows the graph at stage 4 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The brain of the pentest side. It plans runs, dispatches techniques to the agent-runtime through the governed interface, and — from stage 4 — owns the cross-surface attack-path graph that chains web → cloud → AD → k8s → identity into one story no single-surface tool can assemble. It never touches attacker bytes itself; it reasons over validated results and steers via governance.

## 2. Responsibilities

- Run the perceive→reason→plan→act loop; dispatch techniques to `agent-runtime` (always through the policy gate).
- Own the attack-path graph: integrate proven discoveries as nodes/edges; pivot across surfaces.
- Emit steering commands (`steer.*`) — governance-relayed, never a direct channel into the untrusted plane.
- Consume validated findings and evidence to replan; request re-proof on rescan.

## 3. Interfaces

**Synchronous**

- gRPC to `run-controllers` (lease/dispatch) and `governance-service` (authorize).

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `graph.node.created`, `graph.edge.created`, `graph.node.confidence_changed`, `steer.pause`, `steer.resume`, `steer.abort`, `technique.dispatched`, `chain.replanned`, `run.terminal`
- Consumes: `finding.hypothesized`, `validation.evidence_captured`, `finding.live_confirmed`, `finding.rescan_requested`

## 4. Owned data

- The attack-path graph (Aurora + pgvector, FORCE RLS); run/plan state; node identity as a strict alias of `vuln_id`.

## 5. Dependencies

`governance-service`, `run-controllers`, `model-router`, `validator`, `chain-service`

## 6. Runtime & scaling

One planning context per active run; Fargate service, scales with concurrent engagements. Graph writes funnel to a single Aurora writer.

## 7. Security posture

- Lives in the trusted plane; has no route into the untrusted engines except through governance-relayed steering.
- Graph node identity is a strict alias/superset of `vuln_id` — one registry — so a wrong node collapse can't fabricate an authorizing pivot.
- Cannot widen its own scope; the signed RoE bounds it.

## 8. Key design decisions

- Steering is governance-relayed so the planner never holds a privileged channel into the untrusted plane.
- The graph is the moat — one cross-surface story — and its node identity is a security control, not just a display key.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*