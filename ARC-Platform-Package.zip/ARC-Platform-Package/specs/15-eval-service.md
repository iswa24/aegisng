# eval-service

*Benchmark corpus + regression gate on capability changes — the drift gate that gates agent/model change.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone at stage 3 |
| **First appears** | Stage 3 · Models & A/B |

## 1. Why it exists

You cannot govern what you cannot measure. This is the eval harness that scores every scanner/model/prompt change against a ground-truth corpus and blocks promotion on regression. Injection-resistance is its own eval category with a regenerated held-out fixture set per promotion cycle, owned by an assurance function independent of the builder (evaluator ≠ builder) — the SR 11-7 backbone.

## 2. Responsibilities

- Score every capability change against the benchmark corpus; emit a pass/regression verdict.
- Run injection-resistance as its own eval category with regenerated held-out fixtures per promotion.
- Gate model-router promotions (the drift gate); block on regression.

## 3. Interfaces

**Synchronous**

- gRPC verdict API consumed by `model-router` promotion path.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `eval.run_completed`, `eval.regression_failed`

## 4. Owned data

- Benchmark corpus + ground truth; per-change eval results and held-out fixtures.

## 5. Dependencies

`model-router`

## 6. Runtime & scaling

Batch eval jobs (Fargate/Karpenter, Spot-eligible); runs per promotion cycle, not per request.

## 7. Security posture

- Owned by assurance independent of the ML/eval builders — evaluator ≠ builder, to avoid Goodhart.
- An unreviewed behavior change is structurally unable to reach production.

## 8. Key design decisions

- Built before autonomy widens — the scoreboard precedes scaling.
- Injection-resistance is a first-class, independently-owned eval, not a subclause.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*