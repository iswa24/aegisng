# code-scanner-service

*The CRAFT engine — sandboxed whole-repo build, malicious-code detection, vulnerability discovery, pre-proposal two-grader.*

| | |
|---|---|
| **Plane** | UP — Untrusted execution |
| **Trust zone** | Untrusted execution |
| **Deployment** | Standalone engine from stage 1; estate fleet at full ARC |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The code-analysis engine (CRAFT), productionized. It pulls one immutable snapshot from the work queue, builds and reasons over the whole repo in a sandbox, runs a malicious-code detection track and a vulnerability track, applies a pre-proposal two-grader noise filter, and proposes hypotheses through the one door. It runs in the untrusted account, in an ephemeral microVM, with deny-all egress.

## 2. Responsibilities

- Pull `scanner-work`; sandboxed whole-repo build + analysis.
- Malicious-code detection track + vulnerability track; pre-proposal two-grader filter.
- Propose hypotheses (`finding.hypothesized`, source=code_scanner) through `broker-parser` — never directly onto the spine.
- Pull the OSS verdict KB as a read-only S3 snapshot.

## 3. Interfaces

**Synchronous**

- SQS consume; proposals to `broker-parser`; egress only via `egress-gateway`.

## 4. Owned data

- None durable in-plane; scratch in a single emptyDir on a read-only rootfs.

## 5. Dependencies

`broker-parser`, `egress-gateway`, `model-router`

## 6. Runtime & scaling

Ephemeral microVM per scan (Fargate/Karpenter, Spot-eligible for retryable jobs); one physical work queue with priority attributes.

## 7. Security posture

- Untrusted plane: no authority, no DB-write, no key, no route in (Invariant I).
- One scan = one ephemeral microVM, destroyed on done; read-only rootfs; digest-pinned signed image.
- Proposes only through the keyless door; final proof is `validator`'s, not the scanner's.

## 8. Key design decisions

- The scanner's internal two-grader is a pre-proposal noise filter, not final proof (I5).
- Runs blind of the pentest engine — anti-correlated error is the reconciliation premise.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*