# evidence-audit

*The S3 audit — immutable, tamper-evident record of every event; S3 Object-Lock (Compliance mode); admissibility replay.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform / data |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The audit-of-record the bank's regulatory posture rests on. It consumes every event unconditionally and writes an immutable, hash-chained copy to S3 with Object Lock in Compliance mode — in a separate log-archive account, so the record sits outside the plane it is evidence against. A periodic HSM-signed Merkle checkpoint plus a transparency log let an auditor verify inclusion without trusting the operator.

## 2. Responsibilities

- Consume all event types unconditionally; write an immutable, hash-chained copy to S3 (per-record `prev_hash`).
- S3 Object Lock in Compliance mode (not Governance) in a separate log-archive account (write-only/no-delete cross-account role).
- Periodic HSM-signed Merkle checkpoint + transparency log; admissibility replay on demand.
- Record the OBO subject on every event — answer 'which human caused this'.

## 3. Interfaces

**Synchronous**

- Replay/verify API for Risk & Audit persona (read-only).

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `audit.integrity_check_failed`
- Consumes: `* (all event types)`

## 4. Owned data

- The S3 audit store (Object Lock, Compliance mode) + hash-chain checkpoints; 7-year retention + legal-hold path.

## 5. Dependencies

`iam-identity-and-key-custody`

## 6. Runtime & scaling

Append-only consumer; S3 scales effectively without bound. Cross-region replication for DR of the audit record itself.

## 7. Security posture

- Compliance-mode Object Lock — a privileged insider (DBA/admin) cannot rewrite it.
- Lives in a separate account — evidence is not inside the system it indicts.
- Tamper-evident via hash-chain + Merkle checkpoint; the durable audit path is not `LISTEN/NOTIFY`.

## 8. Key design decisions

- Immutability is the property that matters, and it is structural (Object Lock + out-of-plane), not a policy.
- Formerly labeled 'WORM audit' — the store is S3 with Object Lock; the plain name is 'S3 audit'.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*