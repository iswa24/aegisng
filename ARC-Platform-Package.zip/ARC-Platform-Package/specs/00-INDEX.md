# ARC Platform — Microservice Specifications

*Normalized to the ARC Evolution Atlas · 2026-08-31 · architecture-only.*

## How to read this set

ARC's full logical decomposition is the ~20 services below, across five planes. It is **reached by extraction from a stage-1 modular monolith** — at any given stage only about a dozen are independently deployed; the rest remain modules inside the control monolith or the engines until scale, blast-radius, or audit earns the split. Each spec's header states the plane, trust zone, deployment (module vs standalone), and the stage it first appears. Terminology matches the atlas: **S3 audit** (not WORM), **reporting** persona (not CISO), the **deny-by-default policy gate / PDP**, a **Postgres-first event spine** with **Portico** as the delivery spine only at estate scale, **CVSS 3.1**.

## Trust model

Two AWS accounts. A **trusted control-plane account** holds all authority, data, models, and audit. An **untrusted execution account** is where attacker-controlled bytes are touched, in ephemeral per-job microVMs. A cross-account SCP wall separates them, with zero A↔B network route.

- **Invariant I** — nothing touching attacker-controlled bytes holds authority, DB-write, signing keys, or a route to the control plane.
- **Invariant II** — results cross only as validated, signed claims through **one door**: a keyless `broker-parser` (untrusted) hands a validated typed object to a `broker-signer` (trusted, holds the key, never sees raw bytes).

## Service inventory

| # | Service | Plane | Role | First appears |
|---|---|---|---|---|
| 1 | [`web-console`](./01-web-console.md) | EDGE | The operator UI — React/TypeScript; talks only to api-gateway over REST + SSE. | Stage 1 |
| 2 | [`api-gateway`](./02-api-gateway.md) | EDGE | The one public contract (Backend-for-Frontend) — composes internal gRPC calls, relays events as SSE, mints OBO tokens. | Stage 1 |
| 3 | [`governance-service`](./03-governance-service.md) | TC | The Policy Decision Point (PDP) — deny-by-default scope authorization, no-destruction, budget, kill-switch, admission. The deterministic policy brain. | Stage 1 (as module) |
| 4 | [`identity-authz`](./04-identity-authz.md) | TC | Human authentication/authorization — RBAC personas, segregation-of-duties, federated via AWS IAM Identity Center to the bank IdP. | Stage 1 |
| 5 | [`iam-identity-and-key-custody`](./05-iam-identity-and-key-custody.md) | TC | AWS-native workload identity (IRSA), per-run scoped STS roles, human OBO token exchange; provenance/CA keys non-exportable in KMS/CloudHSM. | Stage 1 |
| 6 | [`model-router`](./06-model-router.md) | TC | The only path to Bedrock — tiered routing, batch/live quota pools with 429 backpressure, champion/challenger A/B on scoring. | Stage 3 |
| 7 | [`orchestrator`](./07-orchestrator.md) | TP | Drives pentest runs — the planning loop; owns the cross-surface attack-path graph; multi-agent coordination. | Stage 1 |
| 8 | [`engagement-operator`](./08-engagement-operator.md) | TP | Go Kubernetes operator — reconciles the Engagement CRD; admission webhook; provisions and tears down run environments. | Stage 1 |
| 9 | [`run-controllers`](./09-run-controllers.md) | TP | Split least-privilege controllers — lease-controller (HA dead-man lease), cred-vendor (scoped STS), twin-provisioner. | Stage 1 |
| 10 | [`chain-service`](./10-chain-service.md) | TP | Joins both engines on vuln_id — reconciliation into Confirmed / Scanner-only / Testing-only; net-new diff; OSS verdict KB. | Stage 1 |
| 11 | [`validator`](./11-validator.md) | TP | Refute-by-default proof gate — two-grader, sandbox re-exploit, the evidence ladder; the sole proof authority for both engines. | Stage 1 |
| 12 | [`findings-service`](./12-findings-service.md) | TP | Finding-as-work-item — dev + reporting views, tickets, hand-back packs, the reporting dashboard, rescan requests. | Stage 1 |
| 13 | [`memory-service`](./13-memory-service.md) | TP | Cross-engagement memory (pgvector) — provenance-guarded, service-partitioned by engagement, coverage tracking. | Stage 2 |
| 14 | [`evidence-audit`](./14-evidence-audit.md) | TP | The S3 audit — immutable, tamper-evident record of every event; S3 Object-Lock (Compliance mode); admissibility replay. | Stage 1 |
| 15 | [`eval-service`](./15-eval-service.md) | TP | Benchmark corpus + regression gate on capability changes — the drift gate that gates agent/model change. | Stage 3 |
| 16 | [`ingestion-service`](./16-ingestion-service.md) | TP | Scanner intake — repo webhooks, snapshot pin, content-hash dedup, enqueue to the scanner work queue. | Stage 1 |
| 17 | [`broker-parser`](./17-broker-parser.md) | UP | The keyless, untrusted-facing half of the one door — closed-schema validation of every proposed claim; holds no key, no route in. | Stage 1 |
| 18 | [`broker-signer`](./18-broker-signer.md) | TD | The trusted half of the one door — taint-join + provenance-sign; the sole producer of the claim→event projection; holds only kms:Sign. | Stage 1 |
| 19 | [`code-scanner-service`](./19-code-scanner-service.md) | UP | The CRAFT engine — sandboxed whole-repo build, malicious-code detection, vulnerability discovery, pre-proposal two-grader. | Stage 1 |
| 20 | [`agent-runtime`](./20-agent-runtime.md) | UP | The APEX pentest engine — ephemeral agent pods; plan→act→observe→reflect against authorized in-scope targets; every action gated. | Stage 1 |
| 21 | [`egress-gateway`](./21-egress-gateway.md) | UP | The SigV4 cloud-proxy egress door — deny-all by default, lease-opened, scope-checked against the resolved destination. | Stage 1 |

## Shared contract vocabulary

- **`vuln_id`** — the host-independent join key behind reconciliation, the graph, buckets, audit, and coverage. One versioned contract.
- **Evidence ladder** — shipped finding events `finding.static_only` · `finding.replica_proven` · `finding.live_confirmed` · `finding.refuted`; the fine-grained rung (`proven-e2e / proven-in-process / reached / blocked / unproven`) rides as a `ladder_rung` field, not as an event name.
- **Reconciliation** — `chain.reconciled {vuln_id, bucket: confirmed|scanner_only|testing_only, net_new}`.
- **Identity** — AWS-IAM-native (IRSA workloads; per-run scoped STS with `engagement_id`/`obo_subject` session tags; OBO token from the edge). No SPIRE/SPIFFE.
- **Environments** — `staging | production_read_verify | digital_twin`.
- **Authorization lifetime** — one canonical ≤2s, inherited by token, lease, and sidecar cache.
