# broker-signer

*The trusted half of the one door — taint-join + provenance-sign; the sole producer of the claim→event projection; holds only kms:Sign.*

| | |
|---|---|
| **Plane** | TD — Trusted data / backbone |
| **Trust zone** | Trusted data/backbone — holds the key, never sees raw bytes |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The trusted half of the one door. It receives the validated typed object from the parser (never raw attacker bytes), binds freshness into the canonical signed bytes, signs with the non-exportable provenance key (it holds only `kms:Sign` on one key), appends to the durable log, and projects each signed claim into typed semantic events. A uniqueness check runs before Sign; a detected duplicate trips the kill-switch.

## 2. Responsibilities

- Taint-join and provenance-sign the validated claim; bind freshness `(engagement_id, run_id, vuln_id, evidence_hash, roe_version_hash, key_id, iat)` into the signed bytes.
- Uniqueness/single-use `jti` check before Sign; a duplicate trips the kill-switch, never silently drops.
- Emit `claim.signed` (raw, for audit) plus the typed semantic event per `claim_type`.
- Append to the durable event spine.

## 3. Interfaces

**Synchronous**

- Inbound hand-off from `broker-parser`; `kms:Sign` to key custody.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `claim.signed`, `finding.hypothesized`, `malicious_code.flagged`, `validation.evidence_captured`, `coverage.observed`

## 4. Owned data

- The signed-claim log head; nonce/`jti` registry.

## 5. Dependencies

`iam-identity-and-key-custody`

## 6. Runtime & scaling

Trusted-plane Fargate; the signer is a correlated single point — sized multi-AZ with Sign-rate anomaly detection.

## 7. Security posture

- Never sees raw attacker bytes — only the parser's validated typed object.
- Holds only `kms:Sign` on one non-exportable key — cannot exfiltrate the key.
- Freshness is bound into the signed bytes, so a stale/replayed claim is detectable and trips the kill-switch.

## 8. Key design decisions

- The sole producer onto the claims stream (D-42/B2) — results cross exactly once, here.
- Signing a semantic-valid but adversary-authored free-text field is the highest-consequence residual — mitigated at the parser, backstopped by human quarantine.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*