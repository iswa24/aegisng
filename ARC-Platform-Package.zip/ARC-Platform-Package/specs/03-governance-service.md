# governance-service

*The Policy Decision Point (PDP) — deny-by-default scope authorization, no-destruction, budget, kill-switch, admission. The deterministic policy brain.*

| | |
|---|---|
| **Plane** | TC — Trusted control |
| **Trust zone** | Trusted control — the authority |
| **Deployment** | Module inside the control monolith stages 1–3; extracted to a standalone service + in-pod sidecar at stage 4 |
| **First appears** | Stage 1 (as module) · extracted Stage 4 |

## 1. Why it exists

The single deterministic authority that decides whether any action is allowed. It is code and policy (OPA/Rego), never model judgment — the whole containment story rests on the fact that authorization is mechanical. Every tool call, egress, model call, and finding proposal is authorized here, deny-by-default, fail-closed at every step. It owns the signed Rules-of-Engagement (RoE) lifecycle, the budget ledger, and the kill-switch state machine.

## 2. Responsibilities

- `Authorize(action)` — the deny-by-default decision pipeline: identity/OBO present → in signed scope → not a destructive verb → within budget → not killed → ALLOW/BLOCK/REQUIRE_APPROVAL, emitting a capability token on ALLOW.
- Enforce the no-destruction deny-list as a structurally separate, higher-priority policy package no engagement policy can shadow.
- Own the signed RoE lifecycle — scope changes mint a new signed version rather than editing a mutable row.
- Run the kill-switch state machine; relay `steer.pause/resume/abort` into lease control and teardown.
- Own the budget ledger (reserve/consume/exhaust) and durable-append the decision log before responding.

## 3. Interfaces

**Synchronous**

- gRPC `GovernanceService` (internal, mTLS/SigV4): `Authorize`, `ReserveBudget`, `EvaluateDelivery`, `VerifyRoE`.
- REST admin surface behind `api-gateway` for RoE authoring/approval and registry management — never on the decision hot path.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `governance.decision`, `killswitch.triggered`, `killswitch.halted`, `budget.reserved`, `budget.consumed`, `budget.exhausted`, `roe.signed`, `scope.changed`
- Consumes: `steer.pause`, `steer.resume`, `steer.abort`

## 4. Owned data

- The decision log (durable-append-before-response, mirrored to S3 audit).
- Signed RoE versions and the no-destruction policy package.
- The budget ledger per engagement.

## 5. Dependencies

`identity-authz`, `iam-identity-and-key-custody`, `run-controllers`

## 6. Runtime & scaling

Two-tier: a central PDP (multi-AZ min-3 behind an internal NLB, HPA on decision latency) plus, from stage 4, an in-pod sidecar fast-path with a central fallback. The sidecar cache expires to explicit DENY; revocation-critical facts push-invalidate ≤1s.

## 7. Security posture

- Deny-by-default, fail-closed on eval error (a stage-exit gate).
- PDP-unreachable = DENY (a P0 kill-switch gauntlet test).
- One canonical authorization lifetime ≤2s, inherited by token, lease, and sidecar cache alike.
- The decision log is written before the ALLOW is returned, so no authorized action is unlogged.

## 8. Key design decisions

- Governance is a module first, extracted only at stage 4 when the hottest path earned the split — the clearest example of split-on-evidence.
- Authorization is deterministic code, not a model — the containment guarantee cannot depend on an LLM behaving.
- Scope is versioned, not edited, so a stale or forged scope can never silently widen authority.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*