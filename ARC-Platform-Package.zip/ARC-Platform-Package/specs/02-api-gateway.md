# api-gateway

*The one public contract (Backend-for-Frontend) — composes internal gRPC calls, relays events as SSE, mints OBO tokens.*

| | |
|---|---|
| **Plane** | EDGE — Edge / ingress |
| **Trust zone** | Trusted platform edge |
| **Deployment** | Standalone (BFF) from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

A single front door for every human interaction, so the internal service mesh is never exposed and identity is stamped once at the edge. It composes backend gRPC calls into REST `/v1/...`, relays the event spine to the browser as SSE, and — critically — performs the OAuth2 token-exchange that mints the engagement-scoped on-behalf-of (OBO) token which propagates the launching human's identity through every downstream hop.

## 2. Responsibilities

- Terminate SSO sessions; mint the engagement-scoped OBO token (RFC 8693 token exchange) that carries `{sub: human, persona, engagement_id}` through every hop.
- Compose internal gRPC into the public REST contract; relay spine events to the browser as SSE.
- Rate-limit, authenticate, and shape every request before it reaches a control-plane service.
- Be the only ingress with a public network path.

## 3. Interfaces

**Synchronous**

- Exposes REST `/v1/...` at the edge; calls every control-plane service over internal gRPC (mTLS via ACM Private CA, IAM-mapped).
- Relays SSE to `web-console`.

## 4. Owned data

- None durable beyond short-lived session/token cache.

## 5. Dependencies

`identity-authz`, `governance-service`, `orchestrator`, `findings-service`, `chain-service`, `memory-service`

## 6. Runtime & scaling

Stateless horizontal scale (Fargate service) behind an internal/edge load balancer; HPA on request latency.

## 7. Security posture

- The OBO mint point — no OBO token downstream means no attributable authority, and the policy gate denies fail-closed.
- The only public surface; everything behind it is private. mTLS to all internal callees.
- No business logic — composition and identity only, so a gateway compromise yields no authority of its own.

## 8. Key design decisions

- BFF pattern: one public contract, internal mesh hidden. The browser cannot reach any service but this one.
- Identity is stamped once, at the edge, and rides every hop — so `evidence-audit` can always answer 'which human caused this'.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*