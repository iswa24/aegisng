# memory-service

*Cross-engagement memory (pgvector) — provenance-guarded, service-partitioned by engagement, coverage tracking.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone at stage 2 |
| **First appears** | Stage 2 · Harden |

## 1. Why it exists

Gives the platform a memory so run 1 starts as deep as run N. It stores episodic findings, semantic facts, and environment observations in pgvector — but every read/write is service-partitioned by `engagement_id` (rejected if absent, not client-filtered), and a provenance tier governs trust: episodic memory needs validator-proof, semantic facts need ≥2 corroborations or a confidence/staleness score. This closes cross-engagement leakage and memory-poisoning.

## 2. Responsibilities

- Store/retrieve episodic, semantic, and environment memory (pgvector); prime planning.
- Enforce `engagement_id` as a service-enforced partition key on every read and write.
- Apply the provenance tier: validator-proof for episodic; ≥2 corroborations / confidence score for semantic.
- Track coverage.

## 3. Interfaces

**Synchronous**

- gRPC recall/write; uses `model-router.Embed`.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `memory.written`, `memory.recalled`, `memory.revalidated`, `coverage.updated`
- Consumes: `coverage.observed`

## 4. Owned data

- pgvector memory store (Aurora, FORCE RLS), partitioned by `engagement_id`/`tenant_id`.

## 5. Dependencies

`model-router`, `validator`

## 6. Runtime & scaling

Aurora + pgvector; read-scaled by replicas. Fargate service.

## 7. Security posture

- Cross-engagement retrieval is structurally impossible (service-enforced partition), with a standing negative test.
- Poisoned memory can't steer a planner without clearing the provenance guard.

## 8. Key design decisions

- Partition is service-enforced, not client-filtered — the isolation doesn't depend on a caller passing a filter.
- Provenance tiers stop an unproven or single-source fact from being treated as ground truth.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*