# identity-authz

*Human authentication/authorization — RBAC personas, segregation-of-duties, federated via AWS IAM Identity Center to the bank IdP.*

| | |
|---|---|
| **Plane** | TC — Trusted control |
| **Trust zone** | Trusted control |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

Establishes who a human is and what persona they hold, and enforces segregation-of-duties across the sensitive actions (who authorizes an engagement, signs the RoE, approves a prod action, operates the signer, audits — no two the same principal). It federates to the bank's IdP through IAM Identity Center and keys SoD and approvals off the OBO subject that rides every hop.

## 2. Responsibilities

- Federate login via IAM Identity Center; establish persona sessions (six personas → permission sets).
- Enforce segregation-of-duties: reject role combinations that violate SoD.
- Own HITL approval issuance — single-use, scoped, time-boxed (≤15 min) tokens, logged on issue and redemption.
- Step-up (re-auth) for high-sensitivity actions.

## 3. Interfaces

**Synchronous**

- gRPC to `api-gateway` and `governance-service`: session validation, SoD checks, approval issuance/redemption.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `identity.role_assigned`, `identity.sod_violation_attempted`, `identity.role_assumed`, `identity.obo_minted`
- Consumes: `killswitch.triggered`

## 4. Owned data

- Persona/permission-set assignments; SoD rules; active approval tokens (issue + redeem records → S3 audit).

## 5. Dependencies

`iam-identity-and-key-custody`

## 6. Runtime & scaling

Stateless verification against IAM Identity Center; small Aurora table for SoD rules and approval records. Fargate service, HPA on request rate.

## 7. Security posture

- SoD is enforced here and cannot be satisfied by one person holding two roles.
- Approval tokens are single-use, verb-scoped, and time-boxed; no-approval = no-action (fail-closed), never timeout-to-proceed.
- Identity is AWS-IAM-native end to end — no SPIRE/SPIFFE.

## 8. Key design decisions

- Human identity (this service) is deliberately separate from key custody — the IdP never holds signing keys and the key custodian never authenticates humans.
- Approvals are objects with a lifecycle, not a mutable 'approved_by' flag.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*