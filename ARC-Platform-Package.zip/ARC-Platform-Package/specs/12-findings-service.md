# findings-service

*Finding-as-work-item — dev + reporting views, tickets, hand-back packs, the reporting dashboard, rescan requests.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

Turns proven findings into work the bank acts on. It presents the dev view (per-vuln_id ticket lifecycle, CI check-run) and the reporting view (dashboard, exec rollups), files tickets, produces hand-back packs, and routes malicious-code flags to a same-day human-gate queue. Every field it renders is treated as untrusted data end-to-end.

## 2. Responsibilities

- Own the finding-as-work-item lifecycle: dev tickets (per `vuln_id`), reporting rollups, hand-back packs.
- Route `malicious_code.flagged` to the same-day human-gate review queue.
- File tickets and CI check-runs; request rescans.
- Recommend controls; export findings.

## 3. Interfaces

**Synchronous**

- REST behind `api-gateway` for the console; ticketing integrations.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `finding.ticket_filed`, `finding.exported`, `finding.rescan_requested`, `control.recommended`
- Consumes: `chain.reconciled`, `malicious_code.flagged`, `finding.live_confirmed`

## 4. Owned data

- Ticket/work-item state; hand-back packs; reporting rollups (Aurora, FORCE RLS).

## 5. Dependencies

`chain-service`, `model-router`

## 6. Runtime & scaling

Fargate service; read-heavy, replica-scaled. Export jobs batched.

## 7. Security posture

- Treats finding content as untrusted data end-to-end; render-escaping + CSP at the console (defense against adversary-authored fields).
- Malicious-code flags always go to a human gate — never auto-actioned.

## 8. Key design decisions

- A finding is a work item with a lifecycle, not a static report row.
- Dev and reporting are different views over the same proven record, role-separated.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*