# ingestion-service

*Scanner intake — repo webhooks, snapshot pin, content-hash dedup, enqueue to the scanner work queue.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The front of the code-analysis pipeline. It receives repo webhooks, pins an immutable snapshot (commit/tree SHA), dedups by content hash so the same code isn't re-scanned, and enqueues work onto the single `scanner-work` SQS queue with a priority attribute. It hands the untrusted scanner exactly one immutable reference — never a live connection into the bank's SCM.

## 2. Responsibilities

- Receive repo webhooks; pin a snapshot (`commit_sha`/`tree_sha`); content-hash dedup.
- Enqueue canonical messages onto `scanner-work` (priority as a message attribute, not separate queues).
- Trigger scanner re-proof on `finding.rescan_requested`.

## 3. Interfaces

**Synchronous**

- SCM webhooks; SQS enqueue.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `scan.enqueued`, `scan.deduped`, `scan.completed`
- Consumes: `finding.rescan_requested`

## 4. Owned data

- Snapshot pins; dedup KB (content-hash → verdict).

## 5. Dependencies

`chain-service`

## 6. Runtime & scaling

Webhook-driven; SQS decouples burst. Fargate service.

## 7. Security posture

- Hands the untrusted scanner an immutable snapshot reference, never a live SCM route.
- Dedup key is content-hash, so identical code short-circuits before touching the untrusted plane.

## 8. Key design decisions

- One physical `scanner-work` queue; priority is a message attribute + backlog discipline, not three queues.
- `scan_tier` enum: `advisory_pr | scan_merge | enforced_gate_release`.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*