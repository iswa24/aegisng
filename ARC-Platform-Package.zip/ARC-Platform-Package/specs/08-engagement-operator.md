# engagement-operator

*Go Kubernetes operator — reconciles the Engagement CRD; admission webhook; provisions and tears down run environments.*

| | |
|---|---|
| **Plane** | TP — Trusted platform |
| **Trust zone** | Trusted platform (K8s control) |
| **Deployment** | Standalone platform component from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

Turns a declarative Engagement custom resource into a live, contained run environment and guarantees teardown. It is the admission webhook that refuses any pod that isn't correctly contained (RuntimeClass, no hostPath/hostNetwork, signed image), and the reconciler that provisions the ephemeral microVM per job and destroys it on completion.

## 2. Responsibilities

- Reconcile the Engagement CRD → provision/teardown run environments.
- Admission webhook: reject non-microVM RuntimeClass, hostPath/hostNetwork/hostPID, unsigned or mutable-tag images.
- Transition run lifecycle on `run.terminal`; guarantee destroy-on-done.
- Enforce the environment enum (`staging | production_read_verify | digital_twin`).

## 3. Interfaces

**Synchronous**

- K8s API (CRD reconcile, admission); gRPC to `run-controllers`.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `engagement.status_changed`, `run.provisioning`
- Consumes: `run.terminal`

## 4. Owned data

- Engagement CRD state; admission policy.

## 5. Dependencies

`run-controllers`, `governance-service`

## 6. Runtime & scaling

Operator pattern; one reconcile loop per cluster, HA leader-elected. Scales with engagement count, not traffic.

## 7. Security posture

- The structural chokepoint that makes 'one PoC = one ephemeral microVM, destroyed on done, never reused' true.
- Admission control is where image-supply-chain (cosign/Kyverno) and runtime isolation are enforced — nothing non-contained can schedule.

## 8. Key design decisions

- Containment is enforced at admission, so it cannot be bypassed by a workload spec.
- Environments are a closed enum; `production_read_verify` is a distinct, gated state, not a boolean flag.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*