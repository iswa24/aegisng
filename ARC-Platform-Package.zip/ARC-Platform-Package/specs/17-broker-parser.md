# broker-parser

*The keyless, untrusted-facing half of the one door — closed-schema validation of every proposed claim; holds no key, no route in.*

| | |
|---|---|
| **Plane** | UP — Untrusted execution |
| **Trust zone** | Untrusted execution — the keyless door half |
| **Deployment** | Standalone from stage 1 |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The only thing on the untrusted side of the one door. It receives proposals from the engines, validates them against a closed schema, applies free-text caps and a secrets/entropy scan (quarantine-to-human on trip), and hands a validated typed object across to the signer. It holds no signing key and has no route to the control plane — so even a fully compromised parser cannot forge a signed claim or reach inward.

## 2. Responsibilities

- Validate every proposed claim against a closed schema; reject anything off-schema.
- Apply hard length + character-class caps and a secrets/entropy scan on every free-text field; quarantine-to-human on a trip.
- Authenticate the proposing pod via signed `sts:GetCallerIdentity` replay.
- Hand the validated typed object to `broker-signer` — the only crossing.

## 3. Interfaces

**Synchronous**

- Untrusted-plane ingress from `code-scanner-service`/`agent-runtime`; one outbound hand-off to `broker-signer`.

## 4. Owned data

- None durable. Holds no key.

## 5. Dependencies

`broker-signer`

## 6. Runtime & scaling

Untrusted-plane Fargate; scales with proposal volume. Stateless.

## 7. Security posture

- Keyless by design — a compromise yields no signing authority.
- No route to the control plane; the only path forward is the validated hand-off.
- The content-channel chokepoint: caps + secrets scan happen here, before anything is signed.

## 8. Key design decisions

- Half of the one door (D-42) — the untrusted half deliberately holds nothing worth stealing.
- This is where 'contain what the agent authors' is enforced, pre-signature.

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*