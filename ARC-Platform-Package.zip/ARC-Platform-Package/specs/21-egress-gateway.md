# egress-gateway

*The SigV4 cloud-proxy egress door — deny-all by default, lease-opened, scope-checked against the resolved destination.*

| | |
|---|---|
| **Plane** | UP — Untrusted execution |
| **Trust zone** | Untrusted execution — the network door |
| **Deployment** | Standalone from stage 1; stateless fleet at estate |
| **First appears** | Stage 1 · ARC pilot |

## 1. Why it exists

The single network exit for the untrusted plane. Default deny-all; a connection opens only under a valid ≤2s lease and only to a destination that passes scope-check against its resolved address (a stateful proxy that terminates and re-checks redirects). Link-local/metadata/RFC1918 are blocked unconditionally. On lease lapse it closes — flushing established connections, not just refusing new ones.

## 2. Responsibilities

- Deny-all egress by default; open only under a valid lease to an in-scope resolved destination.
- Terminate and re-check redirects (302/DNS-rebind); block link-local/metadata/RFC1918 unconditionally.
- On lease lapse / kill: close and flush conntrack — kill established sessions, not just new ones.
- Report new-vs-established teardown latency separately.

## 3. Interfaces

**Synchronous**

- SigV4 cloud-proxy; lease check against `run-controllers`.

**Events** *(names are transport-independent — carried on the Postgres event spine through the cross-surface stage; on Portico at estate scale)*

- Produces: `egress.decision`, `egress.opened`, `egress.closed`, `egress.volume_exhausted`
- Consumes: `lease.expired`, `killswitch.triggered`

## 4. Owned data

- Per-run lease/volume state; egress decision log → S3 audit.

## 5. Dependencies

`run-controllers`, `governance-service`

## 6. Runtime & scaling

Stateless enforcement fleet sharing one lease store in the trusted plane; scales horizontally at estate.

## 7. Security posture

- Scope is enforced against the RESOLVED destination, not the declared one — a persuaded agent can't talk its way past.
- Kill flushes established state; the stop is mechanical.
- No credential on the untrusted side can reconfigure it.

## 8. Key design decisions

- The mechanical stop for exfiltration and pivots — 'contain what the agent does'.
- Established-session teardown is explicit (the earlier design was silent on it — now fixed).

---
*ARC platform spec · normalized to the ARC Evolution Atlas · 2026-08-31 · CVSS 3.1 · architecture-only (no internal names or URLs).*