# Design Studio

Fifteen personas (the design studio, the Cyberspace squad and the program lead), a shared toolkit, and a design party mode. They turn a project or a spec into one interactive design page: C1 to C4 structure, use cases you can follow at any level and as sequence diagrams, data flow, database schema, API contracts, AWS architecture with the official icons, and multi-agent designs. They work on their own and as a BMad module.

## What is in `skills/`

| Folder | What it is |
|---|---|
| `design-agent-maya` | 🧭 Maya, Lead Design Architect. Owns the page; start here. |
| `design-agent-rhea` | 🔎 Rhea, Evidence Analyst. Reads sources, ledger, gaps, briefs, spec traceability. |
| `design-agent-finn` | 🎬 Finn, Flow Designer. Use cases, sequence diagrams, failure paths. |
| `design-agent-dara` | 🗄️ Dara, Data and API Designer. Schema, data flow, API. |
| `design-agent-skye` | ☁️ Skye, Cloud Architect. AWS diagrams. |
| `design-agent-aria` | 🤖 Aria, Agent Systems Architect. Multi-agent designs, agent operating procedures. |
| `design-agent-theo` | 🏛️ Theo, Distinguished Engineer, Agentic Architecture. SmartSDK specialist: what SmartSDK must provide for a feature, the firm playbook, story seeds; agentic patterns and reviews. |
| `design-agent-sage` | 🎯 Sage, Cyberspace Program Lead. Keeps every piece of work pointed at the owner's goals; runs every session and on a schedule; enforces the reading gate. |
| `design-agent-uma` | 🧩 Uma, Use Case Architect. Fully dressed use cases and granular needs; bridges BMad's PRD and design. |
| `design-agent-noor` | 🧭 Noor, Cyber Domain Analyst. Walks every use case and edge case through the design. |
| `design-agent-hana` | 🔧 Hana, Claude Harness Specialist. Reverse-engineers harnesses; nothing lost in a port. |
| `design-agent-ada` | 📜 Ada, AOP Builder. Agent operating procedures in the firm's template and SmartSDK's form. |
| `design-agent-iris` | 🧪 Iris, Agent Evaluation Engineer. Evals in SmartSDK's format; the release gate. |
| `design-agent-kai` | 🧱 Kai, Sandbox Runtime Engineer. Imagined runtime prototypes per use case, drawn by the studio. |
| `design-agent-vera` | 🖍️ Vera, Design Reviewer. Critique, review packets, feedback. |
| `design-party` | Design party mode: the team in one room. |
| `design-kit` | Shared tools and guides: page template, checker, AWS icons, references, tests. Every persona needs it. |
| `bmod-design` | The BMad module record and the party roster. Never run directly. |

Keep all eighteen folders together, side by side. The personas find the kit at `../design-kit`.

## Install

**Claude Code, without BMad.** Copy every folder in `skills/` into your project's `.claude/skills/` (or `~/.claude/skills/`). Then ask for Maya ("talk to Maya", or `/design-agent-maya`) or a design party (`/design-party`).

**With BMad (6.13 or later).** Put this repository where your team hosts skills and replace `YOUR-ORG` in every `bmod.toml` with it (one search and replace; BMad accepts `github:`, `https://`, `file:` or `plugin:` sources). Install the skills beside your BMad skills (`npx skills add <your repo>`, or copy them into the same skills folder), then run the `bmad` skill with `setup design`. BMad then knows the module, its help, and its roster.

**Requirements.** `python3`. For the automatic design check: `pip install playwright` and a Chrome or Chromium. Without a browser the page's own "Run design check" button does the same checks.

## Party mode

- `design-party` — the design studio room. `--party design-review` for an adversarial review, `--party architecture-board` to add the delivery team. `--mode subagent` gives each persona its own agent so they think independently. `--non-interactive "<topic>"` runs one topic to a close.
- With BMad installed, `bmad-party-mode` seats the design team in its default room beside the BMad agents with no setup, and knows two design rooms: `--party design-studio` and `--party design-review`.
- The mixed room, `architecture-board`, is a party-mode customization: copy the entry in `skills/design-party/assets/architecture-board.toml` into `_bmad/custom/bmad-party-mode.toml` (or let `design-party` offer to add it). Then `bmad-party-mode --party architecture-board`.

## Customizing a persona

Under BMad, override any persona in `_bmad/custom/design-agent-<name>.toml` (team) or `.user.toml` (personal): icon, role, style, principles, standing facts, menu. Without BMad, edit the skill's `customize.toml`.

To give every persona your firm's standards, add to each override:

```toml
[agent]
persistent_facts = ["file:{project-root}/docs/architecture-standards.md"]
```

## Maintaining the page engine

The engine lives in `skills/design-kit/template.html` (sections 2 and 3). After any change run `python3 skills/design-kit/tests/run_tests.py`. `build_agents.py` regenerates the persona skills, the module record and the roster from one table; edit the table there, not the generated files.

## AWS icons

`skills/design-kit/aws-icons.json` is the official AWS Architecture Icons set (release 23.1, from AWS Labs), unmodified, under CC BY-ND 2.0. See `skills/design-kit/AWS-ICONS-NOTICE.txt`.

## What changed in 1.1 (after the first full team run)

The seven personas and the design party were run end to end on a real project. These fixes came out of that run.

- **Flowcharts no longer cause false level mismatches.** A flowchart's steps roll up into the box it hangs from.
- **New fields:** `up` (which coarser box a box stands for), `also` (a box opens more than one design), `rollup: false` (a view reads the same at every level), `guard: true`, `group` on a use case (a menu heading that is not an actor), `status` and `stage` on frames, `status` on a table column, plain-text `writers`, and the `aws-group` frame.
- **"Show what this can reach" stops at a guard** and at an asynchronous hand-off, and the check warns when a box is drawn as blocked from something it can still reach.
- **New tool `page.py`:** `summary`, `extract`, `build`, `upgrade`.
- **Design party:** rules for a room with nobody there to decide, a "health party" for an existing design, a transcript, and personas that skip greeting and menus inside a room.
- **Persona skills:** a short path when BMad is not installed and when called for one piece of work.
- **Guides:** the four ways to settle a level mismatch, drawing a schema or an AWS view when the documents are incomplete, and message contracts.
- Regression tests: 136.

## What changed in 1.2 (arrows drawn the way a person draws them)

- **The page now picks the simplest line for each arrow:** straight across or down when two boxes line up; one straight line at an angle when nothing is in the way; one corner when something is; two corners only as a last resort. Before, any two boxes that were not exactly in line got a folded arrow.
- Schema views, AWS views and flowcharts keep right angles (their convention). `lines: "elbow"` or `lines: "direct"` on a view or the whole page, and `line` on one arrow, override the default.
- **`page.py straighten <page> [--apply]`** removes hand-set sides, ports and via points wherever the arrow is simpler without them. `keep: true` protects an arrow.
- The check warns about small jogs ("move one of the two boxes 20px so it is straight").
- The use case diagram uses straight lines from actor to oval.
- Guides and persona skills now say: place the boxes, leave the arrows unrouted on the first draft, then look at the screenshot.
- Regression tests: 143.

## What changed in 1.3 (Confluence and setup)

- **`check.py doctor`** says whether a machine can check pages and take screenshots, and what to fix if not.
- **The page works inside a frame:** side columns shrink, ☰ and Details hide either one, and a Full screen button appears when the page is framed.
- **`page.py confluence <page>`** writes the two snippets that show the whole interactive page on a Confluence page (hosted copy, or attached copy).

## What changed in 1.4 (editing in the page)

- **Edit button on every design page.** A reader clicks a box, an arrow or an open item and adds details, a note, a question, an answer or a decision. Typed text is always shown as text.
- Edits stay in the browser until **Save file** downloads a copy of the page with them inside and a change log line. **Export edits** downloads just the edits.
- `page.py apply-edits <page> <edits.json>` merges exported edits into the working page.
- A box with notes shows a small blue count.
- Regression tests: 147.

## What changed in 1.5 (phones, narrow panes, locked previews)

- **The page works on a phone and in a narrow pane.** The header wraps so every button stays on screen; the menu and the details open as drawers over the drawing; a tap selects, one finger pans, two fingers zoom.
- The Edit button was hidden below 900px. It is now always there.
- **Locked previews** (a viewer that cannot store anything or download): the page says so, keeps the edits listed after a save attempt, and shows them as text to copy.
- The Save file button shows the number of unsaved edits.
- Regression tests: 150.

## What changed in 1.6 (drawing in the page)

- In edit mode, **+ Box** and **+ Arrow** sit on the drawing: add a box where you click, draw an arrow between two boxes, give each a name, a kind and details.
- **Drag a box to move it** (snaps to the grid). Dragging empty space still pans.
- A box or arrow can be deleted from its form, unless a use case walks through it or it opens another design.
- Works with a mouse and by touch. Regression tests: 157.

## What changed in 1.7 (drawing that works with a real hand)

Version 1.6's drawing tools failed in real use: a click that moved a few pixels was thrown away, and dragging from box to box panned the drawing. Fixed:

- Tools act when the pointer is released, so a click may move a little.
- **+ Arrow** also works by dragging from one box to another; a dashed line follows the pointer.
- A picked box shows a blue handle; drag it onto another box to draw an arrow.
- A small finger slide no longer moves a box, and a tap no longer presses whatever opens under the finger.
- Mistakes are explained in the toolbar (the same box twice, a click that missed).
- Tested with wobbling clicks and drags on eight designs, at four screen sizes, with mouse and touch, framed and in a locked preview (324 checks), plus 164 permanent regression tests.

## What changed in 1.8 (the form applies at once)

- Picking a kind of box changes its shape immediately; so do the line kind, how sure, how far along, and details. A name shows on the drawing while it is typed. Before, nothing changed until "Save changes" was pressed, which read as "not working".
- The form's button is now **Done** and only closes the form.
- Typing and picking on one box count as one edit.
- Regression tests: 169.

## What changed in 1.9 (zoom percentage)

- A zoom control at the bottom right of every drawing: the percentage, minus and plus (steps of ten), and a list of levels from 25% to 400% plus Fit all.
- 100% is the designed size. Wheel, pinch and the keys `+`, `-`, `0`, `1` work too.
- The percentage stays the same when a panel opens or the window is resized.
- Regression tests: 175.

## What changed in 1.10 (structure first: lanes, columns, left to right)

- **Use case diagram is a swimlane map.** One lane per actor, one column per phase, read left to right. List `phases` on the page, give each use case a `phase`, and add `then` where one use case leads to the next.
- **Swimlane designs.** A flow design can carry a `swim` block (lanes and columns). Boxes name their `lane` and `col` and need no coordinates; the page places them and draws the lanes. In edit mode a dragged box drops into the lane and column under the pointer.
- **Structure check.** `python3 page.py structure <page>` reports the shape of every design: which way its arrows run, how many rows and columns its boxes share, whether a flow is in lanes, and how the use case diagram is grouped. The design check warns when a design reads right to left, has no clear direction, does not line up, or is a long flow without lanes.
- **Personas plan before they draw.** New guide `references/layout.md`: five decisions per design (direction, columns, rows or lanes, main path, arrows that run back), recorded on the design as `reads` and shown on the page as "How to read it". Maya has a STRUCTURE action for existing pages, Finn a LANES action, and Vera reviews the shape before the content.
- **Fix:** hiding the menu on a laptop squeezed the drawing into a narrow strip. It now takes the freed width.
- Regression tests: 197.

## What changed in 1.11 (every design is laid out to a plan)

- **The moves, written down.** `references/layout.md` now lists the ten moves that give a design a clear order (main path on one row, people on the top row or in the left column, each dependency above or below the box that uses it, zones as columns, few and deliberate long arrows, a `reads` line), and the way of working: plan, arrange, check, look.
- **`python3 page.py arrange <page> <plan.json>`** applies a layout plan: where each box and frame goes, the few arrows that need a set route, and the `reads` line. It prints the before and after numbers and refuses to save if any box, arrow, label, use case or open item would differ.
- **The check notices unplanned designs.** One warning lists the designs of six or more boxes with no `reads` line.
- **Personas.** Every persona applies this to every design it touches. Maya does not release a design with a structure warning or without `reads`.
- Regression tests: 204.

## What changed in 1.12 (Theo, and the redesign prompt)

- **New persona: 🏛️ Theo, Distinguished Engineer, Agentic Architecture** (`design-agent-theo`). He chooses and defends the architecture of agentic and multi-agent systems: the simplest pattern that works, a named reason for every agent boundary, containment by design, failure-mode analysis, production readiness, and mapping onto Google ADK, the Claude Agent SDK or a workflow engine. Actions: PATTERN, REVIEW, ADR, FAILURE, READY, PORT. He works with or without a design page. Aria still draws the agent system; Theo decides what it should be.
- **New guide: `references/agentic-patterns.md`.** The ladder (one call, workflow, single agent, multi-agent) and the five good reasons to split; workflow and agent patterns with when to use them, how they fail and how to contain them; security (the lethal trifecta, quarantined readers, stops outside the agent); the MAST failure categories; production readiness; a framework mapping; the ten deciding questions; a decision-record template. Protocol and framework facts checked on 25 Nov 2026.
- **Design party:** Theo joins the design studio and design review rooms (eight personas).
- **`REDESIGN-PROMPT.md`:** the steps and the prompt for giving an existing design page a clear order with the team.

## What changed in 1.13 (Theo is the SmartSDK specialist)

- **Theo enables features on SmartSDK.** New actions:
  - ENABLE: what SmartSDK must provide for a feature.
  - PLAYBOOK: learn the firm's agent-builder practice.
  - HANDOFF: brief the designers and hand story seeds to the story-writing agent.
  - STORYCHECK: check the finished stories against SmartSDK.
- **New guide: `references/smartsdk-enablement.md`.** The method, the folder layout, the registers (capabilities, gaps, change requests, story seeds, firm playbook) and the hand-off.
- **New tool: `enable.py`** (`init`, `check`, `render`, `playbook`).
  - `check` opens every cited SmartSDK, harness, requirement and playbook file and confirms that the quoted words are on those lines.
  - It also checks that every gap is covered and decided, and that every story is testable, fits one agent session, and depends on the SmartSDK change it needs.
  - `render` writes the story files in BMad format and the enablement report.
- **Framework mapping corrected for ADK 2.x** (Workflow graph; `SequentialAgent`, `ParallelAgent` and `LoopAgent` deprecated from 2.0.0) in `agentic-patterns.md`.
- **`THEO-SMARTSDK-PROMPT.md`:** the prompts for the playbook, a feature, and the hand-off.
- Regression tests: 229 (25 new for `enable.py`, on an invented SmartSDK and harness).

## What changed in 1.14 (the Cyberspace squad)

- **Six new personas**, working with Theo as the Cyberspace squad:
  - 🧩 Uma, Use Case Architect: fully dressed use cases and granular, testable needs, sitting between BMad's PRD and design.
  - 🧭 Noor, Cyber Domain Analyst: walks every use case and edge case through the design and puts gaps on the page.
  - 🔧 Hana, Claude Harness Specialist: reverse-engineers a harness into a cited inventory, including what it gets from Claude Code for free.
  - 📜 Ada, AOP Builder: agent operating procedures in the firm's template (settled 12 Nov) and the form SmartSDK expects.
  - 🧪 Iris, Agent Evaluation Engineer: eval sets in SmartSDK's own eval format, mapped to every AOP step, story criterion and risky edge case.
  - 🧱 Kai, Sandbox Runtime Engineer: imagined runtime prototypes per use case, drawn by the design studio as proposed.
- **New guide: `references/cyberspace-squad.md`.** The chain, the folder layout and the form of every hand-off.
- **New tool: `squad.py`** (`usecases`, `inventory`, `aop`, `evals`, `runtime`, `edges`, `items`, `status`). Every check opens the files it cites.
- **Nothing lost in a port.** `enable.py` now refuses a harness construct that is neither delivered by a capability nor out of scope with a reason. Capabilities cite Uma's needs.
- **Design party room `cyberspace-squad`.** The design studio room is now the eight design personas.
- **`SQUAD-PROMPT.md`** has the prompts.
- Regression tests: 267 (38 new for the squad, on an invented harness, SmartSDK and design page).

## What changed in 1.15 (direction, and reading everything first)

- **New persona: 🎯 Sage, Cyberspace Program Lead.** Sage keeps the charter: the north star in the owner's words, goals with measures, non-goals, decisions, open decisions and priorities. He checks that every piece of work traces to a goal, and says what is off course, what is waiting on the owner, and what matters next. Actions: DIRECTION, CHARTER, GATE, STATUS.
- **Sage runs on his own.**
  - A Claude Code SessionStart hook prints his briefing into every session: north star, goals in order, non-goals, open decisions, and the direction now.
  - A scheduled job runs his direction review (`references/program.md` section 4).
  - The hook settings are in `design-kit/hooks/cyberspace-hooks.json`.
- **The reading gate: every persona reads everything, start to end, before any work.**
  - `readgate.py` declares what must be read.
  - Each reader logs a summary and exact quotes from every part of every file.
  - The check refuses the log when a file is unread, a file has changed since it was read, a quote is wrong, part of a file was skipped, or a summary is thin.
  - A PreToolUse hook blocks Claude from writing to `design/`, `agentic/` and `program/` until every scope has been read in full.
  - Every persona's instructions now start with this rule.
- **New tool: `program.py`** (`check`, `drift`, `report`, `context`). Use cases name their goals; capabilities and stories trace back through needs.
- **New guide: `references/program.md`.**
- **A draft Cyberspace charter** is in the bundle's `program/charter.md`. It is built only from the owner's definition and the requirement register. Measures and priorities are left as open decisions for the owner.
- Regression tests: 299 (32 new for the reading gate and the program checks).

