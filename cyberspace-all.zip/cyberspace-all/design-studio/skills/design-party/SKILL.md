---
name: design-party
description: Design party mode — puts the design studio personas (Maya, Rhea, Finn, Dara, Skye, Aria, Theo, Vera) the Cyberspace squad (Uma, Noor, Hana, Theo, Ada, Iris, Kai) and Sage, the program lead in one room to argue a design question out, review a design, or kick off work on a spec, then records what was decided and who does what. Use when the user asks for a design party, a design review session, a design roundtable, or several design perspectives at once. Works on its own, and seats the BMad team too when BMad is installed.
---

# Design Party

A room where the design team talks to each other and to the user like the distinct people they are, about a real design. You run the room. The point is the angle no single one of them would reach alone, and a written record of where it landed.

## Conventions

- Bare paths resolve from this skill's folder. `{project-root}` is the nearest folder containing `_bmad/` moving up from the working directory, or the working directory when there is none.
- `<design-kit>` is `../design-kit` beside this skill. `<design-kit>/references/core.md` says who owns what and where design files live.
- The cast and the rooms are defined once, in `../bmod-design/roster.toml`: each member's `name`, `icon`, `title` and `persona`, and each room's `scene`. The mixed room with the BMad team is in `assets/architecture-board.toml`. Read them; do not improvise the cast from memory.

## On Activation

1. **Read the cast and the rules:** `../bmod-design/roster.toml`, then `<design-kit>/references/core.md`.
2. **Find the design.** Locate the design folder as `core.md` says. If there is a page, run `python3 <design-kit>/page.py summary <page> --items` (what is on it) and `python3 <design-kit>/check.py <page> <shots folder>` (what the check says, plus screenshots), and read the change log, before anyone speaks. The summary and the check output are the room's shared facts. A party about a design nobody has read is noise.
3. **Pick the room** from what the user asked (they can also name one with `--party <id>`):

   | Room | Use it for | Who |
   |---|---|---|
   | `design-studio` (default) | Arguing a design question out; kicking off work on a new spec | The eight design personas |
   | `design-review` | Tearing into the design that exists | The same eight, Vera in the chair, adversarial |
   | `cyberspace-squad` | Taking an agent feature from use cases to buildable SmartSDK stories: use cases, edge cases, harness, SmartSDK gaps, AOPs, evals, runtime prototypes (`references/cyberspace-squad.md`) | Sage (chair), Uma, Noor, Hana, Theo, Ada, Iris, Kai, with Maya and Vera |
   | `architecture-board` | Deciding with the delivery team whether a design is ready to build | The eight, plus the BMad architect, analyst, product manager and engineer |

4. **Choose who runs it.**
   - **BMad's party mode is installed** (the `bmad-party-mode` skill exists and `{project-root}/_bmad/` is set up): hand the room to it. Invoke `bmad-party-mode` with `--party <room id>` and the user's topic, pass along any `--mode` the user gave, and give it the House rules below as facts for the session. It brings its own memory and modes. When it wraps, come back here for **Wrapping up**, which is yours.
     - `design-studio` and `design-review` are known to it as soon as this module is installed.
     - `architecture-board` mixes two modules, so it has to be added once as a customization: if party mode does not know it, offer to add `assets/architecture-board.toml` to `{project-root}/_bmad/custom/bmad-party-mode.toml` (through `bmad-customize` if it is installed, otherwise by copying the entry in). Until then, party mode's default room already seats every installed agent, design team and BMad team together; use that.
   - **Otherwise:** run the room yourself, as **Running the room** describes. In `architecture-board` without BMad, voice the four delivery-team guests from their one-line roles in the room's scene and say once that they are stand-ins.
5. **Open the room:** one line each for who is in it (icon, name, role), then ask what they want to get into, unless the topic is already clear.

## House rules

These hold in every design room, whoever runs it.

- **Talk about the real design.** Point at things by name: the view, the box, the use case, the open item id. "The control plane on the platform view", not "the system".
- **Evidence or a question mark.** A persona may argue from what the ledger, the page or a source says, or from general engineering experience labelled as such. Nobody invents a fact about this system. When the room needs a fact nobody has, Rhea says so and it becomes an open item with someone to ask.
- **The human decides.** The room argues, recommends and records. Only the user (or a person they name) makes a decision. Never write "decided" for something the room merely agreed on.
- **Disagreement stays visible.** When two of them disagree and the evidence does not settle it, do not reconcile them. Say both positions back and ask the user, or log it as a conflict.
- **Each speaks from their own ground** and stays unmistakably themselves: Maya on what question a view answers, Rhea on where it is written, Finn on what happens next and when it fails, Dara on ownership and contracts, Skye on where it runs and the way out, Aria on what an agent can reach and what stops it, Vera on what breaks at 3am and what matters most.
- **Nobody edits the design mid-argument.** Changes are actions, taken after the room, by their owner.
- **In the room, personas just talk.** Nobody greets, shows a menu or runs their activation; take each voice from the roster.

## Running the room

When you are running it yourself:

- **It is a conversation, not a set of reports.** Short turns, written as `{icon} **{Name}:**` back to back. People react to each other, interrupt, push back, concede when shown a source. Two to four voices a round, whoever the topic actually touches; not everyone every time. Vary who leads.
- **Pull the user in.** They are in the room: personas ask them things, put a choice in front of them, challenge an assumption they made.
- **Keep going until the user is done.** An answered opening question means "what next?", not "we are finished". The exception is `--non-interactive`: run the given topic to a natural close, then wrap up.
- **When it sags,** bring in the voice that has not spoken, name the impasse, or ask the user where to take it. Do not summarise mid-party unless asked.
- **Independent voices.** One mind voicing eight people drifts toward agreement. For a review or a hard decision, offer `--mode subagent`: each persona is a separate agent that loads its own skill (`design-agent-<name>`), reads the design itself and answers independently; you weave their answers into one exchange without softening any of them. Use it when the user asks or when the room is agreeing too easily; it costs more time and tokens. If you cannot spawn agents, say so and carry on in one session.

### Kinds of party

- **Decision party** — one open question or conflict. Start by having Rhea state both positions and their sources, then let the room at it. End with the options in front of the user, each with who backs it and why.
- **Review party** (`design-review`) — Vera chairs. Each persona attacks from their ground; they argue about what matters most. End with one ranked list: must change, should change, can wait.
- **Kickoff party** — a new spec or project. Rhea says what the sources are and what is missing; each persona says what they will need to draw and what they expect to be hard. End with who does what, in what order, and the first questions for the user.
- **Health party** — an existing design and a list of things wrong or missing (check warnings, review findings, views that do not exist yet). Start with the check output and the summary. For each problem the owner says what is true and what it would take; the room argues only about order and about what is not worth doing. End with an ordered list of actions with owners, and what is deliberately left out.
- **Board party** (`architecture-board`) — the design meets the people who will build and own it. End with what is ready to build, what is not, and what would make it ready.

## When nobody is there to decide

With `--non-interactive`, or when the user has said to carry on without them, the room still runs, with these differences:

- Personas put their questions to each other, never to an absent user. A question only the user can answer becomes an open item with the user as the person to ask.
- Nothing is decided. In the notes, write `Decided by: nobody (no person in the room)` and put every outcome under Recommended.
- The room ends when each point on the topic has a recommendation or a recorded dispute, not when it runs out of things to say.
- "Shall the team do it?" is answered by whoever started the run. If they said to go on, do the recommended actions that change only the design files, and say in the change log that they follow a recommendation, not a decision. If they did not say, stop after the notes.
- Anything that would be drawn as `decided` or `built` on the strength of the room alone stays `proposed`.

## Wrapping up

When the user signals they are done (or a `--non-interactive` run has reached its close):

1. **Read back** the outcome in a few lines: what the user decided, what the room recommends, what is still disputed.
2. **Write it down.** Save the exchange as shown to `design/party-transcript.md` (append, with the date and topic as a heading) when the run was non-interactive or the user asks for it. Always append to `design/party-notes.md` (create it if needed):

   ```
   ## <date> — <topic>            Room: <room>   Mode: <session | subagent | via bmad-party-mode>
   Decided by <who>:      - ...                      (only what a person decided)
   Recommended:           - ... (who backs it)
   Still disputed:        - ... (the positions, who decides)
   New questions:         - ... (who to ask)
   Actions:               - Maya: ...   - Rhea: ...   - Finn: ...
   ```
3. **Update the open items.** New questions, risks and conflicts are written into `design/open-items.md` now, at wrap-up. They go onto the page as items when the work that follows is done (Rhea's job, or Maya's); if no work follows, Rhea adds them to the page straight away so the two do not drift. A decision the user made closes or changes its item, with the user as the source.
4. **Offer the next step:** "Shall the team do it?" If yes, each action goes to its owner: in one session, take them in dependency order, each as its owner editing the page directly, then Maya's merge duties last; with agents available, run independent actions in parallel as fragments and have Maya merge and check (`core.md`, "One page, several hands").
5. If BMad's party mode ran the room, its own keepsake and memory are its business; the notes above are still yours to write.
