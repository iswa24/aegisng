#!/usr/bin/env python3
"""Open a Maya design page in a headless browser, run its built-in design check on every design,
walk every use case, and save one screenshot per design.

  python3 check.py path/to/design.html [screenshot-dir]
  python3 check.py doctor                      is this machine set up to check pages and take screenshots?

Exit code 1 if there are page errors or check problems (warnings do not fail).
Needs: pip install playwright, and a Chrome/Chromium (set CHROME=/path/to/chrome if not auto-found).
"""
import os, sys, json, shutil, pathlib
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sync_playwright = None

def find_browser():
    """An installed Chrome, Chromium or Edge. CHROME=/path/to/browser overrides."""
    if os.environ.get("CHROME"): return os.environ["CHROME"]
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "microsoft-edge-stable", "chrome", "msedge"):
        if shutil.which(name): return shutil.which(name)
    for path in ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                 r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                 "/opt/google/chrome/chrome", "/usr/lib/chromium/chromium", "/snap/bin/chromium"):
        if os.path.exists(path): return path
    return None

def doctor():
    import tempfile
    ok = True
    def say(good, what, fix=""):
        nonlocal ok; ok = ok and good; print(("  ok    " if good else "  MISSING ") + what + ("" if good or not fix else "\n          Fix: " + fix))
    print("Design kit doctor: can this machine check a design page and take screenshots?\n")
    say(sys.version_info >= (3, 8), f"Python {sys.version.split()[0]}", "use Python 3.8 or newer")
    try:
        import playwright; say(True, "the playwright package")
    except ImportError:
        say(False, "the playwright package", "pip install playwright   (from your package mirror; no browser download is needed)"); playwright = None
    chrome = find_browser()
    say(bool(chrome), f"a browser: {chrome}" if chrome else "a Chrome, Chromium or Edge on this machine (the one where this command runs, not your desktop)",
        "install Chromium in this environment, or set CHROME=/full/path/to/the/browser")
    tpl = pathlib.Path(__file__).resolve().parent / "template.html"
    say(tpl.exists(), "the kit's template.html", "the design-kit folder is incomplete; copy it again")
    if playwright and chrome and tpl.exists():
        try:
            with sync_playwright() as p, tempfile.TemporaryDirectory() as d:
                b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]); pg = b.new_page(viewport={"width": 1800, "height": 950})
                pg.goto(tpl.as_uri()); n = len(pg.evaluate("MAYA_CHECK()")); shot = pathlib.Path(d) / "t.png"; pg.screenshot(path=str(shot)); size = shot.stat().st_size; b.close()
            say(size > 20000, f"the browser opened the sample page headless, ran its design check ({n} findings) and saved a screenshot ({size // 1024} KB)", "the screenshot came out empty; try another browser with CHROME=")
        except Exception as e:
            say(False, "starting the browser headless", f"it failed with: {str(e).splitlines()[0][:200]}")
    print("\n" + ("All good. Next: run check.py on a page with a screenshot folder, then ask Claude Code to open one of the PNG files and describe it." if ok
                  else "Not ready yet. Without this, open the page in any browser and press 'Run design check': same checks, no screenshots."))
    sys.exit(0 if ok else 1)

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "doctor": doctor()
    page_path = pathlib.Path(sys.argv[1]).resolve()
    shots = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
    if shots: shots.mkdir(parents=True, exist_ok=True)
    chrome = find_browser()
    if sync_playwright is None: sys.exit("The playwright package is missing. Run: python3 check.py doctor")
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(viewport={"width": 1800, "height": 950})
        errs = []
        pg.on("console", lambda m: errs.append(f"{m.type}: {m.text}") if m.type in ("error", "warning") else None)
        pg.on("pageerror", lambda e: errs.append("pageerror: " + str(e)))
        pg.goto(page_path.as_uri())
        res = pg.evaluate("MAYA_CHECK()")
        names = pg.evaluate("Object.fromEntries(DIAGRAM.views.map(v=>[v.id,v.name]))")
        pg_count = pg.evaluate("DIAGRAM.views.filter(v=>!v.auto).length")
        for vid in names:
            pg.evaluate("id => act('view', id)", vid)
            if shots: pg.screenshot(path=str(shots / f"view-{vid}.png"))
        flows = pg.evaluate("DIAGRAM.flows.map(f=>[f.id,f.steps.length])")
        stuck = []
        for fid, n in flows:
            pg.evaluate("id => act('flow', id)", fid)
            for _ in range(n - 1): pg.evaluate("act('next')")
            if pg.evaluate("S.step") != n - 1: stuck.append(fid)
        if shots and flows:
            pg.evaluate("id => act('flow', id)", flows[0][0]); pg.screenshot(path=str(shots / f"flow-{flows[0][0]}.png"))
        b.close()
    problems = [r for r in res if r["level"] == "error"]; warns = [r for r in res if r["level"] == "warn"]
    drawn = pg_count
    print(f"Designs: {drawn}{' (plus the generated use case diagram)' if drawn < len(names) else ''}   Use cases walked: {len(flows)} (stuck: {len(stuck)})")
    print(f"Page errors: {len(errs)}   Problems: {len(problems)}   Warnings: {len(warns)}")
    for e in errs: print("  PAGE   ", e)
    for r in problems: print("  PROBLEM", f"[{names.get(r['view'], '-')}]", r["msg"])
    for r in warns: print("  warning", f"[{names.get(r['view'], '-')}]", r["msg"])
    for f in stuck: print("  PROBLEM use case could not be walked to the end:", f)
    sys.exit(1 if (errs or problems or stuck) else 0)

if __name__ == "__main__":
    main()
