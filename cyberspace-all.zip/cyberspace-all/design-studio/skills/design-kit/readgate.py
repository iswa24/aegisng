#!/usr/bin/env python3
"""The reading gate: nobody works until they have read every source, start to end, and proved it.

  python3 readgate.py init <project-dir> <scope> <path-or-glob>...   declare what must be read for a scope (for example
                                                                      "cyberspace": the requirements, the documents, the
                                                                      SmartSDK repo, the harness). Paths are relative to
                                                                      the project; folders mean every text file under them
  python3 readgate.py plan <project-dir> <scope>                      list every file, its length and the parts that need
                                                                      a quote, so a reader knows the size of the job
  python3 readgate.py check <project-dir> <scope> <reader>            check a reader's log: every file in scope, the
                                                                      version that is there now, a summary, and quotes from
                                                                      every part of every file, each found on its line
  python3 readgate.py status <project-dir>                            every scope and who has passed it
  python3 readgate.py hook <project-dir>                              for a Claude Code PreToolUse hook: block writing to
                                                                      design/, agentic/ or program/ until every scope has a
                                                                      reader who passed (exit 2 with the reason)

A reader's log is <project>/reading/<scope>/<reader>.json:
  {"reader": "theo", "files": [{"path": "req/prd.md", "sha256": "...", "summary": "...",
     "quotes": [{"line": 12, "quote": "words copied from line 12"}], "questions": ["..."]}]}

Files that are not text (PDF, Word, slides) must be converted to text first, into reading/<scope>/converted/, and that
folder put in scope. The gate cannot prove understanding; it proves that every part of every file was opened and read.
"""
import sys, os, json, re, glob, hashlib, pathlib, math

TEXT = {".md", ".txt", ".json", ".yaml", ".yml", ".toml", ".py", ".js", ".ts", ".tsx", ".jsx", ".sh", ".csv", ".sql", ".tf",
        ".cfg", ".ini", ".xml", ".rst", ".go", ".java", ".kt", ".rb", ".mmd", ".puml", ".env.example", ".properties", ".gradle", ".lock"}
CONVERT = {".pdf", ".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".xls", ".odt", ".rtf"}
SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv", "reading"}
GUARD = [g for g in os.environ.get("CYBERSPACE_GUARD", "design,agentic,program").split(",") if g]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(t): return re.sub(r"\s+", " ", t).strip()

def scope_files(proj, scope):
    sc = proj / "reading" / scope / "scope.json"
    if not sc.exists(): sys.exit(f"no scope {scope!r}: run readgate.py init {proj} {scope} <paths>")
    pats = json.loads(sc.read_text())["paths"]; files, convert = set(), set()
    for pat in pats:
        hits = [pathlib.Path(x) for x in glob.glob(str(proj / pat), recursive=True)] or []
        for h in hits:
            cands = [h] if h.is_file() else [x for x in h.rglob("*") if x.is_file()]
            for f in cands:
                r = f.resolve().relative_to(proj.resolve())
                if any(part in SKIP for part in r.parts[:-1]) and not str(r).startswith(f"reading/{scope}/converted"): continue
                if f.is_symlink(): continue
                ext = "".join(f.suffixes[-2:]) if f.name.endswith(".env.example") else f.suffix.lower()
                if ext in TEXT or f.name in ("Dockerfile", "Makefile", "CODEOWNERS", "LICENSE", "README"): files.add(str(r).replace("\\", "/"))
                elif ext in CONVERT: convert.add(str(r).replace("\\", "/"))
    return sorted(files), sorted(convert)

def parts(n):
    """Split a file of n lines into parts; the reader quotes at least one line from each part."""
    size = max(120, math.ceil(n / 25)); return [(a, min(n, a + size - 1)) for a in range(1, n + 1, size)] or [(1, 1)]

def init(proj, scope, paths):
    proj = pathlib.Path(proj); d = proj / "reading" / scope; d.mkdir(parents=True, exist_ok=True)
    (d / "scope.json").write_text(json.dumps({"scope": scope, "paths": paths}, indent=1))
    files, conv = scope_files(proj, scope)
    lines = sum(len((proj / f).read_text(encoding="utf-8", errors="replace").splitlines()) for f in files)
    print(f"scope {scope}: {len(files)} text files, {lines:,} lines")
    for c in conv: print(f"  convert to text first: {c}  (into reading/{scope}/converted/, which is in scope automatically)")
    if conv:
        paths = paths + [f"reading/{scope}/converted"]; (d / "scope.json").write_text(json.dumps({"scope": scope, "paths": paths}, indent=1))

def plan(proj, scope):
    proj = pathlib.Path(proj); files, conv = scope_files(proj, scope); total = 0
    for f in files:
        n = len((proj / f).read_text(encoding="utf-8", errors="replace").splitlines()); total += n
        print(f"{f}  {n} lines  quote from each of: " + ", ".join(f"{a}-{b}" for a, b in parts(n)))
    for c in conv: print(f"NOT READABLE YET: {c} (convert to text into reading/{scope}/converted/)")
    print(f"{len(files)} files, {total:,} lines")

def check(proj, scope, reader, quiet=False):
    proj = pathlib.Path(proj); files, conv = scope_files(proj, scope); err = []
    logp = proj / "reading" / scope / f"{reader}.json"
    if not logp.exists(): err.append(f"{reader} has not started reading scope {scope} (no reading/{scope}/{reader}.json)"); log = {"files": []}
    else:
        try: log = json.loads(logp.read_text())
        except json.JSONDecodeError as e: err.append(f"reading/{scope}/{reader}.json is not valid JSON ({e})"); log = {"files": []}
    L = {e.get("path"): e for e in log.get("files", [])}
    for c in conv:
        if not any(f.startswith(f"reading/{scope}/converted/") and pathlib.Path(f).stem == pathlib.Path(c).stem for f in files): err.append(f"{c} is not text: convert it into reading/{scope}/converted/ and read that")
    summaries = {}; read_lines = 0
    for f in files:
        e = L.get(f)
        if not e: err.append(f"not read: {f}"); continue
        p = proj / f; lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        if e.get("sha256") != sha(p): err.append(f"{f} has changed since {reader} read it (or the sha256 is wrong): read it again"); continue
        s = e.get("summary", "")
        if len(s.split()) < 25: err.append(f"{f}: the summary has {len(s.split())} words; say what the file says in at least 25 of your own")
        if s and s in summaries: err.append(f"{f}: same summary as {summaries[s]}")
        summaries[s] = f
        hit = set()
        for q in e.get("quotes", []):
            n, t = q.get("line"), q.get("quote", "")
            if len(norm(t)) < 15 and len(t.split()) < 3: err.append(f"{f}: quote on line {n} is too short to prove anything ({t!r})"); continue
            if not isinstance(n, int) or not 1 <= n <= len(lines) or norm(t) not in norm(lines[n - 1]): err.append(f"{f}: line {n} does not contain {t[:50]!r}"); continue
            for i, (a, b) in enumerate(parts(len(lines))):
                if a <= n <= b: hit.add(i)
        missing = [f"{a}-{b}" for i, (a, b) in enumerate(parts(len(lines))) if i not in hit and any(norm(x) for x in lines[a - 1:b])]
        if missing: err.append(f"{f}: no quote from lines {', '.join(missing[:6])}{' and more' if len(missing) > 6 else ''}: read the whole file")
        else: read_lines += len(lines)
    if not quiet:
        for m in err: print("NOT READ:", m)
        print(f"{reader} on {scope}: {sum(1 for f in files if f in L)} of {len(files)} files logged; "
              + ("PASSED: everything in scope was read, start to end." if not err else f"{len(err)} problem(s). No work until this passes."))
    return err

def status(proj):
    proj = pathlib.Path(proj); base = proj / "reading"
    scopes = sorted(p.name for p in base.iterdir() if (p / "scope.json").exists()) if base.exists() else []
    if not scopes: print("no reading scopes yet"); return {}
    out = {}
    for s in scopes:
        readers = sorted(p.stem for p in (base / s).glob("*.json") if p.name != "scope.json")
        passed = [r for r in readers if not check(proj, s, r, quiet=True)]
        out[s] = passed; print(f"{s}: passed by {', '.join(passed) or 'nobody'}" + (f"; not yet: {', '.join(sorted(set(readers) - set(passed)))}" if set(readers) - set(passed) else ""))
    return out

def hook(proj):
    proj = pathlib.Path(proj).resolve()
    try: ev = json.load(sys.stdin)
    except Exception: sys.exit(0)
    if ev.get("tool_name") not in ("Write", "Edit", "MultiEdit", "NotebookEdit"): sys.exit(0)
    fp = (ev.get("tool_input") or {}).get("file_path") or (ev.get("tool_input") or {}).get("notebook_path") or ""
    if not fp: sys.exit(0)
    p = pathlib.Path(fp); p = (p if p.is_absolute() else proj / p).resolve()
    try: r = p.relative_to(proj)
    except ValueError: sys.exit(0)
    if not r.parts or r.parts[0] == "reading" or r.parts[0] not in GUARD: sys.exit(0)
    base = proj / "reading"; scopes = sorted(x.name for x in base.iterdir() if (x / "scope.json").exists()) if base.exists() else []
    if not scopes:
        print(f"Blocked by the reading gate: nothing has been read yet. Declare what must be read (readgate.py init) and read it all before writing to {r.parts[0]}/.", file=sys.stderr); sys.exit(2)
    bad = []
    for s in scopes:
        readers = [x.stem for x in (base / s).glob("*.json") if x.name != "scope.json"]
        if not any(not check(proj, s, rd, quiet=True) for rd in readers): bad.append(s)
    if bad:
        print(f"Blocked by the reading gate: scope(s) {', '.join(bad)} not read in full yet. Run readgate.py plan and check for each, read every file start to end, then write to {r}.", file=sys.stderr); sys.exit(2)
    sys.exit(0)

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) >= 4 and a[0] == "init": init(a[1], a[2], a[3:])
    elif len(a) == 3 and a[0] == "plan": plan(a[1], a[2])
    elif len(a) == 4 and a[0] == "check": sys.exit(1 if check(a[1], a[2], a[3]) else 0)
    elif len(a) == 2 and a[0] == "status": status(a[1])
    elif len(a) == 2 and a[0] == "hook": hook(a[1])
    else: print(__doc__); sys.exit(2)
