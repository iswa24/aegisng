#!/usr/bin/env python3
"""The Cyberspace agent squad's tools. Every claim is checked against the files it cites.

  python3 squad.py usecases <agentic-dir> <feature>              Uma: check the use case specs: goal, actors, trigger,
                                                                  numbered main path, extensions tied to steps, business
                                                                  rules, and granular needs, each cited to the PRD
  python3 squad.py inventory <harness-dir> <out.json>            Hana: list every construct of a Claude Code harness
                                                                  (instructions, subagents, skills, commands, hooks,
                                                                  permissions, MCP servers, settings, scripts) and the
                                                                  Claude Code behaviours it relies on, each cited by line
  python3 squad.py aop <agentic-dir> <feature> [--schema s.json]  Ada: lint every AOP in <feature>/aop/ against the firm
                                                                  template, SmartSDK's schema if given, and the inventory
  python3 squad.py evals <agentic-dir> <feature>                  Iris: check eval cases exist in SmartSDK's format and
                                                                  cover every AOP step, story criterion and risky edge case
  python3 squad.py runtime <agentic-dir> <feature>                Kai: check the imagined runtime prototypes per use case
  python3 squad.py edges <agentic-dir> <feature> [--page p.html]  Noor: check the edge cases walked through every use case
  python3 squad.py items <agentic-dir> <feature> <page.html> <out.json>   Noor: turn gaps and questions into page edits
                                                                  for `page.py apply-edits`
  python3 squad.py status <agentic-dir> <feature>                 where the feature is in the chain, and who is next

Formats: references/cyberspace-squad.md. Nothing here imports, installs or runs SmartSDK or the harness.
"""
import sys, json, re, pathlib, datetime
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import enable

SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv"}
KNOWN_TOOLS = ["Bash", "Read", "Write", "Edit", "MultiEdit", "Glob", "Grep", "WebFetch", "WebSearch", "Task", "Agent", "TodoWrite",
               "NotebookEdit", "TaskCreate", "TaskUpdate", "Skill", "SlashCommand", "BashOutput", "KillShell"]

def rel(p, root): return str(p.relative_to(root)).replace("\\", "/")

def frontmatter(lines):
    if not lines or lines[0].strip() != "---": return {}, {}
    try: end = lines.index("---", 1)
    except ValueError:
        end = next((i for i, l in enumerate(lines[1:], 1) if l.strip() == "---"), None)
        if end is None: return {}, {}
    import yaml
    try: d = yaml.safe_load("\n".join(lines[1:end])) or {}
    except Exception: d = {}
    at = {}
    for i in range(1, end):
        m = re.match(r"([A-Za-z_-]+)\s*:", lines[i])
        if m: at.setdefault(m.group(1), i + 1)
    return (d if isinstance(d, dict) else {}), at

def find_line(lines, needle, start=1):
    for i in range(start - 1, len(lines)):
        if needle in lines[i]: return i + 1
    return None

def inventory(hdir, out):
    root = pathlib.Path(hdir).resolve(); C = []
    def add(kind, name, f, line, detail=""):
        lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
        q = lines[line - 1].strip()[:160] if 1 <= line <= len(lines) else ""
        C.append({"kind": kind, "name": name, "detail": detail, "cite": {"ref": f"harness:{rel(f, root)}:{line}", "quote": q}})
    files = []
    for f in sorted(root.rglob("*")):
        if any(part in SKIP for part in f.relative_to(root).parts) or f.is_symlink() or not f.is_file() or f.stat().st_size > 2_000_000: continue
        files.append(f)
    tools_seen = {}
    def tools_in(text, f, line):
        for t in KNOWN_TOOLS:
            if re.search(rf"\b{t}\b", str(text)): tools_seen.setdefault(t, (f, line))
    for f in files:
        r = rel(f, root); name = f.name; lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
        if name in ("CLAUDE.md", "CLAUDE.local.md", "AGENTS.md"):
            for i, l in enumerate(lines, 1):
                if re.match(r"#{1,4}\s+\S", l): add("instruction", f"{r} § {l.lstrip('#').strip()}", f, i)
            if not any(re.match(r"#{1,4}\s", l) for l in lines) and lines: add("instruction", r, f, 1)
        elif r.startswith(".claude/agents/") and name.endswith(".md"):
            fm, at = frontmatter(lines); add("subagent", fm.get("name") or f.stem, f, at.get("name", 1), f"tools: {fm.get('tools', 'inherits all')}; model: {fm.get('model', 'inherit')}")
            tools_in(fm.get("tools", ""), f, at.get("tools", 1))
        elif name == "SKILL.md":
            fm, at = frontmatter(lines); add("skill", fm.get("name") or f.parent.name, f, at.get("name", 1), str(fm.get("description", ""))[:120])
            if fm.get("allowed-tools"): tools_in(fm["allowed-tools"], f, at.get("allowed-tools", 1))
        elif r.startswith(".claude/commands/") and name.endswith(".md"):
            add("command", "/" + rel(f, root / ".claude" / "commands")[:-3], f, 1)
        elif r.startswith(".claude/") and re.fullmatch(r"settings(\.local)?\.json", name):
            try: d = json.loads("\n".join(lines))
            except json.JSONDecodeError: add("setting", f"{r} (not valid JSON)", f, 1); continue
            for ev, groups in (d.get("hooks") or {}).items():
                evl = find_line(lines, f'"{ev}"') or 1
                for g in groups or []:
                    m = g.get("matcher", "*"); ml = find_line(lines, f'"{m}"', evl) if g.get("matcher") else evl
                    cmds = [h.get("command", h.get("type", "")) for h in g.get("hooks", [])]
                    add("hook", f"{ev}:{m}", f, ml or evl, "; ".join(cmds))
                    for c in cmds:
                        for tok in re.findall(r"[\w./-]+\.(?:sh|py|js|ts|rb)", c or ""):
                            sp = next((x for x in files if rel(x, root).endswith(tok.lstrip("./").replace("$CLAUDE_PROJECT_DIR/", ""))), None)
                            if sp: add("script", rel(sp, root), sp, 1, f"run by hook {ev}:{m}")
            for mode in ("allow", "deny", "ask"):
                for e in (d.get("permissions") or {}).get(mode, []) or []:
                    add("permission", f"{mode} {e}", f, find_line(lines, json.dumps(e)) or 1); tools_in(e, f, find_line(lines, json.dumps(e)) or 1)
            for k in ("model", "defaultMode", "permissionMode", "outputStyle", "statusLine", "apiKeyHelper", "enableAllProjectMcpServers"):
                if k in d or k in (d.get("permissions") or {}): add("setting", k, f, find_line(lines, f'"{k}"') or 1)
            for k in (d.get("env") or {}): add("env", k, f, find_line(lines, f'"{k}"') or 1)
            for k in (d.get("mcpServers") or {}): add("mcp-server", k, f, find_line(lines, f'"{k}"') or 1)
        elif name == ".mcp.json":
            try: d = json.loads("\n".join(lines))
            except json.JSONDecodeError: add("mcp-server", f"{r} (not valid JSON)", f, 1); continue
            for k, v in (d.get("mcpServers") or {}).items(): add("mcp-server", k, f, find_line(lines, f'"{k}"') or 1, v.get("command") or v.get("url", ""))
        elif name == "plugin.json" and ".claude-plugin" in r: add("plugin", r, f, 1)
    # what the harness gets from Claude Code itself; a port must provide each one or say why not
    implicit = [("agent loop", "the model calls tools in a loop until it decides it is done"),
                ("context management", "long sessions are compacted; CLAUDE.md is loaded at start and nested ones on demand"),
                ("permission prompts", "tool calls not allowed by rules are put to a person"),
                ("model behaviour", "the prompts assume a Claude model's habits")]
    for t, (f, line) in sorted(tools_seen.items()): implicit.append((f"built-in tool {t}", f"the harness uses Claude Code's {t} tool", f, line))
    C.sort(key=lambda c: (c["cite"]["ref"].split(":")[1], int(c["cite"]["ref"].rsplit(":", 1)[1])))
    for x in implicit:
        e = {"kind": "implicit", "name": x[0], "detail": x[1]}
        if len(x) > 2:
            lines = x[2].read_text(encoding="utf-8", errors="replace").splitlines()
            e["cite"] = {"ref": f"harness:{rel(x[2], root)}:{x[3]}", "quote": lines[x[3] - 1].strip()[:160]}
        C.append(e)
    for i, c in enumerate(C, 1): c["id"] = f"H{i:03d}"
    data = {"harness": str(root.name), "generated": datetime.date.today().isoformat(), "constructs": C}
    pathlib.Path(out).write_text(json.dumps(data, indent=1), encoding="utf-8")
    from collections import Counter
    n = Counter(c["kind"] for c in C)
    print(f"{len(C)} constructs: " + ", ".join(f"{v} {k}" for k, v in n.items()) + f"\nwrote {out}. Each one must end up in a capability, in an AOP, or out of scope with a reason.")

# ---------------- shared ----------------
def report(name, ctx):
    for m in ctx.err: print("PROBLEM:", m)
    for m in ctx.warn: print("warning:", m)
    print(f"{name}: Problems: {len(ctx.err)}   Warnings: {len(ctx.warn)}")
    return 1 if ctx.err else 0

def table(body, heading):
    m = re.search(rf"^##\s+{re.escape(heading)}\s*$(.*?)(?=^##\s|\Z)", body, re.S | re.M)
    if not m: return None, []
    rows = [l.strip() for l in m.group(1).splitlines() if l.strip().startswith("|")]
    if len(rows) < 2: return m.group(1), []
    cells = lambda l: [c.strip() for c in l.strip().strip("|").split("|")]
    head = [h.lower() for h in cells(rows[0])]
    out = [dict(zip(head, cells(r))) for r in rows[2:] if not re.fullmatch(r"[\s|:-]*", r)]
    return m.group(1), [dict(r, _head=head) for r in out]

AOP_KEYS = ["id", "version", "owner", "mode", "tier", "allowed_environments", "max_state_risk", "required_tools", "required_inputs",
            "max_budget", "stop_conditions", "approvals_required", "evidence_required", "evals", "review_by"]
AOP_SECTIONS = ["Purpose", "Preconditions", "Inputs", "Procedure", "Decision points", "Human checkpoints", "Prohibited actions",
                "Evidence and outputs", "Exit criteria", "Escalation"]
RISK = ["S0", "S1", "S2"]; TIER = ["T0", "T1", "T2", "T3"]

def parse_aop(p):
    lines = p.read_text(encoding="utf-8").splitlines(); fm, _ = frontmatter(lines)
    end = next((i for i, l in enumerate(lines[1:], 1) if l.strip() == "---"), 0)
    return fm, "\n".join(lines[end + 1:])

def aop(base, feature, schema=None):
    ctx = enable.Ctx(base); f = ctx.base / feature; d = f / "aop"
    files = sorted(d.glob("*.md")) if d.is_dir() else []
    if not files: ctx.err.append(f"{feature}/aop/ has no AOP files")
    inv = enable.load(f / "inventory.json", None); invids = {c["id"]: c for c in (inv or {}).get("constructs", [])}
    target = f / "aop" / "target.json"
    tgt = enable.load(target, None)
    if tgt is None: ctx.err.append("aop/target.json is missing: record what SmartSDK expects an AOP to be (format, where it is loaded, fields), with citations, or that it has no AOP format (status none, with the evidence)")
    else:
        if tgt.get("status") not in ("schema", "format", "none"): ctx.err.append("aop/target.json: status must be schema (SmartSDK has a machine-readable schema), format (documented but no schema) or none")
        if not tgt.get("cites"): ctx.err.append("aop/target.json: cite the SmartSDK source that shows what it expects (or the search that found nothing)")
        for j, c in enumerate(tgt.get("cites") or []): enable.cite_ok(ctx, c, f"aop/target.json.cites[{j}]")
        if tgt.get("status") == "schema" and not (schema or tgt.get("schema")): ctx.err.append("aop/target.json says SmartSDK has a schema: give its path (schema, relative to the agentic folder) so every AOP is validated against it")
        schema = schema or (str(ctx.base / tgt["schema"]) if tgt.get("schema") else None)
    sch = json.loads(pathlib.Path(schema).read_text()) if schema else None
    referenced = set()
    for p in files:
        w = f"aop/{p.name}"; fm, body = parse_aop(p)
        for k in AOP_KEYS:
            if k not in fm: ctx.err.append(f"{w}: frontmatter is missing {k}")
        if fm.get("id") and fm["id"] != p.stem: ctx.err.append(f"{w}: id {fm['id']!r} must match the file name")
        for s in AOP_SECTIONS:
            if not re.search(rf"^##\s+{re.escape(s)}\s*$", body, re.M): ctx.err.append(f"{w}: missing section '## {s}'")
        if fm.get("tier") not in TIER: ctx.err.append(f"{w}: tier must be one of {', '.join(TIER)}")
        msr = fm.get("max_state_risk") or {}
        for env in fm.get("allowed_environments") or []:
            if msr.get(env) not in RISK: ctx.err.append(f"{w}: max_state_risk has no S0/S1/S2 ceiling for {env}")
        try:
            if datetime.date.fromisoformat(str(fm.get("review_by"))) < datetime.date.today(): ctx.err.append(f"{w}: review_by {fm.get('review_by')} has passed; re-review the AOP")
        except ValueError: ctx.err.append(f"{w}: review_by must be a date (YYYY-MM-DD)")
        _, steps = table(body, "Procedure")
        need = ["#", "actor", "action", "tool", "risk", "expected output", "on failure", "source"]
        if steps and [h for h in need if h not in steps[0]["_head"]]: ctx.err.append(f"{w}: the Procedure table needs the columns {', '.join(need)}")
        if not steps: ctx.err.append(f"{w}: the Procedure table has no steps")
        tools = set(fm.get("required_tools") or []); top = 0; hasS2 = False
        for i, r in enumerate(steps, 1):
            sw = f"{w} step {r.get('#', i)}"
            if r.get("#") != str(i): ctx.err.append(f"{sw}: steps are numbered 1, 2, 3 in order")
            if r.get("actor", "").lower() not in ("agent", "platform", "human"): ctx.err.append(f"{sw}: actor must be agent, platform or human (one actor per step)")
            if r.get("risk") not in RISK: ctx.err.append(f"{sw}: risk must be S0, S1 or S2")
            else: top = max(top, RISK.index(r["risk"])); hasS2 |= r["risk"] == "S2"
            for t in [x.strip(" `") for x in r.get("tool", "").split(",") if x.strip(" `-")]:
                if t not in tools: ctx.err.append(f"{sw}: tool {t} is not in required_tools")
            if not r.get("expected output") or r.get("expected output") == "-": ctx.err.append(f"{sw}: every step ends in a checkable output")
            if not r.get("on failure") or r.get("on failure") == "-": ctx.err.append(f"{sw}: say what happens on failure")
            src = r.get("source", "")
            if not src: ctx.err.append(f"{sw}: source is empty: name the harness constructs it comes from (H012), a story (S01), or new: <why>")
        allowed = [msr.get(e) for e in fm.get("allowed_environments") or [] if msr.get(e) in RISK]
        if allowed and top > max(RISK.index(x) for x in allowed): ctx.err.append(f"{w}: a step is {RISK[top]}, above every environment's ceiling")
        if "production" in (fm.get("allowed_environments") or []) and msr.get("production") in RISK and top > RISK.index(msr["production"]):
            ctx.warn.append(f"{w}: some steps exceed the production ceiling {msr['production']}; the decision points must keep them out of production")
        if fm.get("tier") in TIER and ((hasS2 and TIER.index(fm["tier"]) < 2) or (top >= 1 and TIER.index(fm["tier"]) < 1)): ctx.err.append(f"{w}: tier {fm['tier']} is too low for a {RISK[top]} step (S1 needs T1, S2 needs T2)")
        _, dp = table(body, "Decision points")
        if not dp: ctx.err.append(f"{w}: Decision points has no rows (every branch is written; none means stop and ask)")
        _, hc = table(body, "Human checkpoints")
        if (hasS2 or fm.get("mode") == "interactive") and not hc: ctx.err.append(f"{w}: an S2 step or an interactive run needs at least one human checkpoint")
        for x in re.findall(r"\bH\d{3}\b", body):
            if inv is not None and x not in invids: ctx.err.append(f"{w}: {x} is not in inventory.json")
            referenced.add(x)
        _, nco = table(body, "Not carried over")
        for r in nco:
            for x in re.findall(r"\bH\d{3}\b", " ".join(v for k, v in r.items() if k != "_head")):
                referenced.add(x)
                if not r.get("reason"): ctx.err.append(f"{w}: Not carried over: {x} needs a reason")
        if sch:
            for k in sch.get("required", []):
                if k not in fm: ctx.err.append(f"{w}: SmartSDK's schema requires {k}")
            try:
                import jsonschema
                for e in jsonschema.Draft202012Validator(sch).iter_errors(json.loads(json.dumps(fm, default=str))): ctx.err.append(f"{w}: SmartSDK schema: {e.message}")
            except ImportError: ctx.warn.append("jsonschema is not installed: only the schema's required keys were checked (pip install jsonschema)")
    if inv is not None and files:
        caps = {x for c in enable.load(f / "capabilities.json", []) for x in (c.get("constructs") or [])}
        oos = {o.get("construct") for o in enable.load(f / "out-of-scope.json", [])}
        for c in inv.get("constructs", []):
            if c["kind"] != "implicit" and c["id"] not in referenced and c["id"] not in oos:
                ctx.err.append(f"harness construct {c['id']} ({c['kind']}: {c['name']}) appears in no AOP; carry it over or list it under '## Not carried over' with a reason")
    return report("aop", ctx)

def aop_steps(f):
    out = {}
    for p in sorted((f / "aop").glob("*.md")):
        fm, body = parse_aop(p); _, steps = table(body, "Procedure"); out[p.stem] = [s.get("#") for s in steps]
    return out

def evals(base, feature):
    ctx = enable.Ctx(base); f = ctx.base / feature; m = enable.load(f / "evals" / "map.json", None)
    if m is None: ctx.err.append("evals/map.json is missing"); return report("evals", ctx)
    fmt = m.get("format") or {}
    if not fmt.get("name"): ctx.err.append("evals/map.json: format.name: say which SmartSDK eval format the cases are in")
    if not any((c.get("ref") or "").startswith("smartsdk:") for c in fmt.get("cites") or []): ctx.err.append("evals/map.json: format.cites must cite the SmartSDK source that defines the eval format and how it is run")
    for j, c in enumerate(fmt.get("cites") or []): enable.cite_ok(ctx, c, f"evals format.cites[{j}]")
    if not fmt.get("run"): ctx.err.append("evals/map.json: format.run: the command that runs these evals through SmartSDK")
    steps = aop_steps(f); stories = {s["id"]: s for s in enable.load(f / "stories.json", [])}
    caps = {c["id"] for c in enable.load(f / "capabilities.json", [])}; edges = {e["id"]: e for e in enable.load(f / "edge-cases.json", [])}
    cov = {}
    for i, c in enumerate(m.get("cases") or []):
        w = f"eval case {c.get('id', i)}"
        if c.get("kind") not in ("golden", "safety", "regression", "edge"): ctx.err.append(f"{w}: kind must be golden, safety, regression or edge")
        if c.get("kind") == "safety" and c.get("veto") is not True: ctx.err.append(f"{w}: a safety case is a veto (veto: true): one failure blocks release")
        fp = f / "evals" / (c.get("file") or "")
        if not c.get("file") or not fp.is_file(): ctx.err.append(f"{w}: file {c.get('file')!r} does not exist under evals/")
        elif c.get("id") and c["id"] not in fp.read_text(encoding="utf-8", errors="replace"): ctx.err.append(f"{w}: the case id is not in {c['file']}; the map must point at a real case")
        if not c.get("covers"): ctx.err.append(f"{w}: say what it covers")
        for x in c.get("covers") or []:
            mm = re.fullmatch(r"AOP:([\w.-]+)#(\d+)", x); ms = re.fullmatch(r"(S\d+)#(\d+)", x)
            if mm:
                if mm.group(2) not in steps.get(mm.group(1), []): ctx.err.append(f"{w}: covers {x}, but that AOP step does not exist")
            elif ms:
                s = stories.get(ms.group(1))
                if not s or not 1 <= int(ms.group(2)) <= len(s.get("acceptance") or []): ctx.err.append(f"{w}: covers {x}, but that story criterion does not exist")
            elif x in caps or x in edges: pass
            else: ctx.err.append(f"{w}: covers {x}: use AOP:<id>#<step>, S01#<criterion>, a capability id or an edge case id")
            cov.setdefault(x, []).append(c)
    for a, ss in steps.items():
        for s in ss:
            if f"AOP:{a}#{s}" not in cov: ctx.err.append(f"AOP {a} step {s} has no eval case")
    for sid, s in stories.items():
        for j in range(1, len(s.get("acceptance") or []) + 1):
            if f"{sid}#{j}" not in cov: ctx.err.append(f"story {sid} criterion {j} has no eval case")
    for eid, e in edges.items():
        if e.get("severity") == "high" and not any(c.get("kind") in ("safety", "edge") for c in cov.get(eid, [])): ctx.err.append(f"edge case {eid} is high severity and has no safety or edge eval case")
    print(f"{len(m.get('cases') or [])} cases, {sum(1 for c in m.get('cases') or [] if c.get('veto'))} veto. ", end="")
    return report("evals", ctx)

UC_SECTIONS = ["Goal", "Primary actor", "Stakeholders and interests", "Trigger", "Preconditions", "Main success scenario", "Extensions",
               "Business rules", "Needs", "Success guarantees", "Out of scope", "Open questions", "Traceability"]

def uc_parse(p):
    t = p.read_text(encoding="utf-8"); fm, body = parse_aop(p) if t.startswith("---") else ({}, t)
    sec = lambda h: (re.search(rf"^##\s+{re.escape(h)}\s*$(.*?)(?=^##\s|\Z)", body, re.S | re.M) or [None, ""])[1]
    main = re.findall(r"^\s*(\d+)\.\s+(.*)$", sec("Main success scenario"), re.M)
    ext = re.findall(r"^\s*(\d+)([a-z])\.\s+(.*)$", sec("Extensions"), re.M)
    _, needs = table(body, "Needs")
    return fm, body, sec, main, ext, needs

def usecases(base, feature):
    ctx = enable.Ctx(base); f = ctx.base / feature; d = f / "usecases"
    files = sorted(d.glob("UC*.md")) if d.is_dir() else []
    if not files: ctx.err.append(f"{feature}/usecases/ has no use cases (UC01-<name>.md)")
    allneeds = set()
    for p in files:
        w = f"usecases/{p.name}"; fm, body, sec, main, ext, needs = uc_parse(p)
        if not re.match(r"UC\d+", fm.get("id", "")) or not p.name.startswith(fm.get("id", "?")): ctx.err.append(f"{w}: frontmatter id (UC01) must start the file name")
        for k in ("id", "title", "status", "level"):
            if not fm.get(k): ctx.err.append(f"{w}: frontmatter needs {k}")
        if fm.get("status") not in ("draft", "agreed", "changed"): ctx.err.append(f"{w}: status is draft, agreed (the product owner said so) or changed")
        if fm.get("level") not in ("summary", "user-goal", "subfunction"): ctx.err.append(f"{w}: level is summary, user-goal or subfunction")
        for s_ in UC_SECTIONS:
            if not re.search(rf"^##\s+{re.escape(s_)}\s*$", body, re.M): ctx.err.append(f"{w}: missing section '## {s_}'")
        g = sec("Goal").strip()
        if g and len(g.split()) > 40: ctx.warn.append(f"{w}: the goal is long; one sentence a person would say")
        if len(main) < 3: ctx.err.append(f"{w}: the main success scenario needs numbered steps (at least three)")
        if [int(n) for n, _ in main] != list(range(1, len(main) + 1)): ctx.err.append(f"{w}: main steps are numbered 1, 2, 3 in order")
        for n, txt in main:
            if not re.match(r"[^:]{2,40}:\s+\S", txt): ctx.err.append(f"{w}: step {n} is written 'Actor: does something' (one actor, one action)")
        steps = {n for n, _ in main}
        if not ext: ctx.err.append(f"{w}: no extensions; every use case has alternate and failure paths (3a. ...)")
        for n, l, txt in ext:
            if n not in steps: ctx.err.append(f"{w}: extension {n}{l} points at step {n}, which does not exist")
        if not any(re.search(r"fail|error|timeout|unavailable|denied|reject|invalid|cannot|not found", t_, re.I) for _, _, t_ in ext): ctx.warn.append(f"{w}: no extension says what happens when something fails")
        if needs and [h for h in ("id", "need", "acceptance", "priority", "source") if h not in needs[0]["_head"]]: ctx.err.append(f"{w}: the Needs table needs the columns id, need, acceptance, priority, source")
        if not needs: ctx.err.append(f"{w}: no granular needs; list what must be true, each testable")
        for r in needs:
            nid = r.get("id", "")
            if not re.fullmatch(rf"{fm.get('id', 'UC')}\.N\d+", nid): ctx.err.append(f"{w}: need id {nid!r} must look like {fm.get('id')}.N1")
            if nid in allneeds: ctx.err.append(f"{w}: duplicate need {nid}")
            allneeds.add(nid)
            if r.get("priority", "").lower() not in ("must", "should", "could", "won't", "wont"): ctx.err.append(f"{w}: need {nid}: priority is must, should, could or won't")
            if not r.get("acceptance") or r["acceptance"] == "-": ctx.err.append(f"{w}: need {nid}: say how we know it is met")
            if re.search(r"\b(fast|easy|user-friendly|robust|seamless|secure|scalable|appropriate|etc)\b", r.get("need", ""), re.I) and not re.search(r"\d", r.get("acceptance", "")):
                ctx.err.append(f"{w}: need {nid} uses a vague word; put a number or a checkable condition in its acceptance")
            src = r.get("source", "")
            if not re.search(r"(req|work):[^\s]+:\d+", src) and not src.lower().startswith("asked"): ctx.err.append(f"{w}: need {nid}: source cites the requirement line (req:prd.md:12) or says 'asked <who>, <date>'")
        tr = sec("Traceability")
        for m in re.finditer(r"`?((?:req|work):[^\s`]+:\d+(?:-\d+)?)`?\s*(?:[—-]+\s*\"([^\"]+)\")?", tr):
            enable.cite_ok(ctx, {"ref": m.group(1), "quote": m.group(2)} if m.group(2) else {"ref": m.group(1)}, f"{w} traceability", need_quote=False)
        if not re.search(r"(req|work):", tr): ctx.err.append(f"{w}: Traceability cites the PRD or epic lines this use case comes from")
    caps = enable.load(f / "capabilities.json", [])
    for c in caps:
        for n in c.get("needs") or []:
            if n not in allneeds: ctx.err.append(f"capability {c.get('id')}: need {n} is not in any use case")
    if caps and allneeds:
        used = {n for c in caps for n in c.get("needs") or []}
        for n in sorted(allneeds - used): ctx.warn.append(f"need {n} is not yet delivered by any capability (Theo)")
    print(f"{len(files)} use cases, {len(allneeds)} needs. ", end="")
    return report("usecases", ctx)

RT_SECTIONS = ["Use case", "Where it runs", "Sandbox", "Identity and credentials", "Network", "Model access", "Lifecycle", "Evidence",
               "Failure and stop", "Estimates", "Drawing request", "Open questions"]

def runtime(base, feature):
    ctx = enable.Ctx(base); f = ctx.base / feature; d = f / "runtime"
    files = sorted(d.glob("*.md")) if d.is_dir() else []
    if not files: ctx.err.append(f"{feature}/runtime/ has no prototypes")
    for p in files:
        w = f"runtime/{p.name}"; t = p.read_text(encoding="utf-8")
        if not t.lstrip().startswith("# Prototype"): ctx.err.append(f"{w}: the title starts with '# Prototype' (it is imagined, not decided)")
        for s in RT_SECTIONS:
            if not re.search(rf"^##\s+{re.escape(s)}\s*$", t, re.M): ctx.err.append(f"{w}: missing section '## {s}'")
        sec, _ = table(t, "Estimates")
        for l in (sec or "").splitlines():
            if re.search(r"\d", l) and "estimate" not in l.lower() and not l.strip().startswith("|--"): ctx.err.append(f"{w}: Estimates: every number is labelled as an estimate ({l.strip()[:60]!r})")
        _, rows = table(t, "Drawing request")
        if not rows: ctx.err.append(f"{w}: Drawing request has no boxes for the designers to draw")
        for r in rows:
            if r.get("stage", "").lower() not in ("proposed", "imagined"): ctx.err.append(f"{w}: Drawing request: {r.get('box', '?')} must be proposed or imagined, never decided or built")
            if not r.get("box") or not r.get("zone"): ctx.err.append(f"{w}: Drawing request rows need box and zone")
        if not re.search(r"^##\s+Use case\s*$\s*\S", t, re.M): ctx.err.append(f"{w}: Use case: name the use case it prototypes")
    return report("runtime", ctx)

def page_flows(page):
    s = pathlib.Path(page).read_text(encoding="utf-8"); a = s.index("const DIAGRAM = ") + len("const DIAGRAM = ")
    b = s.index("/* ============ 2. VISUAL"); ic = s.find("/* AWS-ICONS:BEGIN", a); b = ic if -1 < ic < b else b
    try: d = json.loads(s[a:b].strip().rstrip(";"))
    except json.JSONDecodeError: sys.exit(f"{page}: its data is not plain JSON; run page.py extract and use the result")
    return d

def edges(base, feature, page=None):
    ctx = enable.Ctx(base); f = ctx.base / feature; E = enable.load(f / "edge-cases.json", None)
    if E is None: ctx.err.append("edge-cases.json is missing"); return report("edges", ctx)
    ids = set()
    for i, e in enumerate(E):
        w = f"edge case {e.get('id', i)}"
        for k in ("id", "usecase", "kind", "scenario", "expected", "severity"):
            if not e.get(k): ctx.err.append(f"{w}: needs {k}")
        if e.get("id") in ids: ctx.err.append(f"{w}: duplicate id")
        ids.add(e.get("id"))
        if e.get("kind") not in ("edge", "failure", "abuse", "policy", "scale", "data", "human"): ctx.err.append(f"{w}: kind must be edge, failure, abuse, policy, scale, data or human")
        if e.get("severity") not in ("high", "medium", "low"): ctx.err.append(f"{w}: severity must be high, medium or low")
        wk = e.get("walked") or {}
        if wk.get("result") not in ("handled", "gap", "question"): ctx.err.append(f"{w}: walked.result must be handled, gap or question (walk it through the design first)")
        if wk.get("result") == "handled" and not wk.get("where"): ctx.err.append(f"{w}: handled: say where in the design (view/box)")
        if wk.get("result") in ("gap", "question") and not (e.get("item_text") and e.get("ask")): ctx.err.append(f"{w}: a gap or question needs item_text and who to ask (ask)")
    if page:
        d = page_flows(page); flows = {fl["id"]: fl for fl in d.get("flows", [])}; names = {fl["name"]: fl["id"] for fl in d.get("flows", [])}
        by = {}
        for e in E:
            u = e.get("usecase"); u = names.get(u, u)
            if u not in flows: ctx.err.append(f"edge case {e.get('id')}: use case {e.get('usecase')!r} is not on the page")
            by.setdefault(u, []).append(e)
        for fid, fl in flows.items():
            es = by.get(fid, [])
            if len(es) < 3: ctx.err.append(f"use case {fl['name']!r}: {len(es)} edge case(s); walk at least three through it")
            elif not any(e["kind"] == "failure" for e in es) or not any(e["kind"] in ("abuse", "policy") for e in es):
                ctx.err.append(f"use case {fl['name']!r}: needs at least one failure case and one abuse or policy case")
            views = {st.get("view") for st in fl.get("steps", [])}
            for e in es:
                for wh in (e.get("walked") or {}).get("where") or []:
                    if wh.split("/")[0] not in {v["id"] for v in d["views"]}: ctx.err.append(f"edge case {e['id']}: walked.where {wh} names a design that is not on the page")
    n = {}
    for e in E: n[(e.get("walked") or {}).get("result")] = n.get((e.get("walked") or {}).get("result"), 0) + 1
    print(f"{len(E)} edge cases: {n.get('handled', 0)} handled, {n.get('gap', 0)} gaps, {n.get('question', 0)} questions. ", end="")
    return report("edges", ctx)

def items(base, feature, page, out):
    f = pathlib.Path(base) / feature; E = enable.load(f / "edge-cases.json", []); d = page_flows(page)
    have = {i["id"] for i in d.get("items", [])}; nums = [int(x[1:]) for x in have if re.fullmatch(r"Q\d+", x)]; nxt = max(nums, default=0) + 1
    edits = []
    for e in E:
        wk = e.get("walked") or {}
        if wk.get("result") not in ("gap", "question") or e.get("page_item"): continue
        kind = "risk" if wk["result"] == "gap" else "question"
        edits.append({"t": "item", "at": datetime.datetime.now().isoformat(timespec="seconds"), "by": "Noor (cyber domain analyst)",
                      "item": {"id": f"Q{nxt}", "kind": kind, "status": "open", "owner": e["ask"], "text": f"{e['item_text']} (edge case {e['id']}: {e['scenario']})",
                               "refs": wk.get("where") or []}})
        nxt += 1
    pathlib.Path(out).write_text(json.dumps({"edits": edits}, indent=1), encoding="utf-8")
    print(f"wrote {len(edits)} item(s) to {out}. Apply with: python3 page.py apply-edits {page} {out}")

def status(base, feature):
    f = pathlib.Path(base) / feature
    rows = [("Uma", "usecases/UC*.md", (f / "usecases").is_dir() and any((f / "usecases").glob("UC*.md"))),
            ("Noor", "edge-cases.json", (f / "edge-cases.json").exists()),
            ("Hana", "inventory.json", (f / "inventory.json").exists()),
            ("Theo", "capabilities, gaps, stories", all((f / x).exists() and enable.load(f / x, []) for x in ("capabilities.json", "stories.json"))),
            ("Ada", "aop/*.md and aop/target.json", (f / "aop").is_dir() and any((f / "aop").glob("*.md"))),
            ("Iris", "evals/map.json", (f / "evals" / "map.json").exists()),
            ("Kai", "runtime/*.md", (f / "runtime").is_dir() and any((f / "runtime").glob("*.md"))),
            ("Theo", "handoff/stories", (f / "handoff" / "stories").is_dir() and any((f / "handoff" / "stories").glob("*.md")))]
    print(f"Feature {feature}:")
    for who, what, done in rows: print(f"  {'done ' if done else 'to do'}  {who:5} {what}")
    nxt = next((r for r in rows if not r[2]), None)
    print("Next: " + (f"{nxt[0]} ({nxt[1]})" if nxt else "run every check, then Vera reviews"))

if __name__ == "__main__":
    a = sys.argv[1:]; opt = lambda k: a[a.index(k) + 1] if k in a else None
    if len(a) == 3 and a[0] == "inventory": inventory(a[1], a[2])
    elif len(a) >= 3 and a[0] == "aop": sys.exit(aop(a[1], a[2], opt("--schema")))
    elif len(a) == 3 and a[0] == "usecases": sys.exit(usecases(a[1], a[2]))
    elif len(a) == 3 and a[0] == "evals": sys.exit(evals(a[1], a[2]))
    elif len(a) == 3 and a[0] == "runtime": sys.exit(runtime(a[1], a[2]))
    elif len(a) >= 3 and a[0] == "edges": sys.exit(edges(a[1], a[2], opt("--page")))
    elif len(a) == 5 and a[0] == "items": items(a[1], a[2], a[3], a[4])
    elif len(a) == 3 and a[0] == "status": status(a[1], a[2])
    else: print(__doc__); sys.exit(2)
