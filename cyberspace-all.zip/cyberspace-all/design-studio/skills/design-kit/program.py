#!/usr/bin/env python3
"""The program check: is everything we are working on pointed at what the owner asked for?

  python3 program.py check <program-dir>                              check the charter (program/charter.md)
  python3 program.py drift <program-dir> <project-dir> [--page p.html] check the work against the charter: every use case
                                                                      traces to a goal, nothing works on a non-goal, every
                                                                      story traces back to a goal, decisions cited exist and
                                                                      are decided, open decisions are not overdue, goals
                                                                      have work, and every reading scope has been read
  python3 program.py report <program-dir> <project-dir> [--page p.html] write program/report.md: direction, by goal
  python3 program.py context <program-dir> <project-dir>              a short briefing for the start of every session
                                                                      (Claude Code SessionStart hook prints it into context)

The charter format and the program lead's method are in references/program.md.
"""
import sys, re, json, pathlib, datetime, subprocess
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

SECTIONS = ["North star", "Goals", "Non-goals", "Decisions", "Open decisions", "Priorities", "Guardrails"]

def fm_body(p):
    t = p.read_text(encoding="utf-8"); lines = t.splitlines()
    if not lines or lines[0].strip() != "---": return {}, t
    end = next((i for i, l in enumerate(lines[1:], 1) if l.strip() == "---"), 0)
    import yaml
    try: fm = yaml.safe_load("\n".join(lines[1:end])) or {}
    except Exception: fm = {}
    return (fm if isinstance(fm, dict) else {}), "\n".join(lines[end + 1:])

def section(body, h):
    m = re.search(rf"^##\s+{re.escape(h)}\s*$(.*?)(?=^##\s|\Z)", body, re.S | re.M); return m.group(1) if m else None

def rows(text):
    ls = [l.strip() for l in (text or "").splitlines() if l.strip().startswith("|")]
    if len(ls) < 2: return []
    cells = lambda l: [c.strip() for c in l.strip().strip("|").split("|")]
    head = [h.lower() for h in cells(ls[0])]
    return [dict(zip(head, cells(r))) for r in ls[2:] if not re.fullmatch(r"[\s|:-]*", r)]

class R:
    def __init__(self): self.err, self.warn = [], []
    def out(self, name):
        for m in self.err: print("PROBLEM:", m)
        for m in self.warn: print("warning:", m)
        print(f"{name}: Problems: {len(self.err)}   Warnings: {len(self.warn)}"); return 1 if self.err else 0

def load_charter(pdir, r):
    p = pathlib.Path(pdir) / "charter.md"
    if not p.exists(): r.err.append(f"{p} is missing: the program has no charter, so nobody can say whether work is on course"); return None
    fm, body = fm_body(p)
    for k in ("program", "status", "owner", "updated"):
        if not fm.get(k): r.err.append(f"charter: frontmatter needs {k}")
    if fm.get("status") not in ("draft", "agreed"): r.err.append("charter: status is draft or agreed (agreed only when the owner has said so)")
    for s in SECTIONS:
        if section(body, s) is None: r.err.append(f"charter: missing section '## {s}'")
    G = {x.get("id"): x for x in rows(section(body, "Goals"))}; NG = {x.get("id"): x for x in rows(section(body, "Non-goals"))}
    D = {x.get("id"): x for x in rows(section(body, "Decisions"))}; OD = {x.get("id"): x for x in rows(section(body, "Open decisions"))}
    if not G: r.err.append("charter: no goals")
    for k, g in G.items():
        if not re.fullmatch(r"G\d+", k or ""): r.err.append(f"charter: goal id {k!r} must look like G1")
        if not g.get("measure") or g["measure"] == "-": r.err.append(f"charter: goal {k} has no measure (how we will know it is met)")
        if not g.get("source") or g["source"] == "-": r.err.append(f"charter: goal {k} has no source (where the owner said it)")
    for k, d in D.items():
        if not d.get("decided by") or not d.get("date") or d["decided by"] in ("-", "") : r.err.append(f"charter: decision {k} needs who decided it and when; an undecided one belongs in Open decisions")
    for k, o in OD.items():
        if not o.get("who decides") or o["who decides"] == "-": r.err.append(f"charter: open decision {k} needs who decides")
    pr = section(body, "Priorities") or ""
    for g in re.findall(r"\bG\d+\b", pr):
        if g not in G: r.err.append(f"charter: priorities name {g}, which is not a goal")
    if G and not re.search(r"\bG\d+\b", pr): r.err.append("charter: priorities must order the goals (G1, G3, ...)")
    try:
        age = (datetime.date.today() - datetime.date.fromisoformat(str(fm.get("updated")))).days
        if age > 30: r.warn.append(f"charter: last updated {age} days ago; re-confirm it with the owner")
    except ValueError: r.err.append("charter: updated must be a date (YYYY-MM-DD)")
    return {"fm": fm, "body": body, "G": G, "NG": NG, "D": D, "OD": OD, "priority": re.findall(r"\bG\d+\b", pr)}

def check(pdir):
    r = R(); load_charter(pdir, r); return r.out("charter")

def gather(proj):
    proj = pathlib.Path(proj); ag = proj / "agentic"; feats = {}
    if ag.is_dir():
        for f in sorted(x for x in ag.iterdir() if x.is_dir() and x.name != "harness-inventory"):
            ucs = {}
            for u in sorted((f / "usecases").glob("UC*.md")) if (f / "usecases").is_dir() else []:
                fm, body = fm_body(u); ucs[fm.get("id", u.stem)] = {"fm": fm, "file": u}
            caps = json.loads((f / "capabilities.json").read_text()) if (f / "capabilities.json").exists() else []
            stories = json.loads((f / "stories.json").read_text()) if (f / "stories.json").exists() else []
            feats[f.name] = {"ucs": ucs, "caps": caps, "stories": stories}
    return feats

def drift(pdir, proj, page=None, quiet=False):
    r = R(); C = load_charter(pdir, r)
    if C is None: return r.out("drift") if not quiet else r
    feats = gather(proj); per_goal = {g: 0 for g in C["G"]}
    for fn, F in feats.items():
        uc_goals = {}
        for uid, u in F["ucs"].items():
            gs = u["fm"].get("goals") or []; uc_goals[uid] = gs
            if not gs: r.err.append(f"{fn}/{uid}: traces to no goal (frontmatter goals: [G1]); either it serves a goal or it should not be worked on")
            for g in gs:
                if g in C["NG"]: r.err.append(f"{fn}/{uid}: names {g}, which is a NON-goal: stop and ask the owner")
                elif g not in C["G"]: r.err.append(f"{fn}/{uid}: names goal {g}, which the charter does not have")
                else: per_goal[g] += 1
            for ng in u["fm"].get("nongoals_touched") or []:
                r.err.append(f"{fn}/{uid}: touches non-goal {ng}: stop and ask the owner before more work")
            for d in u["fm"].get("decisions") or []:
                if d not in C["D"]: r.err.append(f"{fn}/{uid}: rests on decision {d}, which is not in the charter's decisions" + (" (it is still open)" if d in C["OD"] else ""))
        need_uc = lambda n: n.split(".")[0]
        cap_goals = {c.get("id"): {g for n in c.get("needs") or [] for g in uc_goals.get(need_uc(n), [])} for c in F["caps"]}
        for c in F["caps"]:
            if F["ucs"] and not cap_goals.get(c.get("id")): r.err.append(f"{fn}/{c.get('id')}: capability traces to no goal through its needs")
        for s in F["stories"]:
            gs = set().union(*[cap_goals.get(x, set()) for x in s.get("capabilities") or []]) if s.get("capabilities") else set()
            if F["ucs"] and not gs: r.err.append(f"{fn}/{s.get('id')}: story '{s.get('title')}' traces to no goal")
    if page:
        s = pathlib.Path(page).read_text(encoding="utf-8")
        for d in set(re.findall(r'"decided by (?:the owner|owner)[^"]*?\b(D\d+)', s)):
            if d not in C["D"]: r.err.append(f"design page says {d} is decided, but the charter does not list it as decided")
    today = datetime.date.today()
    for k, o in C["OD"].items():
        try:
            if datetime.date.fromisoformat(o.get("needed by", "")) < today: r.err.append(f"open decision {k} was needed by {o['needed by']} and is still open: escalate to {o.get('who decides')}")
        except ValueError: pass
    if feats:
        for g in C["G"]:
            if per_goal.get(g, 0) == 0: r.warn.append(f"goal {g} ({C['G'][g].get('goal', '')[:50]}) has no use case working on it")
        pr = [g for g in C["priority"] if g in per_goal]
        for a, b in zip(pr, pr[1:]):
            if per_goal[a] == 0 and per_goal[b] > 0: r.warn.append(f"priority {a} has no work while lower priority {b} has {per_goal[b]} use case(s)")
    rg = pathlib.Path(__file__).resolve().parent / "readgate.py"
    base = pathlib.Path(proj) / "reading"
    scopes = sorted(x.name for x in base.iterdir() if (x / "scope.json").exists()) if base.exists() else []
    if not scopes: r.err.append("no reading scope: nobody has declared, or proved, reading the sources (readgate.py init)")
    for sc in scopes:
        readers = [x.stem for x in (base / sc).glob("*.json") if x.name != "scope.json"]
        ok = [rd for rd in readers if subprocess.run([sys.executable, str(rg), "check", str(proj), sc, rd], capture_output=True).returncode == 0]
        if not ok: r.err.append(f"reading scope {sc}: nobody has read it in full; work built on it is not trustworthy yet")
    r.per_goal = per_goal; r.C = C; r.feats = feats; r.scopes = scopes
    return r if quiet else r.out("drift")

def report(pdir, proj, page=None):
    r = drift(pdir, proj, page, quiet=True)
    if getattr(r, "C", None) is None: return r.out("report")
    C = r.C; L = [f"# Program report: {C['fm'].get('program')}", "", f"{datetime.date.today().isoformat()}. Charter {C['fm'].get('status')}, updated {C['fm'].get('updated')}.", "",
                  "## Direction", "", ("On course: no problems." if not r.err else f"{len(r.err)} problem(s) pulling the work off course:"), ""]
    L += [f"- {m}" for m in r.err] + ([""] if r.err else [])
    if r.warn: L += ["Watch:", ""] + [f"- {m}" for m in r.warn] + [""]
    L += ["## Work by goal (in priority order)", "", "| Goal | Measure | Use cases |", "|---|---|---|"]
    order = C["priority"] + [g for g in C["G"] if g not in C["priority"]]
    for g in order:
        if g in C["G"]: L.append(f"| {g} {C['G'][g].get('goal', '')} | {C['G'][g].get('measure', '')} | {r.per_goal.get(g, 0)} |")
    L += ["", "## Open decisions", "", "| Id | Question | Who decides | Needed by |", "|---|---|---|---|"]
    L += [f"| {k} | {o.get('question', '')} | {o.get('who decides', '')} | {o.get('needed by', '')} |" for k, o in C["OD"].items()]
    L += ["", "## Features", ""] + [f"- {fn}: {len(F['ucs'])} use cases, {len(F['caps'])} capabilities, {len(F['stories'])} stories" for fn, F in r.feats.items()]
    out = pathlib.Path(pdir) / "report.md"; out.write_text("\n".join(L) + "\n", encoding="utf-8"); print(f"wrote {out}"); return 1 if r.err else 0

def context(pdir, proj):
    r = R(); C = load_charter(pdir, r)
    if C is None: print("CYBERSPACE PROGRAM: there is no charter (program/charter.md). Ask the program lead (Sage) to set one up before starting work."); return 0
    lines = [f"CYBERSPACE PROGRAM BRIEFING ({C['fm'].get('status')} charter, updated {C['fm'].get('updated')})",
             "North star: " + " ".join((section(C["body"], "North star") or "").split())[:400],
             "Goals in priority order: " + "; ".join(f"{g} {C['G'][g].get('goal', '')}" for g in C["priority"] if g in C["G"]),
             "Not doing: " + ("; ".join(f"{k} {v.get('not doing', '')}" for k, v in C["NG"].items()) or "none listed"),
             "Open decisions (do not treat as decided): " + ("; ".join(f"{k} {v.get('question', '')} (decides: {v.get('who decides', '')})" for k, v in C["OD"].items()) or "none"),
             "Rules: read every source in full before any work (the reading gate blocks writes until you have); trace every piece of work to a goal; never draw or write an open decision as decided."]
    d = drift(pdir, proj, quiet=True)
    lines.append("Direction now: " + ("on course." if not d.err else f"{len(d.err)} problem(s), first: {d.err[0]}"))
    print("\n".join(lines)); return 0

if __name__ == "__main__":
    a = sys.argv[1:]; opt = lambda k: a[a.index(k) + 1] if k in a else None
    if len(a) == 2 and a[0] == "check": sys.exit(check(a[1]))
    elif len(a) >= 3 and a[0] == "drift": sys.exit(drift(a[1], a[2], opt("--page")))
    elif len(a) >= 3 and a[0] == "report": sys.exit(report(a[1], a[2], opt("--page")))
    elif len(a) == 3 and a[0] == "context": sys.exit(context(a[1], a[2]))
    else: print(__doc__); sys.exit(2)
