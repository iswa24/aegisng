---
program: Triage
status: draft
owner: Head of cyber operations
updated: 2026-11-25
---

## North star
A lead sees a severity proposal for every new ticket, and nothing changes on a ticket without a named approver.

## Goals
| Id | Goal | Measure | Source |
|---|---|---|---|
| G1 | Propose a severity for every new ticket | 95% within 5 minutes | req/prd.md:5 |
| G2 | Keep tickets for the policy period | every ticket kept as long as its class requires | req/policy.md:3 |

## Non-goals
| Id | Not doing | Why | Source |
|---|---|---|---|
| NG1 | Closing tickets automatically | a person closes tickets | asked the owner, 2026-11-20 |

## Decisions
| Id | Decision | Decided by | Date | Source |
|---|---|---|---|---|
| D1 | Every ticket change needs a lead's approval | Owner | 2026-11-20 | req/prd.md:4 |

## Open decisions
| Id | Question | Who decides | Needed by |
|---|---|---|---|
| OD1 | How long is the approval window? | Security / SecOps | 2099-01-01 |

## Priorities
1. G1
2. G2

## Guardrails
- Nothing undecided is written or drawn as decided.
