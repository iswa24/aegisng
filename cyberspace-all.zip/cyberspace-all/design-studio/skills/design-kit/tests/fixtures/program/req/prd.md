# Ticket triage agent

The agent reads new tickets and proposes a severity.
A lead must approve any change to a ticket before it is made.
Proposals are ready within 5 minutes of a ticket arriving.
