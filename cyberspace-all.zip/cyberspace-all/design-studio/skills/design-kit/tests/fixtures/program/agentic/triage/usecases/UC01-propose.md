---
id: UC01
title: Propose a severity
status: draft
level: user-goal
goals: [G1]
decisions: [D1]
---
## Goal
A lead gets a proposal for every new ticket.
