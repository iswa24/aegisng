An invented program, used only to test program.py and readgate.py. None of it describes a real system.
