# Tools at the firm

Every tool that changes something outside the agent
must be registered with confirm=True.
