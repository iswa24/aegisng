# Design brief: triage
## What the feature does
Proposes ticket severity; ticket changes need a lead.
## Blockers
G01: draw the approval resume as proposed until CR01 lands.
