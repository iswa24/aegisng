An invented SmartSDK, harness, requirement and firm guide, used only to test enable.py. None of it describes a real system.
