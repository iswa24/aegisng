"""Tool registry. Applications register tools here; raw ADK tools are not exposed."""


class ToolRegistry:
    def __init__(self):
        self._tools = {}

    def register_tool(self, fn, *, confirm=False):
        """Register a tool. confirm=True asks a person before the tool runs, in the same process."""
        self._tools[fn.__name__] = (fn, confirm)
        return fn

    # Resuming a paused run from another process is not supported.
