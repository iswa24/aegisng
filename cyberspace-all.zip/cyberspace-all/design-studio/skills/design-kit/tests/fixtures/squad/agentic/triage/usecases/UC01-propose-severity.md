---
id: UC01
title: Propose a severity for a new ticket
status: draft
level: user-goal
---

## Goal
A lead gets a severity proposal for every new ticket, and nothing changes on a ticket without the lead's approval.

## Primary actor
Cyber lead

## Stakeholders and interests
- Cyber lead: wants proposals quickly and stays in control of changes.
- Ticket owner: wants a fair severity.

## Trigger
A new ticket arrives in the queue.

## Preconditions
- The agent can read the ticket queue.

## Main success scenario
1. Platform: hands the new ticket to the triage agent.
2. Triage agent: reads the ticket and proposes a severity with a reason.
3. Triage agent: asks to set the severity on the ticket.
4. Cyber lead: approves the change.
5. Platform: applies the change and records who approved it.

## Extensions
3a. The proposal needs no change to the ticket: the agent records the proposal only.
4a. The lead rejects the change: the ticket is not changed and the rejection is recorded.
4b. The lead does not answer within the approval window: the request fails closed and nothing changes.

## Business rules
- No ticket changes without a named approver.

## Needs
| Id | Need | Acceptance | Priority | Source |
|---|---|---|---|---|
| UC01.N1 | Pause before a ticket change until a lead approves | No ticket changes before approval; approval resumes the run | must | req:prd.md:4 |
| UC01.N2 | A proposal for each new ticket within 5 minutes | 95% of proposals within 5 minutes of arrival | should | req:prd.md:5 |

## Success guarantees
- Every change has an approver on record.

## Out of scope
- Bulk approvals.

## Open questions
- How long is the approval window? Ask: Security / SecOps.

## Traceability
- `req:prd.md:4` — "A lead must approve any change to a ticket"
- `req:prd.md:5`
