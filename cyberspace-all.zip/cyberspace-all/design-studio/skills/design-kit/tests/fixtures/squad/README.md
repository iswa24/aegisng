An invented SmartSDK, harness, requirement, firm guide and design page, used only to test squad.py and enable.py together. None of it describes a real system.
