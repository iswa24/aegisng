"""Agents. An application builds one SmartAgent per job."""


class SmartAgent:
    def __init__(self, name, instructions, tools, model="firm-default"):
        self.name, self.instructions, self.tools, self.model = name, instructions, tools, model
