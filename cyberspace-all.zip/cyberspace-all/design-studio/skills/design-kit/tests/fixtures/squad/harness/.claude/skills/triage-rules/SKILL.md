---
name: triage-rules
description: How to grade ticket severity
---
Severity is high when customer data is involved.
