"""Agent evaluation. Eval sets are JSON files with a list of cases; run with: smartsdk eval <agent> <evalset.json>."""


def load_evalset(path):
    """An eval set is {"eval_set_id": ..., "cases": [{"case_id": ..., "input": ..., "expected": ...}]}"""
    import json
    return json.load(open(path))
