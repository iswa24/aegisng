# Ticket triage

## Rules
Never change a ticket without a lead's approval.

## Output
Write a severity proposal for each new ticket.
