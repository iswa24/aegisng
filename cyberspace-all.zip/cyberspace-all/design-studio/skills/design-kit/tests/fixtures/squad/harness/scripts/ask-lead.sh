#!/bin/sh
echo "ask the lead"
