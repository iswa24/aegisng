"""Agent procedures. SmartSDK loads a procedure file and passes its body to the agent as instructions."""

PROCEDURE_REQUIRED = ["id", "version", "owner"]
