# Prototype: propose a severity (imagined)

## Use case
UC01, Propose a severity for a new ticket.

## Where it runs
A container task per ticket, in the build plane's lab account (proposed).

## Sandbox
No shell; only the registered tools read_ticket and update_ticket.

## Identity and credentials
A task identity scoped to one ticket, expiring with the task.

## Network
Egress only to the ticket API and the model route.

## Model access
Through the firm model route.

## Lifecycle
Start on ticket arrival; stop after the proposal or the approval window.

## Evidence
Proposal and approval record to the evidence store.

## Failure and stop
Budget and time limits enforced by the platform; the approval fails closed.

## Estimates
- Start time: about 30 seconds (estimate).
- Cost per ticket: under one cent of compute (estimate).

## Drawing request
| Box | Kind | Zone | Stage |
|---|---|---|---|
| Triage task | service | Lab account | proposed |
| Ticket API | external | Firm | proposed |
| Model route | service | Firm | imagined |

## Open questions
- Which account hosts lab agents? Ask: Platform engineers.
