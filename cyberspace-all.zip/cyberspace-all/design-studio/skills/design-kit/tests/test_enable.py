"""Tests for enable.py: the clean worked example passes, and each planted mistake is caught."""
import json, shutil, subprocess, sys, tempfile, pathlib

KIT = pathlib.Path(__file__).resolve().parent.parent
FIX = pathlib.Path(__file__).resolve().parent / "fixtures" / "enable"

def run(*a):
    r = subprocess.run([sys.executable, str(KIT / "enable.py"), *map(str, a)], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr

def main():
    passed, fails = 0, []
    def ok(name, cond, detail=""):
        nonlocal passed
        if cond: passed += 1
        else: fails.append(name); print("FAIL:", name, detail[-400:])
    with tempfile.TemporaryDirectory() as tmp:
        def fresh():
            d = pathlib.Path(tmp) / "x"
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(FIX, d); shutil.rmtree(d / "agentic" / "triage" / "handoff" / "stories", ignore_errors=True)
            (d / "agentic" / "triage" / "handoff" / "stories").mkdir(); return d / "agentic"
        def edit(ag, name, fn):
            p = ag / "triage" / name; data = json.loads(p.read_text()); fn(data); p.write_text(json.dumps(data))
        ag = fresh(); code, out = run("check", ag, "triage")
        ok("the worked example passes the check", code == 0 and "Problems: 0" in out, out)
        code, out = run("render", ag, "triage"); st = list((ag / "triage" / "handoff" / "stories").glob("*.md"))
        txt = st[0].read_text() if st else ""
        ok("render writes one story file in BMad format with the cited SmartSDK API and the firm rule",
           len(st) == 1 and "## Acceptance Criteria" in txt and "registry.py:8" in txt and "P01" in txt and "CR01" in txt and "## Dev Agent Record" in txt, out)
        ok("render writes the enablement report", (ag / "triage" / "handoff" / "enablement-report.md").exists())
        cases = [
          ("a quote that is not in the cited lines", "capabilities.json", lambda d: d[0]["smartsdk"]["cites"][0].update(quote="def register_tool(self, fn, *, confirm=True)"), "is not in those lines"),
          ("a cited file that does not exist", "capabilities.json", lambda d: d[0]["smartsdk"]["cites"][0].update(ref="smartsdk:src/smartsdk/agents.py:1"), "no such file"),
          ("cited lines outside the file", "capabilities.json", lambda d: d[0]["smartsdk"]["cites"][0].update(ref="smartsdk:src/smartsdk/tools/registry.py:80-90"), "outside the file"),
          ("a citation that escapes its root", "capabilities.json", lambda d: d[0]["from_req"].update(ref="req:../smartsdk/pyproject.toml:1", quote="[project]"), "points outside"),
          ("a SmartSDK claim with no quote", "capabilities.json", lambda d: d[0]["smartsdk"]["cites"][0].pop("quote"), "add the quote"),
          ("'exposed' with no SmartSDK citation", "capabilities.json", lambda d: d[0]["smartsdk"].update(status="exposed", cites=[]), "cite the SmartSDK source"),
          ("an unknown status with no question", "capabilities.json", lambda d: d[0]["smartsdk"].update(status="unknown", cites=[]), "needs a question"),
          ("a capability SmartSDK lacks that no gap covers", "gaps.json", lambda d: d.clear(), "no gap covers it"),
          ("an extend gap with no change request", "gaps.json", lambda d: d[0].pop("change_request"), "needs a change_request"),
          ("a ladder step outside 1 to 5", "gaps.json", lambda d: d[0].update(ladder=7), "ladder is 1 to 5"),
          ("a story that needs a blocked capability without depending on its change request", "stories.json", lambda d: d[0].update(depends_on=[]), "add CR01 to depends_on"),
          ("an acceptance criterion without 'then'", "stories.json", lambda d: d[0]["acceptance"][0].pop("then"), "needs given, when and then"),
          ("a story too big for one session", "stories.json", lambda d: d[0].update(fits_one_session=False), "fits_one_session"),
          ("a story with no SmartSDK APIs and no reason", "stories.json", lambda d: d[0].pop("smartsdk_apis"), "smartsdk_apis"),
          ("a dependency cycle between stories", "stories.json", lambda d: d.extend([dict(d[0], id="S02", depends_on=["CR01", "S03"]), dict(d[0], id="S03", depends_on=["CR01", "S02"])]), "depends on itself"),
          ("a playbook rule used but not defined", "capabilities.json", lambda d: d[0].update(playbook=["P09"]), "P09 does not exist"),
        ]
        for name, f, fn, expect in cases:
            ag = fresh(); edit(ag, f, fn); code, out = run("check", ag, "triage")
            ok("caught: " + name, code == 1 and expect in out, out)
        ag = fresh(); p = ag / "playbook.json"; pb = json.loads(p.read_text()); pb.append({"id": "P02", "status": "proposed", "rule": "x"}); p.write_text(json.dumps(pb))
        code, out = run("check", ag, "triage"); ok("caught: a proposed playbook rule that does not say where it was learned", code == 1 and "learned from" in out, out)
        ag = fresh(); p = ag / "playbook.json"; pb = json.loads(p.read_text()); pb[0]["cites"] = []; p.write_text(json.dumps(pb))
        code, out = run("check", ag, "triage"); ok("caught: a confirmed firm rule with no source", code == 1 and "cites where the firm says it" in out, out)
        ag = fresh(); cr = ag / "triage" / "change-requests" / "CR01.md"; cr.write_text(cr.read_text().replace("## Alternatives", "## Other"))
        code, out = run("check", ag, "triage"); ok("caught: a change request missing a section", code == 1 and "missing section '## Alternatives'" in out, out)
        ag = fresh(); b = ag / "triage" / "handoff" / "design-brief.md"; b.write_text(b.read_text().replace("G01", "the blocker"))
        code, out = run("check", ag, "triage"); ok("caught: a design brief that leaves out a blocker", code == 1 and "does not mention blocker G01" in out, out)
        ag = fresh(); edit(ag, "capabilities.json", lambda d: d[0]["smartsdk"]["cites"][0].update(quote="nope"))
        code, out = run("render", ag, "triage"); ok("render refuses while the check finds problems", code != 0 and "Not rendered" in out and not list((ag / "triage" / "handoff" / "stories").glob("*.md")), out)
        d = pathlib.Path(tmp) / "new"; code, out = run("init", d, "feat")
        ok("init creates the registers and a stub brief", code == 0 and (d / "sources.json").exists() and (d / "feat" / "capabilities.json").exists() and "TODO" in (d / "feat" / "handoff" / "design-brief.md").read_text(), out)
    print(f"enable: {passed} passed, {len(fails)} failed")
    return passed, fails

if __name__ == "__main__":
    p, f = main(); sys.exit(1 if f else 0)
