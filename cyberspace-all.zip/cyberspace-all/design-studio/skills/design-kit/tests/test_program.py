"""Tests for program.py (direction) and readgate.py (read everything first): the example passes, each planted mistake is caught."""
import json, shutil, subprocess, sys, tempfile, pathlib, hashlib

KIT = pathlib.Path(__file__).resolve().parent.parent
FIX = pathlib.Path(__file__).resolve().parent / "fixtures" / "program"

def run(tool, *a, stdin=None):
    r = subprocess.run([sys.executable, str(KIT / tool), *map(str, a)], capture_output=True, text=True, input=stdin)
    return r.returncode, r.stdout + r.stderr

def main():
    passed, fails = 0, []
    def ok(name, cond, detail=""):
        nonlocal passed
        if cond: passed += 1
        else: fails.append(name); print("FAIL:", name, detail[-500:])
    with tempfile.TemporaryDirectory() as tmp:
        def fresh():
            d = pathlib.Path(tmp) / "x"
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(FIX, d); return d
        def log(d): return d / "reading" / "sources" / "sage.json"
        def edit_log(d, fn):
            p = log(d); L = json.loads(p.read_text()); fn(L); p.write_text(json.dumps(L))
        def edit(d, rel, old, new):
            p = d / rel; t = p.read_text(); assert old in t, (rel, old); p.write_text(t.replace(old, new, 1))
        hook = lambda d, path, tool="Write": run("readgate.py", "hook", d, stdin=json.dumps({"tool_name": tool, "tool_input": {"file_path": str(d / path)}}))
        d = fresh()
        code, out = run("readgate.py", "check", d, "sources", "sage"); ok("a full reading passes the gate", code == 0 and "PASSED" in out, out)
        code, out = run("program.py", "check", d / "program"); ok("the example charter passes", code == 0, out)
        code, out = run("program.py", "drift", d / "program", d); ok("the example is on course", code == 0, out)
        ok("drift notices a goal with no work", "G2" in out and "no use case" in out, out)
        code, out = run("program.py", "context", d / "program", d)
        ok("the session briefing gives the north star, goals in order, non-goals and open decisions",
           code == 0 and "North star: A lead sees" in out and "G1 Propose" in out and "NG1" in out and "OD1" in out and "Direction now: on course" in out, out)
        code, out = run("program.py", "report", d / "program", d); ok("the report is written", code == 0 and (d / "program" / "report.md").exists() and "Work by goal" in (d / "program" / "report.md").read_text(), out)
        code, out = hook(d, "design/page.html"); ok("the hook lets a write through once everything is read", code == 0, out)
        reading = [
          ("a file not read at all", lambda d: edit_log(d, lambda L: L["files"].pop(1)), "not read: req/policy.md"),
          ("a file changed since it was read", lambda d: edit(d, "req/prd.md", "5 minutes", "10 minutes"), "changed since"),
          ("a quote that is not on its line", lambda d: edit_log(d, lambda L: L["files"][0]["quotes"][0].update(line=4)), "does not contain"),
          ("a part of a long file never quoted (read only the top)", lambda d: edit_log(d, lambda L: L["files"][1]["quotes"].pop(2)), "no quote from lines 241-260"),
          ("a summary too short to show understanding", lambda d: edit_log(d, lambda L: L["files"][0].update(summary="Triage requirements.")), "at least 25"),
          ("a quote too short to prove anything", lambda d: edit_log(d, lambda L: L["files"][0]["quotes"][0].update(quote="The")), "too short"),
          ("a new file added to the scope after reading", lambda d: (d / "req" / "new.md").write_text("# New requirement\nAgents must log every tool call.\n"), "not read: req/new.md"),
        ]
        for name, fn, expect in reading:
            d = fresh(); fn(d); code, out = run("readgate.py", "check", d, "sources", "sage")
            ok("gate catches: " + name, code == 1 and expect in out, out)
        d = fresh(); (d / "req" / "spec.pdf").write_bytes(b"%PDF-1.4")
        code, out = run("readgate.py", "check", d, "sources", "sage"); ok("gate catches: a PDF that was never converted to text", code == 1 and "convert it" in out, out)
        d = fresh(); edit_log(d, lambda L: L["files"].pop(1))
        code, out = hook(d, "design/page.html"); ok("the hook blocks writing to design/ while a scope is unread", code == 2 and "reading gate" in out, out)
        code, out = hook(d, "agentic/triage/stories.json", "Edit"); ok("the hook blocks edits to agentic/ too", code == 2, out)
        code, out = hook(d, "reading/sources/sage.json"); ok("the hook never blocks writing the reading log itself", code == 0, out)
        code, out = hook(d, "notes/scratch.md"); ok("the hook leaves files outside the guarded folders alone", code == 0, out)
        code, out = run("readgate.py", "hook", d, stdin=json.dumps({"tool_name": "Read", "tool_input": {"file_path": str(d / "design/x")}})); ok("the hook never blocks reading", code == 0, out)
        d = fresh(); shutil.rmtree(d / "reading"); code, out = hook(d, "design/page.html"); ok("the hook blocks when nobody has declared what to read", code == 2 and "nothing has been read" in out, out)
        program = [
          ("a use case that traces to no goal", lambda d: edit(d, "agentic/triage/usecases/UC01-propose.md", "goals: [G1]", "goals: []"), "traces to no goal"),
          ("work on a non-goal", lambda d: edit(d, "agentic/triage/usecases/UC01-propose.md", "goals: [G1]", "goals: [NG1]"), "NON-goal"),
          ("a use case resting on an undecided decision", lambda d: edit(d, "agentic/triage/usecases/UC01-propose.md", "decisions: [D1]", "decisions: [OD1]"), "still open"),
          ("a story that traces to no goal", lambda d: edit(d, "agentic/triage/stories.json", '"capabilities": ["C01"]', '"capabilities": []'), "traces to no goal"),
          ("an overdue open decision", lambda d: edit(d, "program/charter.md", "| 2099-01-01 |", "| 2020-01-01 |"), "needed by 2020-01-01"),
          ("nobody has read the sources", lambda d: edit_log(d, lambda L: L["files"].pop(0)), "nobody has read it in full"),
        ]
        for name, fn, expect in program:
            d = fresh(); fn(d); code, out = run("program.py", "drift", d / "program", d)
            ok("drift catches: " + name, code == 1 and expect in out, out)
        charter = [
          ("a goal with no measure", ("| 95% within 5 minutes |", "| - |"), "no measure"),
          ("a decision with nobody who decided it", ("| Owner | 2026-11-20 |", "| - | 2026-11-20 |"), "needs who decided"),
          ("priorities that name no goal", ("1. G1\n2. G2", "1. Speed"), "must order the goals"),
          ("a missing section", ("## Guardrails", "## Notes"), "Guardrails"),
        ]
        for name, (old, new), expect in charter:
            d = fresh(); edit(d, "program/charter.md", old, new); code, out = run("program.py", "check", d / "program")
            ok("charter check catches: " + name, code == 1 and expect in out, out)
        d = fresh(); (d / "program" / "charter.md").unlink(); code, out = run("program.py", "context", d / "program", d)
        ok("with no charter, the briefing says to set one up first", "no charter" in out, out)
    print(f"program: {passed} passed, {len(fails)} failed")
    return passed, fails

if __name__ == "__main__":
    p, f = main(); sys.exit(1 if f else 0)
