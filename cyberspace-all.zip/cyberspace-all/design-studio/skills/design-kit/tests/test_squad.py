"""Tests for squad.py and the squad's hooks in enable.py: the worked example passes, and each planted mistake is caught."""
import json, re, shutil, subprocess, sys, tempfile, pathlib

KIT = pathlib.Path(__file__).resolve().parent.parent
FIX = pathlib.Path(__file__).resolve().parent / "fixtures" / "squad"

def run(tool, *a):
    r = subprocess.run([sys.executable, str(KIT / tool), *map(str, a)], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr

def main():
    passed, fails = 0, []
    def ok(name, cond, detail=""):
        nonlocal passed
        if cond: passed += 1
        else: fails.append(name); print("FAIL:", name, detail[-500:])
    with tempfile.TemporaryDirectory() as tmp:
        def fresh():
            d = pathlib.Path(tmp) / "x"
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(FIX, d); return d
        def edit_json(d, name, fn):
            p = d / "agentic" / "triage" / name; data = json.loads(p.read_text()); fn(data); p.write_text(json.dumps(data))
        def edit_text(d, name, old, new):
            p = d / "agentic" / "triage" / name; t = p.read_text(); assert old in t, (name, old); p.write_text(t.replace(old, new, 1))
        d = fresh(); ag = d / "agentic"
        for tool, cmd in [("squad.py", "usecases"), ("squad.py", "aop"), ("squad.py", "evals"), ("squad.py", "runtime"), ("enable.py", "check")]:
            code, out = run(tool, cmd, ag, "triage"); ok(f"the worked example passes {cmd}", code == 0 and "Problems: 0" in out, out)
        code, out = run("squad.py", "edges", ag, "triage", "--page", d / "page.html"); ok("the worked example passes edges against the page", code == 0 and "Problems: 0" in out, out)
        # Hana: the inventory finds every kind of construct, each cited to a line that holds its quote
        code, out = run("squad.py", "inventory", d / "harness", d / "inv.json"); inv = json.loads((d / "inv.json").read_text())
        kinds = {c["kind"] for c in inv["constructs"]}
        ok("inventory finds subagents, skills, hooks, permissions, instructions, scripts and implicit behaviours",
           {"subagent", "skill", "hook", "permission", "instruction", "script", "implicit"} <= kinds, str(kinds))
        bad = []
        for c in inv["constructs"]:
            if "cite" in c:
                _, path, line = c["cite"]["ref"].split(":"); txt = (d / "harness" / path).read_text().splitlines()[int(line) - 1]
                if c["cite"]["quote"] not in txt: bad.append(c["id"])
        ok("every inventory citation points at the line that holds its quote", not bad, str(bad))
        ok("inventory lists the built-in tools the harness relies on", any(c["name"] == "built-in tool Read" for c in inv["constructs"]))
        ok("inventory matches the example's saved inventory", [c["name"] for c in inv["constructs"]] == [c["name"] for c in json.loads((ag / "triage" / "inventory.json").read_text())["constructs"]])
        cases = [
          # (name, tool, cmd, mutate(d), expected text)
          ("Uma: a need with a vague word and no number", "squad.py", "usecases", lambda d: edit_text(d, "usecases/UC01-propose-severity.md", "| Pause before a ticket change until a lead approves | No ticket changes before approval; approval resumes the run |", "| A fast and seamless pause before a ticket change | It feels quick |"), "vague word"),
          ("Uma: a step with no actor", "squad.py", "usecases", lambda d: edit_text(d, "usecases/UC01-propose-severity.md", "2. Triage agent: reads", "2. Reads"), "'Actor: does something'"),
          ("Uma: an extension pointing at a step that does not exist", "squad.py", "usecases", lambda d: edit_text(d, "usecases/UC01-propose-severity.md", "4b.", "9b."), "points at step 9"),
          ("Uma: a need with no source", "squad.py", "usecases", lambda d: edit_text(d, "usecases/UC01-propose-severity.md", "| should | req:prd.md:5 |", "| should | - |"), "source cites the requirement"),
          ("Uma: a traceability quote not in the PRD", "squad.py", "usecases", lambda d: edit_text(d, "usecases/UC01-propose-severity.md", '"A lead must approve any change to a ticket"', '"Leads approve everything"'), "is not in those lines"),
          ("Uma: a capability citing a need no use case has", "squad.py", "usecases", lambda d: edit_json(d, "capabilities.json", lambda c: c[0].update(needs=["UC01.N9"])), "UC01.N9 is not in any use case"),
          ("Hana/Theo: a harness construct nobody delivers", "enable.py", "check", lambda d: edit_json(d, "capabilities.json", lambda c: c[1]["constructs"].remove("H004")), "H004"),
          ("Hana/Theo: out of scope with no reason", "enable.py", "check", lambda d: edit_json(d, "out-of-scope.json", lambda o: o[0].update(reason="")), "needs a reason"),
          ("Ada: a tool not in required_tools", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "| read_ticket | S0 |", "| delete_ticket | S0 |"), "delete_ticket is not in required_tools"),
          ("Ada: two actors in one step", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "| 2 | agent |", "| 2 | agent and human |"), "one actor per step"),
          ("Ada: a step with no source", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "| H004 |", "| |"), "source is empty"),
          ("Ada: a harness construct dropped from the AOP silently", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "(from H005, H006, H007)", "(from H005, H007)"), "H006"),
          ("Ada: a tier too low for the risk", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "tier: T1", "tier: T0"), "too low"),
          ("Ada: an expired AOP", "squad.py", "aop", lambda d: edit_text(d, "aop/aop-triage-propose.md", "review_by: 2027-05-01", "review_by: 2025-01-01"), "has passed"),
          ("Ada: SmartSDK's expectation not cited", "squad.py", "aop", lambda d: edit_json(d, "aop/target.json", lambda t: t.update(cites=[])), "cite the SmartSDK source"),
          ("Iris: an AOP step with no eval case", "squad.py", "evals", lambda d: edit_json(d, "evals/map.json", lambda m: m["cases"][1].update(covers=["C02"])), "step 2 has no eval case"),
          ("Iris: a safety case that is not a veto", "squad.py", "evals", lambda d: edit_json(d, "evals/map.json", lambda m: m["cases"][3].pop("veto")), "is a veto"),
          ("Iris: a case id that is not in the eval file", "squad.py", "evals", lambda d: edit_json(d, "evals/map.json", lambda m: m["cases"][0].update(id="ev-missing")), "case id is not in"),
          ("Iris: a high-severity edge case with no safety case", "squad.py", "evals", lambda d: edit_json(d, "evals/map.json", lambda m: m["cases"].pop(4)), "E03 is high severity"),
          ("Iris: the eval format not cited from SmartSDK", "squad.py", "evals", lambda d: edit_json(d, "evals/map.json", lambda m: m["format"].update(cites=[])), "cite the SmartSDK source"),
          ("Kai: a prototype box drawn as decided", "squad.py", "runtime", lambda d: edit_text(d, "runtime/UC01-propose-severity.md", "| Triage task | service | Lab account | proposed |", "| Triage task | service | Lab account | decided |"), "never decided or built"),
          ("Kai: a number not labelled as an estimate", "squad.py", "runtime", lambda d: edit_text(d, "runtime/UC01-propose-severity.md", "about 30 seconds (estimate)", "30 seconds"), "labelled as an estimate"),
          ("Kai: a missing section", "squad.py", "runtime", lambda d: edit_text(d, "runtime/UC01-propose-severity.md", "## Failure and stop", "## Notes"), "Failure and stop"),
          ("Noor: a gap with no one to ask", "squad.py", "edges", lambda d: edit_json(d, "edge-cases.json", lambda e: e[2].pop("ask")), "who to ask"),
          ("Noor: an edge case not walked through the design", "squad.py", "edges", lambda d: edit_json(d, "edge-cases.json", lambda e: e[0].pop("walked")), "walk it through the design"),
        ]
        for name, tool, cmd, fn, expect in cases:
            d = fresh(); fn(d); code, out = run(tool, cmd, d / "agentic", "triage")
            ok("caught: " + name, code == 1 and expect in out, out)
        d = fresh(); edit_json(d, "edge-cases.json", lambda e: e.pop(0))
        code, out = run("squad.py", "edges", d / "agentic", "triage", "--page", d / "page.html")
        ok("caught: Noor: a use case with fewer than three edge cases", code == 1 and "walk at least three" in out, out)
        d = fresh(); code, out = run("squad.py", "items", d / "agentic", "triage", d / "page.html", d / "items.json"); its = json.loads((d / "items.json").read_text())["edits"]
        ok("Noor's gaps become page items with the next free id, who to ask and the boxes they concern",
           len(its) == 1 and its[0]["item"]["id"] == "Q8" and its[0]["item"]["owner"] == "Security / SecOps" and its[0]["item"]["refs"] == ["flow/reader"], json.dumps(its))
        code, out = run("squad.py", "status", d / "agentic", "triage")
        ok("status shows the chain and who is next", "Uma" in out and "Next: Theo" in out, out)
    print(f"squad: {passed} passed, {len(fails)} failed")
    return passed, fails

if __name__ == "__main__":
    p, f = main(); sys.exit(1 if f else 0)
