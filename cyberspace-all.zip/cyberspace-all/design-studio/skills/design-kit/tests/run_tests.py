#!/usr/bin/env python3
"""Regression tests for the design page engine (template.html).

Run after any change to the engine (sections 2 and 3 of template.html):
  python3 tests/run_tests.py [path/to/template.html]

Needs playwright and a Chrome/Chromium (set CHROME=/path if not found). Exit code 1 on any failure.
The tests use the worked example in template.html, so keep that example exercising every feature.
"""
import os, sys, shutil, pathlib
from playwright.sync_api import sync_playwright

PAGE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent.parent / "template.html").resolve()
fails, passed = [], 0
def ok(name, cond, detail=""):
    global passed
    if cond: passed += 1
    else: fails.append(f"{name} {detail}".strip())

def main():
    chrome = os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(viewport={"width": 1800, "height": 950}); errs = []
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(PAGE.as_uri()); ev = pg.evaluate; act = lambda a, i=None: ev("([a,i]) => act(a,i)", [a, i])
        views = ev("DIAGRAM.views.map(v=>v.id)"); flows = ev("DIAGRAM.flows.map(f=>[f.id,f.steps.length])")

        # the built-in design check finds nothing wrong with the example
        res = ev("MAYA_CHECK()"); ok("design check: no problems", not [r for r in res if r["level"] == "error"], str([r["msg"] for r in res if r["level"] == "error"][:3]))
        ok("design check: no warnings", not [r for r in res if r["level"] == "warn"], str([r["msg"] for r in res if r["level"] == "warn"][:3]))

        # every design draws; every use case walks to its end, on the map and as a sequence, at every level
        for v in views:
            act("view", v); ok(f"view {v} draws", ev("document.querySelectorAll('#svg .node').length") > 0)
        levels = ev("LEVELS")
        ok("levels C1..C4 present", levels == [1, 2, 3, 4], str(levels))
        for fid, n in flows:
            for lv in [""] + [str(l) for l in levels]:
                act("flow", fid); act("level", lv)
                m = ev("stepsOf(F(S.flow)).length")
                for _ in range(m - 1): act("next")
                ok(f"flow {fid} @ {lv or 'drawn'} walks", ev("S.step") == m - 1)
                act("seq", "1"); ok(f"flow {fid} @ {lv or 'drawn'} sequence draws", ev("document.querySelectorAll('#svg [data-step]').length") == m); act("seq", "0")
        act("level", ""); act("clear")

        # roll-up: a detailed use case gets shorter, and lands on the coarser design
        act("flow", "inside"); act("level", "2"); ok("roll-up to C2 lands on containers", ev("S.view") == "containers"); ok("roll-up to C2 merges steps", ev("stepsOf(F('inside')).length") < 8)
        act("level", "1"); ok("roll-up to C1 lands on context", ev("S.view") == "context"); act("level", ""); act("clear")

        # level switch navigates when no use case is selected
        act("view", "context")
        for lv, want in [("2", "containers"), ("3", "internals"), ("4", "schema"), ("1", "context")]:
            pg.click(f'#legend [data-act=level][data-id="{lv}"]'); ok(f"level switch to C{lv}", ev("S.view") == want, ev("S.view"))

        # drill-down, node click, arrow click
        act("view", "containers"); pg.click("[data-node=pay]"); ok("box click selects", ev("S.node") == "pay")
        pg.wait_for_timeout(60); pg.click("[data-node=pay]"); ok("double-click drills down", ev("S.view") == "internals")
        act("view", "containers"); pg.click('g.ehit[data-edge="gw>pay"]'); ok("arrow click selects", ev("S.edge") == "gw>pay"); ok("arrow shows its API call", pg.locator("details.ep[open]").count() == 1)

        # API, schema, agents, AWS, data flow
        pg.click("[data-node=pay]"); ok("service shows API list", pg.locator("#panel details.ep").count() == 3)
        act("clear"); pg.click("[data-act=apis]"); ok("API catalogue opens", "API catalogue" in pg.inner_text("#panel") or "API CATALOGUE" in pg.inner_text("#panel"))
        act("view", "schema"); pg.click("[data-node=payment]"); t = pg.inner_text("#panel"); ok("table shows columns and writer", "idempotency_key" in t and "Ledger repository" in t)
        act("view", "agents"); pg.click("[data-node=fraud]"); pg.click("[data-act=reach]"); t = pg.inner_text("#panel"); ok("reach lists reachable and blocked", "Ledger lookup tool" in t and "Card data tool" in t)
        act("view", "aws"); ok("AWS icons are embedded", ev("document.querySelectorAll('#svg svg').length") >= 11); ok("AWS frames drawn", ev("V('aws').groups.length") == 12)
        act("view", "containers"); act("mode", "data"); ok("data flow mode", ev("modeOf(V('containers'))") == "data"); act("mode", "structure")
        act("view", "_usecases"); ok("use case diagram generated", ev("document.querySelectorAll('#svg ellipse').length") == len(flows)); pg.click("[data-node=uc_pay]"); ok("oval opens its use case", ev("S.flow") == "pay")

        # open items, lenses, search, design check panel, deep link
        act("clear"); act("view", "containers"); pg.click("[data-act=item][data-id=c1]"); ok("item opens with positions", "Runbook" in pg.inner_text("#panel"))
        pg.click("[data-act=itemview][data-id=timeout]"); ok("item jumps across designs", ev("S.view") == "timeout" and ev("S.item") == "c1")
        act("clear"); act("view", "containers"); act("lens", "gaps"); ok("lens highlights", ev("document.querySelectorAll('#svg .node.on').length") > 0); act("clear")
        pg.fill("#q", "refund"); ok("search finds boxes, use cases, endpoints", pg.locator("#results div").count() >= 3)
        pg.click("[data-act=check]"); ok("design check panel", "Design check" in pg.inner_text("#panel") or "DESIGN CHECK" in pg.inner_text("#panel"))
        pg.goto(PAGE.as_uri() + "#containers/flow/pay/3/seq/c2"); pg.reload(); ok("deep link restores use case, step, sequence, level", ev("[S.flow,S.step,S.seq,S.level].join()") == "pay,3,true,2")
        r = ev("(r => ({can: r.can, beyond: r.beyond, both: r.both}))(reachOf(V('agents'), 'orch'))")
        ok("reach stops at a guard", "limit" in r["can"] and "gw" not in r["can"] and "gw" in r["beyond"] and "lead" in r["beyond"], str(r))
        ok("menu headings are not drawn as actors", ev("!V('_usecases').nodes.some(n => n.label === 'Failure paths')") and "Failure paths" in pg.inner_text("#nav"))
        ok("a flowchart rolls up into its box, with no false mismatch", ev("rolled(F('cardslow'), 2).every(k => !k.missing) && rolled(F('cardslow'), 1).every(k => !k.missing)"))
        ok("`up` names the coarser box", ev("(() => { const v = V('aws'), n = v.nodes[0], was = n.up; n.up = 'gw'; const got = mapUp(v, n.id, upOf(v)); n.up = was; return got; })()") == "gw")
        ok("`rollup: false` keeps a view's steps at every level", ev("(() => { const v = V('aws'); v.rollup = false; for (const k in rollCache) delete rollCache[k]; const same = rolled(F('awspath'), 1).length === F('awspath').steps.length; delete v.rollup; for (const k in rollCache) delete rollCache[k]; return same; })()"))
        ok("a frame shows its status", "UNKNOWN?" in ev("groupTitle({ kind: 'boundary', label: 'x', status: 'unknown', x: 0, y: 0, w: 100, h: 100 }).txt") and "proposed" in ev("groupTitle({ kind: 'vpc', label: 'x', stage: 'proposed', x: 0, y: 0, w: 100, h: 100 }).txt"))
        ev("set({ view: 'schema', node: 'outbox' })"); ok("a writer no view draws is listed as text", "not drawn" in pg.inner_text("#panel").lower())
        ok("`also` opens a second design and counts as a drill-down", ev("(() => { const n = V('context').nodes.find(k => k.child); n.also = ['aws']; set({ view: 'context', node: n.id }); const has = document.querySelector('#panel').innerText.includes('Also open'); delete n.also; return has; })()"))
        r = ev("(() => { const L = layout(V('context'), 'structure'); return L.E.map(x => [x.pts.length, !!x.direct]); })()")
        ok("five boxes: every arrow is one straight line", all(n == 2 for n, _ in r), str(r))
        r = ev("(() => { const v = V('containers'), L = layout(v, 'structure'); return [L.E.filter(x => x.pts.length === 2).length, L.E.length]; })()")
        ok("boxes in a row or column are joined by straight arrows", r[0] >= r[1] - 2, str(r))
        ok("schema, AWS and flowchart views keep right angles", ev("['schema','aws','timeout'].every(id => layout(V(id), 'structure').E.every(x => !x.direct))"))
        ok("`lines: 'elbow'` on a view turns angled lines off", ev("(() => { const v = V('context'); v.lines = 'elbow'; const none = layout(v, 'structure').E.every(x => !x.direct); delete v.lines; return none; })()"))
        ok("an angled line never passes through a box", ev("DIAGRAM.views.filter(v => !v.auto).every(v => { const L = layout(v, 'structure'); return L.E.filter(x => x.direct).every(x => !v.nodes.some(n => n !== x.a && n !== x.b && n.type !== 'note' && segHit(x.pts[0], x.pts[1], n, 0))); })"))
        # the use case diagram is a swimlane map: a lane per actor, a column per phase, read left to right
        U = "V('_usecases')"
        ok("use case diagram: one lane per actor, then one per group", ev(f"{U}.swim.lanes.map(l => l.actor || l.label).join('|')") == "Customer|Support agent|Failure paths", ev(f"{U}.swim.lanes.map(l => l.actor || l.label).join('|')"))
        ok("use case diagram: one column per phase, in order", ev(f"{U}.swim.cols.map(c => c.label).join('|')") == "Take a payment|Behind the payment|Refund|When something fails")
        ok("use case diagram: every oval sits inside its lane and its column", ev(f"(() => {{ const v = {U}; return v.nodes.filter(n => n.type === 'usecase').every(n => {{ const l = v.swim.lanes.find(l => l.id === n.lane), c = v.swim.cols.find(c => c.id === n.col); return l && c && n.y >= l._y && n.y + n.h <= l._y + l._h && n.x >= c._x && n.x + n.w <= c._x + v.swim._cw; }}); }})()"))
        ok("use case diagram: a later phase is further right", ev(f"(() => {{ const v = {U}, x = id => v.nodes.find(n => n.id === 'uc_' + id).x; return x('pay') < x('inside') && x('inside') < x('refund') && x('refund') < x('cardslow'); }})()"))
        ok("use case diagram: nothing overlaps and every name fits", ev(f"(() => {{ const n = {U}.nodes; for (let i = 0; i < n.length; i++) for (let j = i + 1; j < n.length; j++) if (hit(n[i], n[j], 0)) return false; return n.every(k => nodeText(k).fits); }})()"))
        ok("use case diagram: each actor sits in the header of its own lane", ev(f"(() => {{ const v = {U}, g = v.groups.find(k => k.kind === 'swim'); return v.swim.lanes.filter(l => l.actor).every(l => {{ const a = v.nodes.find(n => /^ac_/.test(n.id) && n.label === l.actor); return a && a.y >= l._y && a.y + a.h <= l._y + l._h && a.x + a.w <= g.x + SW.head; }}); }})()"))
        ok("use case diagram: 'then' is the only kind of line, and it runs left to right", ev(f"(() => {{ const v = {U}, e = v.edges.find(e => e.from === 'uc_pay' && e.to === 'uc_refund'), L = layout(v, 'structure').E.find(x => x.e === e); return v.edges.every(k => k.style === 'next') && !!e && L.pts[0][0] < L.pts[L.pts.length - 1][0]; }})()"))
        act("view", "_usecases"); txt = ev("svg.textContent")
        ok("use case diagram: lanes and numbered phases are drawn", "1 · TAKE A PAYMENT" in txt and "4 · WHEN SOMETHING FAILS" in txt and "Failure paths" in txt, txt[:200])
        ok("use case diagram: the panel says how to read it", "How to read it" in pg.inner_text("#panel") and "left to right" in pg.inner_text("#panel"))
        # a flow design drawn as swimlanes
        T = "V('timeout')"
        ok("swimlane design: boxes are placed by lane and column", ev(f"(() => {{ const v = {T}, n = id => v.nodes.find(k => k.id === id), svc = v.swim.lanes[0], ops = v.swim.lanes[1]; return n('p').x < n('d').x && n('d').x < n('ok').x && n('ok').x < n('pend').x && n('p').y >= svc._y && n('p').y + n('p').h <= svc._y + svc._h && n('pend').y >= ops._y; }})()"))
        ok("swimlane design: two boxes in one cell stack without touching", ev(f"(() => {{ const v = {T}, a = v.nodes.find(k => k.id === 'ok'), b = v.nodes.find(k => k.id === 'retry'); return a.x === b.x && b.y >= a.y + a.h + 8; }})()"))
        act("view", "timeout"); txt = ev("svg.textContent")
        ok("swimlane design: lane names and column names are drawn", "Payment service" in txt and "Payments operations" in txt and "2 · DECIDE" in txt)
        ok("swimlane design: the page's saved data keeps lanes and drops what the page computed", ev("(() => { const d = MAYA_DATA(), v = JSON.parse(d).views.find(v => v.id === 'timeout'); return !/\"_(y|h|x|cw|top)\"/.test(d) && !v.groups.some(g => g.kind === 'swim') && v.nodes.find(n => n.id === 'p').lane === 'svc'; })()"))
        ok("swimlane design: a moved box lands in the lane and column it is dropped in", ev(f"(() => {{ const v = {T}, n = v.nodes.find(k => k.id === 'pend'), c = v.swim.cols[3], l = v.swim.lanes[0]; applyEdit({{ t: 'move', view: 'timeout', kind: 'node', id: 'pend', x: c._x + 40, y: l._y + 10 }}); const r = n.lane + '/' + n.col; applyEdit({{ t: 'move', view: 'timeout', kind: 'node', id: 'pend', x: c._x + 40, y: v.swim.lanes[1]._y + 10 }}); return r + ' ' + n.lane; }})()") == "svc/hand ops")
        ok("swimlane design: a box in a lane that does not exist is an error", ev(f"(() => {{ const n = {T}.nodes[0], was = n.lane; n.lane = 'nobody'; const r = designCheck().some(x => x.level === 'error' && /lane \"nobody\"/.test(x.msg)); n.lane = was; layoutSwim({T}); return r; }})()"))
        # structure: what the check says about the shape of a design
        ok("structure: the worked example reads cleanly", ev("MAYA_STRUCTURE().every(r => !r.issues.length)"), str(ev("MAYA_STRUCTURE().filter(r => r.issues.length).map(r => r.name + ': ' + r.issues[0])")))
        ok("structure: a design turned right to left is flagged", "Reads right to left" in ev("(() => { const v = V('containers'), was = v.nodes.map(n => n.x), max = Math.max(...v.nodes.map(n => n.x + n.w)); v.nodes.forEach(n => n.x = max - n.x - n.w); const r = structureOf(v).issues.join(' '); v.nodes.forEach((n, i) => n.x = was[i]); return r; })()"))
        row = "Array.from('abcdef', (c, i) => ({ id: c, type: 'service', x: i * 240, y: 100, w: 180, h: 72 }))"
        both = "[['a','b'],['b','c'],['c','d'],['d','a'],['e','b'],['f','c']]"
        ok("structure: arrows running both ways are flagged", "No clear reading direction" in ev(f"structureOf({{ id: 't', name: 't', groups: [], nodes: {row}, edges: {both}.map(([from, to]) => ({{ from, to }})) }}).issues.join(' ')"))
        ok("structure: an arrow marked as a loop is not counted against the direction", ev(f"structureOf({{ id: 't', name: 't', groups: [], nodes: {row}, edges: {both}.map(([from, to], i) => ({{ from, to, back: i > 2 }})) }}).issues.length") == 0)
        ok("structure: boxes that share no row or column are flagged", "do not line up" in ev("structureOf({ id: 't', name: 't', groups: [], edges: [], nodes: Array.from('abcdefgh', (c, i) => ({ id: c, type: 'service', x: i * 137, y: (i * 5 % 8) * 93, w: 180, h: 72 })) }).issues.join(' ')"))
        ok("structure: a long flow that is not in lanes is flagged", "no lanes" in ev("structureOf({ id: 't', name: 't', level: 'Flow', groups: [], edges: [], nodes: Array.from('abcdefgh', (c, i) => ({ id: c, type: 'service', x: (i % 4) * 240, y: Math.floor(i / 4) * 140, w: 180, h: 72 })) }).issues.join(' ')"))
        ok("structure: 'free' switches the warnings off for one design", ev(f"structureOf({{ id: 't', name: 't', structure: 'free', groups: [], nodes: {row}, edges: {both}.map(([from, to]) => ({{ from, to }})) }}).issues.length") == 0)
        ok("structure: every design in the worked example says how to read it", not any("do not say how to read" in r["msg"] for r in ev("MAYA_CHECK()")))
        ok("structure: a design with no 'reads' line is reported, once for the page", ev("(() => { const v = V('containers'), was = v.reads; delete v.reads; const n = designCheck().filter(r => /do not say how to read them: \"Containers\"/.test(r.msg)).length; v.reads = was; return n; })()") == 1)
        # hiding a side panel must give its width to the drawing
        act("view", "containers"); w0 = ev("svg.getBoundingClientRect().width"); pg.click("#tnav"); pg.wait_for_timeout(150); w1 = ev("svg.getBoundingClientRect().width"); pg.click("#tpanel"); pg.wait_for_timeout(150); w2 = ev("svg.getBoundingClientRect().width"); pg.click("#tnav"); pg.click("#tpanel"); pg.wait_for_timeout(150)
        ok("hiding the menu, then the details, widens the drawing each time", w1 >= w0 + 200 and w2 >= w1 + 250 and abs(w2 - 1800) < 2 and abs(ev("svg.getBoundingClientRect().width") - w0) < 2, str((w0, w1, w2)))
        ok("straighten finds nothing to undo in the sample", ev("MAYA_RELAX().length") == 0)
        ev("set({ view: 'containers' })"); pg.click("#edit"); ev("set({ view: 'containers', node: V('containers').nodes[0].id })")
        ok("edit mode shows a form for the picked box", pg.is_visible("#edLabel") and pg.inner_text("#edit") == "Editing")
        pg.fill("#edSub", "edited <i>x</i>"); pg.fill("#edRows .edrow:last-child .k", "Owner"); pg.fill("#edRows .edrow:last-child .v", "Team A"); pg.click("[data-act=edsave]")
        ok("an edit changes the box and is counted as unsaved", ev("(n => n.sub === 'edited <i>x</i>' && n.details.Owner === 'Team A' && n.changed === true)(V('containers').nodes[0])") and "1 unsaved" in pg.inner_text("#ver") and "&lt;i&gt;" in pg.inner_html("#panel"))
        pg.fill("#edNote", "a note"); pg.click("[data-act=ednote]"); pg.fill("#edItem", "a new question"); pg.click("[data-act=editem]")
        ok("a note and a raised item are recorded", ev("V('containers').nodes[0].notes.length") == 1 and ev("(it => it.id === 'N01' && it.status === 'open' && it.where.length === 1)(DIAGRAM.items[DIAGRAM.items.length - 1])"))
        r = ev("(() => { const o = savedHtml(); return [o.html.startsWith('<!DOCTYPE html>'), o.data.rev, o.data.changes[0].text, o.html.includes('AWS-ICONS:BEGIN'), o.html.split('2. VISUAL LANGUAGE').length, o.data.views.some(v => v.auto), JSON.stringify(o.data).includes('_ds')]; })()")
        ok("the saved copy is a whole page with the edits, the icons and a change log line", r[0] and r[1] == 1 and r[2].startswith("Edited in the page") and r[3] and r[5] is False and r[6] is False, str(r))
        ev("(() => { localStorage.removeItem(edKey()); ED.log = []; ED.on = false; edBadge(); })()")
        ev("set({ view: 'containers' })"); pg.click("#edit"); n0 = ev("V('containers').nodes.length"); e0 = ev("V('containers').edges.length")
        ok("edit mode puts drawing tools on the drawing", pg.is_visible("#edbar [data-act=edbox]") and pg.is_visible("#edbar [data-act=edarrow]"))
        pg.click("#edbar [data-act=edbox]"); pt = ev("(() => { const b = svg.getBoundingClientRect(); return [b.left + 30, b.bottom - 30]; })()"); pg.mouse.click(pt[0], pt[1]); pg.wait_for_timeout(150)
        nid = ev("S.node"); nb = ev("V('containers').nodes[V('containers').nodes.length - 1]")
        ok("+ Box adds a box on the grid where clicked and selects it", ev("V('containers').nodes.length") == n0 + 1 and nb["id"] == nid and nb["x"] % 20 == 0 and nb["y"] % 20 == 0, str(nb))
        pg.select_option("#edBox", "queue"); pg.fill("#edLabel", "Retry queue"); pg.click("[data-act=edsave]")
        ok("the new box takes a name and a kind", ev("(n => [n.label, n.type, n.cat])(V('containers').nodes.find(n => n.id === '%s'))" % nid) == ["Retry queue", "queue", "messaging"])
        first = ev("V('containers').nodes[0].id"); pg.click("[data-act=edarrowfrom]"); pg.click("[data-node=%s]" % first); pg.wait_for_timeout(150)
        ok("an arrow is drawn from the picked box to the clicked box", ev("V('containers').edges.length") == e0 + 1 and ev("S.edge") == "%s>%s" % (nid, first))
        ev("edit({ t: 'move', view: 'containers', id: '%s', x: 40, y: 2000 })" % nid); ev("edit({ t: 'move', view: 'containers', id: '%s', x: 60, y: 2000 })" % nid)
        ok("moves of one box collapse into one edit", ev("ED.log.filter(p => p.t === 'move').length") == 1 and ev("V('containers').nodes.find(n => n.id === '%s').x" % nid) == 60)
        used = ev("(() => { const f = DIAGRAM.flows.find(f => f.steps.some(s => s.view === 'containers' && s.edge)); const e = edgeOf(V('containers'), f.steps.find(s => s.view === 'containers' && s.edge).edge); return e.from; })()")
        ev("set({ view: 'containers', node: '%s' })" % used); pg.click("[data-act=eddel]")
        ok("a box that use cases walk through cannot be deleted in the page", "Not deleted" in pg.inner_text("#panel") and ev("V('containers').nodes.some(n => n.id === '%s')" % used))
        ev("set({ view: 'containers', node: '%s' })" % nid); pg.click("[data-act=eddel]"); pg.click("[data-act=eddel]")
        ok("an added box is deleted with its arrows after a second click", ev("V('containers').nodes.length") == n0 and ev("V('containers').edges.length") == e0)
        ev("(() => { localStorage.removeItem(edKey()); ED.log = []; ED.on = false; ED.tool = null; edBadge(); update(); })()")
        # zoom as a percentage
        ev("set({ view: 'containers' })"); real = lambda: ev("Math.round(svg.getScreenCTM().a * 100)"); shown = lambda: int(pg.inner_text("#zoomnow").rstrip("%"))
        ok("the zoom control shows the real scale", pg.is_visible("#zoombar") and abs(shown() - real()) <= 1, str((shown(), real())))
        hits = []
        for pct in [50, 100, 200, 25, 400]: pg.select_option("#zoomsel", str(pct)); pg.wait_for_timeout(80); hits.append(shown() == pct and abs(real() - pct) <= 1)
        ok("picking a percentage sets exactly that zoom", all(hits), str(hits))
        pg.select_option("#zoomsel", "100"); pg.click("#zoomin"); a1 = shown(); pg.click("#zoomout"); pg.click("#zoomout")
        ok("plus and minus move in steps of ten", a1 == 110 and shown() == 90, str((a1, shown())))
        pg.select_option("#zoomsel", "400"); pg.click("#zoomin"); hi = shown(); pg.select_option("#zoomsel", "25"); [pg.click("#zoomout") for _ in range(3)]
        ok("zoom stops at 400% and at 10%", hi == 400 and shown() == 10, str((hi, shown())))
        pg.select_option("#zoomsel", "150"); pg.click("#tpanel"); pg.wait_for_timeout(200); mid = shown(); pg.click("#tpanel"); pg.wait_for_timeout(200)
        ok("hiding or showing a panel keeps the percentage", mid == 150 and shown() == 150 and abs(real() - 150) <= 1, str((mid, shown(), real())))
        pg.select_option("#zoomsel", "fit"); pg.wait_for_timeout(80)
        ok("'Fit all' shows the whole design and its percentage", ev("Math.abs(vb.w - home.w) < 1") and abs(shown() - real()) <= 1)
        # the form applies each change at once: nothing waits for a button
        ev("set({ view: 'containers' })"); pg.click("#edit"); pg.click("#edbar [data-act=edbox]"); bb = pg.locator("#svg").bounding_box(); pg.mouse.click(bb["x"] + 40, bb["y"] + bb["height"] - 40); pg.wait_for_timeout(450); nid = ev("S.node")
        shape = lambda: ev("id => [...document.querySelector('#svg [data-node=' + id + ']').children].map(c => c.tagName + (c.getAttribute('fill') || '')).join('|')", nid)
        rect = shape(); pg.select_option("#edBox", "data"); pg.wait_for_timeout(150)
        ok("picking 'Data store' turns the box into a cylinder at once, with no button pressed", ev("V('containers').nodes.find(n => n.id === '%s').type" % nid) == "db" and shape() != rect)
        seen = {rect, shape()}
        for k in ["queue", "person", "external", "decision", "model", "note"]: pg.select_option("#edBox", k); pg.wait_for_timeout(100); seen.add(shape())
        ok("each kind of box has its own shape", len(seen) == 8, str(len(seen)))
        pg.fill("#edLabel", "Typed name"); pg.wait_for_timeout(120)
        ok("a name shows on the drawing while it is typed", "Typed" in ev("document.querySelector('#svg [data-node=%s]').textContent" % nid) and "Typed name" in pg.inner_text("#panel h3"))
        ok("typing and picking count as one edit to that box, not dozens", ev("ED.log.filter(p => p.t === 'set').length") == 1, str(ev("ED.log.length")))
        ok("the form keeps focus while changes are applied", ev("document.activeElement && document.activeElement.id") == "edLabel")
        ev("(() => { localStorage.removeItem(edKey()); location.reload(); })()"); pg.wait_for_timeout(400)
        # the same tools used the way a hand uses them: the pointer moves a little during a click, and arrows are also drawn by dragging
        ev("set({ view: 'containers' })"); pg.click("#edit")
        def at(nid, dx=0, dy=0): return ev("([id, dx, dy]) => { const n = V('containers').nodes.find(n => n.id === id), p = svg.createSVGPoint(); p.x = n.x + n.w / 2 + dx; p.y = n.y + n.h / 2 + dy; const q = p.matrixTransform(svg.getScreenCTM()); return [q.x, q.y]; }", [nid, dx, dy])
        def wobble(xy): pg.mouse.move(*xy); pg.mouse.down(); pg.mouse.move(xy[0] + 4, xy[1] + 3); pg.mouse.up(); pg.wait_for_timeout(120)
        ids = ev("V('containers').nodes.filter(n => n.type !== 'note').slice(0, 3).map(n => n.id)"); e0 = ev("V('containers').edges.length")
        wobble(at(ids[0])); ok("a click that moves a few pixels still picks the box", ev("S.node") == ids[0])
        ok("a picked box shows a handle to pull an arrow from", ev("!!document.querySelector('#svg [data-handle]')"))
        ev("set({ view: 'containers' })"); pg.click("#edbar [data-act=edarrow]"); wobble(at(ids[0])); wobble(at(ids[1]))
        ok("+ Arrow works with clicks that move a few pixels", ev("V('containers').edges.length") == e0 + 1 and (ev("S.edge") or "").startswith(ids[0] + ">" + ids[1]), str(ev("[S.edge, ED.tool]")))
        ev("set({ view: 'containers' })"); pg.click("#edbar [data-act=edarrow]"); a1, a2 = at(ids[1]), at(ids[2]); pg.mouse.move(*a1); pg.mouse.down(); pg.mouse.move((a1[0] + a2[0]) / 2, (a1[1] + a2[1]) / 2, steps=5)
        band = ev("!!document.querySelector('#svg line[stroke-dasharray=\"6 5\"]')"); pg.mouse.move(*a2, steps=5); pg.mouse.up(); pg.wait_for_timeout(150)
        ok("+ Arrow works by dragging from one box to another, with a line following the pointer", band and ev("V('containers').edges.length") == e0 + 2 and (ev("S.edge") or "").startswith(ids[1] + ">" + ids[2]), str(ev("[S.edge, ED.tool]")))
        ok("the arrow just drawn stays picked with its form open", pg.is_visible("#edLabel") and ev("!!S.edge"))
        ev("set({ view: 'containers' })"); pg.click("#edbar [data-act=edarrow]"); wobble(at(ids[0])); wobble(at(ids[0]))
        ok("clicking the start box twice is explained, not ignored", "starts from" in pg.inner_text("#edbar")); pg.click("#edbar [data-act=edcancel]")
        x0 = ev("V('containers').nodes.find(n => n.id === '%s').x" % ids[2]); wobble(at(ids[2]))
        ok("a click that moves a few pixels does not move the box", ev("V('containers').nodes.find(n => n.id === '%s').x" % ids[2]) == x0)
        ev("(() => { localStorage.removeItem(edKey()); location.reload(); })()"); pg.wait_for_timeout(400)
        ph = b.new_context(viewport={"width": 390, "height": 800}, has_touch=True, is_mobile=True).new_page(); ph.goto(pg.url.split("#")[0]); ph.wait_for_timeout(300)
        ok("phone width: header fits and Edit, Details, menu are on screen", ph.evaluate("document.querySelector('header').scrollWidth <= innerWidth + 1") and all(ph.is_visible("#" + i) for i in ["edit", "tpanel", "tnav"]))
        ok("phone width: the drawing has the whole width, drawers closed", ph.evaluate("document.getElementById('stage').getBoundingClientRect().width") > 380 and not ph.is_visible("#nav") and not ph.is_visible("#panel"))
        ph.tap("#edit"); ph.tap("#tpanel"); ph.tap("[data-node]"); ph.wait_for_timeout(200)
        ok("phone width: a tap on a box opens its edit form", ph.is_visible("#edLabel"))
        ph.close()
        ok("no page errors", not errs, str(errs[:3]))
        b.close()
    # page.py arrange: applies a layout plan, and nothing but layout
    import json, subprocess, tempfile
    kit = pathlib.Path(__file__).resolve().parent.parent; sys.path.insert(0, str(kit)); import page as pagetool
    with tempfile.TemporaryDirectory() as tmp:
        t = pathlib.Path(tmp); pg2 = t / "p.html"; shutil.copy(PAGE, pg2)
        run = lambda plan: (lambda f: subprocess.run([sys.executable, str(kit / "page.py"), "arrange", str(pg2), str(f)], capture_output=True, text=True))((t / "plan.json").write_text(json.dumps(plan)) and t / "plan.json")
        r = run({"designs": {"context": {"reads": "Left to right: people, the platform, outside systems.", "place": {"card": [800, 100]}}}})
        txt = pg2.read_text()
        ok("arrange: a plan moves the box it names and says what changed", r.returncode == 0 and "Content unchanged" in r.stdout and '"x": 800' in txt and "Re-laid to a clear order" in txt, r.stdout[-200:] + r.stderr[-200:])
        size = len(txt)
        for name, plan, said in [("a box the design does not have", {"designs": {"context": {"reads": "x", "place": {"nobody": [0, 0]}}}}, "does not have"),
                                 ("anything that is not layout", {"designs": {"context": {"reads": "x", "label": "New name"}}}, "moves things"),
                                 ("a design with no 'reads'", {"designs": {"internals": {"place": {}, "reads": ""}}}, None)]:
            r = run(plan)
            if said is None: ok("arrange: keeps an existing 'reads' when the plan gives none", r.returncode == 0, r.stderr[-200:]); shutil.copy(PAGE, pg2); run({"designs": {"context": {"reads": "x", "place": {"card": [800, 100]}}}}); size = len(pg2.read_text())
            else: ok("arrange: refuses " + name + " and saves nothing", r.returncode != 0 and said in r.stderr and len(pg2.read_text()) == size, r.stderr[-200:])
    d0 = {"views": [{"id": "v", "nodes": [{"id": "a", "label": "A", "x": 0, "y": 0}], "edges": [], "groups": []}], "flows": [], "items": []}
    d1 = json.loads(json.dumps(d0)); d1["views"][0]["nodes"][0]["x"] = 500; d2 = json.loads(json.dumps(d0)); d2["views"][0]["nodes"][0]["label"] = "B"
    ok("arrange: moving a box is not a content change; renaming one is", pagetool.content_of(d0) == pagetool.content_of(d1) and pagetool.content_of(d0) != pagetool.content_of(d2))
    import test_enable
    global passed
    p2, f2 = test_enable.main(); passed += p2; fails.extend(f2)
    import test_squad
    p3, f3 = test_squad.main(); passed += p3; fails.extend(f3)
    import test_program
    p4, f4 = test_program.main(); passed += p4; fails.extend(f4)
    print(f"{passed} passed, {len(fails)} failed")
    for f in fails: print("  FAIL", f)
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
