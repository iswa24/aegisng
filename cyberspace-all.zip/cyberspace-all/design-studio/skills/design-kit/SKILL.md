---
name: design-kit
description: Shared toolkit for the design studio personas (Maya, Rhea, Finn, Dara, Skye, Aria, Vera) — the interactive design page template, the design checker, the AWS icon tools and the reference guides. Use when building, checking or repairing a design page, or when a design persona needs its tools.
---

# Design kit

The tools and reference guides the design studio personas share. You can also use it directly to build or check a design page.

## What is here

| Path | What it is |
|---|---|
| `template.html` | The interactive design page. Section 1 (`DIAGRAM`) is data and a worked example of most features; sections 2 and 3 are the engine and are never edited per design. |
| `check.py` | `python3 check.py doctor` says whether this machine can check pages and take screenshots, and what to fix if not. `python3 check.py <page> [shots-dir]` — runs the page's design check on every design, walks every use case, saves a screenshot per design. Exit code 1 on problems. |
| `page.py` | `summary <page>` says what is on a page; `extract` and `build` take the data out and put it back; `upgrade <page>` moves a page to this kit's engine without touching its data; `structure <page>` reports the shape of every design (direction of arrows, shared rows and columns, lanes, phases of the use case diagram) and is the first thing to run on an existing page; `arrange <page> <plan.json>` re-lays designs to a written layout plan and refuses to save anything but moved boxes, frames and arrow routes; `straighten <page>` removes hand-set arrow hints that make arrows bend more than they need to; `confluence <page>` writes the snippets that show the page inside a Confluence page; `apply-edits <page> <edits.json>` merges edits a reader exported from the page. |
| `aws_icons.py` | `search <words>` and `list` find an official AWS icon key; `embed <page>` embeds the icons that page uses. |
| `aws-icons.json`, `AWS-ICONS-NOTICE.txt` | The official AWS Architecture Icons, unmodified, and their source and licence. |
| `references/` | One guide per topic. Start with `references/core.md`; it lists the rest and says who owns what. |
| `tests/run_tests.py` | Regression tests for the engine. Run after any engine change. |

## Conventions

- Bare paths resolve from this skill's folder. Other design skills refer to this folder as `<design-kit>`; it is installed beside them, so from any design skill it is `../design-kit`. If it is not there, look for a folder named `design-kit` in the skills directory.
- `python3` runs every script. `check.py` and the tests need `playwright` and a Chrome or Chromium (`CHROME=/path/to/chrome` if it is not found). Without a browser, open the page and press **Run design check**: it runs the same checks.

## Using it directly

1. Read `references/core.md`, then the guide for the task (`references/page.md` for anything that touches the page).
2. Plan the shape of each design before placing a box (`references/layout.md`). On an existing page run `python3 page.py structure <page>` and restructure what it flags first.
3. Copy `template.html` to the project's design folder; replace only section 1 and the `<title>`.
4. If the page uses AWS icons: `python3 aws_icons.py embed <page>`.
5. `python3 check.py <page> <shots-dir>`; fix every problem; look at the screenshots.

## Changing the engine

Do not, during design work. If the engine cannot express something or has a bug, draw the closest honest version and report it. When the engine itself is being maintained: change it, keep the worked example in `template.html` exercising every feature, and run `python3 tests/run_tests.py` until it passes.
