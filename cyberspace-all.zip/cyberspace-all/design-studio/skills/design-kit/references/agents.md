# Agent systems: multi-agent designs and operating procedures

Read `core.md` first. This is Aria's main reference.

**Making agent designs good.** Use the box types to say what each thing is: `agent` (set `lead: true` on the orchestrator), `tool`, `model`, `db` for memory, `actor` for a person, and a `decision` with `cat: "guard"` for a fixed-rule check that is not a model judgement. Use `cat` values `agent`, `tool`, `model`, `guard`. Use arrow `kind` to say what each arrow is: `handoff` (control passes to another agent), `tool` (an agent calls a tool), `model` (a model call), `memory` (read or write of memory). Frame steps that run together with a group of `kind: "parallel"`, and a retry or refine cycle with `kind: "loop"`; put the exit condition and the limit in the frame's label ("until the validator passes, max 3").

What matters most in an agent design is what each agent can see and reach, so make it explicit: `sees: [...]` and `blind: [...]` on an agent list what information it gets and what it must never get; a `blocked` arrow shows a tool, store or target it has no route to. Then check your own drawing with "Show what this can reach" on each agent: if it can reach something it should not, either the design or the drawing is wrong. Always show where a person approves, where a fixed rule (not a model) decides, where the stop or kill path is, and what happens when an agent loops without finishing. The run order goes in a use case, which also gives the sequence diagram.

## Agent operating procedure (AOP)

An AOP is to an agent what a standard operating procedure is to a person: the written procedure it follows, precise enough to build, test and audit. Write one per agent, or one per use case when several agents share it.

**If the organisation has its own AOP template, use it.** Look for `design/aop-template.md` or ask for it. The outline below is a generic one, used only when no template exists; say in the document that it is generic.

```
AOP: <name>                      Version, date, owner, approver, stage (proposed / decided / built)
1. Purpose and scope             What this agent is for; what it is explicitly not for.
2. Trigger                       What starts a run: a person, an event, a schedule. Who may start it.
3. Inputs and preconditions      What it is given; what must be true before it starts; what it refuses.
4. Procedure                     Numbered steps. For each: who acts (which agent, tool or person), the action,
                                 the tool or model used, what goes in and comes out, and the rule for the next step.
5. Decision points               Every branch. For each: is it a fixed rule or a model judgement? The rule or the
                                 criteria. Who decides when the agent cannot.
6. Tools and permissions         The tools it may call, with what rights. Everything else is denied.
7. Information boundaries        What it may see. What it must never see. What it may write, and where.
8. Limits                        Budget, time, retries, loop limit, rate. What happens when a limit is hit.
9. Human points                  Where a person approves, reviews or takes over, and what they are shown.
10. Stop and recovery            How a run is stopped (by whom, how fast), what state is left, how to resume or undo.
11. Evidence                     What is logged for each step, where, and for how long.
12. Exceptions                   Known failure cases and the handling for each.
13. Test cases                   Runs that must pass before a change is accepted: normal, edge, refusal, stop.
14. Open questions               Anything the source does not say.
```

**From a spec to an AOP.**

1. Read the spec (or the existing SOP) and list every action it describes, in order, with its spec reference. Rhea's requirement register is the input if she has built one.
2. For each action decide who performs it: an agent, a tool, a fixed rule, or a person. Where the spec does not say, do not choose silently: mark it `assumed` and ask.
3. Turn each judgement in the spec ("if appropriate", "when necessary", "escalate serious cases") into a decision point with a testable rule, or into an open question. Vague verbs are the main source of gaps.
4. Fill sections 6 to 10 from the spec and the platform's rules. Missing limits, missing stop path and missing information boundaries are findings, not blanks to fill with defaults.
5. Draw it. The AOP and the diagrams are one design, so they must agree:
   - an **agent design** view (who and what: agents, tools, models, memory, people, guardrail checks, blocked paths);
   - a **flowchart** view of the decision points;
   - one **use case** per kind of run (normal, each exception, stop), which also gives the **sequence diagram**.
   Every numbered step in section 4 is a step in a use case; every decision point is a diamond; every tool in section 6 is a box; every "must never see" is a `blind` entry or a blocked arrow.
6. Check it: press "Show what this can reach" on each agent and compare with sections 6 and 7. Step through each use case against section 4.

**What to push on.** Where a model decides something that a fixed rule could decide. Where an agent can reach more than its procedure needs. Loops with no limit. Steps with no evidence. A stop path that depends on the agent cooperating. An approval where the person is shown too little to judge.

**What "Show what this can reach" means.** Reach is what the box itself can get to and act on. It follows the box's own arrows and onward calls, and it stops at a **guard** (a box with `cat: "guard"`, or any box with `guard: true`, such as a promotion gate that keeps its own colour) and at an **asynchronous hand-off made by something else**. What lies just past those is listed separately as "passed on, out of its hands". If a box is drawn as blocked from a target and can still reach it another way, the panel says so and the design check warns: that is either a drawing fault (one shared box standing for two things) or a real hole. Fix the drawing or open a risk.

- `sees` and `blind` are statements, not checked by the page. Check them yourself against the arrows: everything in `blind` should be either unreachable or behind a blocked arrow.
- One view holds about 16 boxes. Draw a blocked arrow for the targets that matter most (the ones a reviewer would ask about first) and list the rest in the agent's `blind`.
- A sandbox, container or VM the agent runs commands in is a `service` box (`cat: "service"`) with the isolation facts in `sub` and `details`; there is no special type.
