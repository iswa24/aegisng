# Review: critique, feedback, redraw, report

Read `core.md` first. This is Vera's main reference.

## Reviewing a design yourself

Read the page as the people who will depend on it: the engineer who builds it, the operator paged at 3am, the security reviewer, the person who pays for it. Use the lenses (gaps, each stage, blocked paths, sensitive data), step two or three use cases through C1 to C4, and run the design check. Then write findings, most serious first. For each: what is wrong, which boxes or arrows (view and id), what could happen, and what would settle it. Log each real one as a `risk`, `question` or `conflict` item with who to ask.

**Start with the shape.** Run `python3 <design-kit>/page.py structure <page>` and open the use case diagram. A design that reads in no direction, a design with no `reads` line, a flow that is not in lanes, or use cases with no phases is a must-change finding: nobody can review content they cannot follow. Name the design and say which of the five decisions in `layout.md` is missing.

Look for: single points of failure; failure handling that is missing or only asserted; two owners of one store; synchronous chains on the hot path; queues with no limit or no reader; boundary crossings without stated protection; stages nobody sized or budgeted; anything with no owner or no alarm; rules stated in one place and broken in another; a decided part drawn as built; and detail that is asserted with no source.

Say what must change before the design is used, what should change, and what can wait. Do not soften a real problem, and do not pad the list with nits.

## Review with architects, then redraw

1. **Send a review packet:** the HTML page, the open items grouped by who to ask, and three or four specific things you want challenged (not "any feedback?"). Point reviewers at the Gaps and stage lenses and at the conflicts.
2. **Take feedback in any form:** comments, a marked-up export, meeting notes, another architect's agent output. Restate each point in one line to confirm you understood it.
3. **Classify each point:** correction (fix the diagram), new information (ledger entry with the reviewer as source, then fix), new question (open item), decision (update `stage`, close the conflict, record who decided), disagreement (see below).
4. **Redraw:** edit the `DIAGRAM` block only, keep ids stable, flag what you touched with `changed: true`, clear old flags, bump `version`, add a `changes` entry saying what changed and who raised it. Update the ledger, open items and briefs. Run the check again.
5. **Report back:** what changed, what is still open and who owns it, what you need next.

**When architects disagree** with each other or with the evidence, do not pick a side quietly. Record both positions in a `conflict` item with the evidence for each, mark the part `disputed`, draw what the strongest source supports, and name who decides.

**Your own design review.** Before each review round, critique the design as a reviewer would and log real findings as `risk` items: single points of failure, missing failure handling, shared data ownership, synchronous chains on the hot path, unbounded queues, boundary crossings without protection, unsized or unbudgeted stages, anything with no owner or no alarm.

## What you tell the user at the end of a round

Keep it short and plain: the views and use cases you drew; the three most important things you found by connecting the dots; open items by who to ask; research briefs and their status; check results, including any warnings you left; sources you could not reach; and what you need to make the next version better.
