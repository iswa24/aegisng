# Agentic architecture patterns

Read `core.md` first. Theo owns this guide; Aria uses it when she draws an agent system.

This guide is for choosing the shape of a system that uses language-model agents, and for reviewing one. It covers which pattern fits a problem, what each pattern costs, how each one fails, how to contain it, and how it maps onto the frameworks a team is likely to use. It is written for one question first: **does this need to be multi-agent at all?**

Facts about protocols and frameworks change quickly. The ones here were checked on 25 November 2026 (see Sources). Before you rely on a version number or an API name, check it again.

## 1. The ladder: start at the bottom, climb only on evidence

Each rung costs more tokens, more latency, more places to fail and more to secure. Climb a rung only when a measurement, or a constraint you can name, says the rung below is not enough.

| Rung | Shape | Who decides the path | Typical reason to climb to it |
|---|---|---|---|
| 0 | One model call, with retrieval and tools | Code | The default. Most "agent" problems end here. |
| 1 | **Workflow:** a fixed graph of model calls | Code | The steps are known in advance, but one call cannot do them well |
| 2 | **Single agent:** one model in a tool loop | Model | The steps are not known in advance |
| 3 | **Multi-agent:** several agents with separate contexts | Model, per agent | One of the five reasons below |

**The five good reasons to split into several agents:**

1. **A trust boundary.** Parts of the work need different reach. For example, one part reads untrusted input and must never hold credentials. This is the strongest reason, because the split itself is the security control.
2. **Context that does not fit.** The work needs more material than one context can hold well, and it divides into independent parts that each return a short summary.
3. **Real parallelism.** Independent subtasks can run at the same time, and wall-clock time matters more than token cost.
4. **Independent judgement.** A checker must not share the maker's context. Examples are review, red team and grading, where the rule is "no self-grading".
5. **An organisational boundary.** Another team owns, runs and changes the other agent.

**Bad reasons:** it maps to the org chart, it looks like a team of experts, "agents are the future", or one agent was not tried properly with better tools and instructions.

**Where multi-agent is the wrong answer:** tightly coupled work where every step needs the full picture (most edits to one codebase or one document); latency-sensitive paths; low-volume tasks where the token multiplier is not paid back. Multi-agent systems are reported to use several times the tokens of a single agent; Anthropic reported about 15 times the tokens of a chat for its research system. Published studies also find that multi-agent systems often gain little over a single agent or best-of-N sampling (see MAST in Sources).

## 2. Workflow patterns (code decides the path)

Prefer these whenever the path is known. They are testable, cheap and predictable.

| Pattern | What it is | Use when | Watch for | Contain with |
|---|---|---|---|---|
| **Chain / pipeline** | Step 1's output is step 2's input, with checks between steps | Fixed stages: extract, then classify, then draft | Errors compound; a bad early step poisons the rest | A code gate between steps (schema, rule, threshold); fail fast |
| **Router** | A classifier sends each input to one specialised path | Inputs fall into distinct kinds with different handling | Misroutes hide; the "other" bucket grows | Confidence threshold; a default path to a person; route accuracy as a metric |
| **Fan-out / fan-in (sectioning, map-reduce)** | Split into independent parts, run them in parallel, merge | Independent parts; time matters | The merge step is the hard part; parts overlap or leave gaps | Explicit part boundaries; a merge contract; a coverage check |
| **Voting (N-version)** | Same task N times or N ways; aggregate | High-stakes classification; flaky judgements | Cost times N; correlated errors from the same model | Diverse prompts or models; a rule for disagreement (escalate, not average) |
| **Maker-checker (evaluator-optimizer)** | One produces, another critiques, repeat | Clear quality criteria; feedback improves output | Endless loops; the checker drifts toward the maker | A hard iteration limit; checker criteria written down; separate contexts |
| **Plan-then-execute** | A model writes a plan; code runs it step by step | You want model planning but deterministic, auditable execution | Plans that cannot be executed; replanning storms | Validate the plan against allowed actions before running it; replan budget |

## 3. Agent patterns (the model decides the path)

| Pattern | What it is | Use when | Watch for | Contain with |
|---|---|---|---|---|
| **Single agent, tool loop (ReAct-style)** | One model reasons, calls tools, reads results, repeats | Open-ended task, one trust level, fits one context | Loops, wandering, context bloat, tool misuse | Step, token, time and money budgets; a few well-described tools; stop conditions in code |
| **Orchestrator-workers (supervisor)** | A lead agent splits work at run time and dispatches workers | Breadth: research, investigation, many independent leads | The lead under-specifies tasks; workers duplicate or miss work; cost explodes | Task briefs with objective, output format, tools and limits; a worker cap; workers return summaries, not transcripts |
| **Agent as tool (hierarchical delegation)** | A parent calls a child agent like a function; the child's whole run returns one result | You want context isolation and a clean interface | The parent trusts the child's output blindly | A typed result; validate it in code; the child gets only the reach its task needs |
| **Handoff (transfer of control)** | An agent passes the conversation to a peer, which takes over | Conversational systems with distinct specialist stages | Ping-pong; lost context; nobody owns the outcome | An explicit handoff payload; no handoff back without a reason; one owner of completion |
| **Hierarchical teams** | Supervisors of supervisors | Very large work with real sub-domains | Telephone-game drift; latency stacks up | Keep it to two levels; summaries with sources at every level |
| **Blackboard (shared state)** | Agents read and write a shared store and react to it | Many contributors, opportunistic order | Races, overwrites, no clear finish | Versioned writes with an owner per key; a controller that decides when it is done |
| **Debate / adversarial review** | Agents argue or attack each other's output, and a judge decides | Reducing confident errors; red teaming | Collusion toward agreement; theatre without ground truth | Different instructions and contexts; a judge with criteria; check against evidence |
| **Remote agent (cross-organisation)** | Call an agent another team runs, over a protocol | Ownership boundary; reuse of a capability | You cannot see inside it; versioning; trust | Treat it as an external service: contract, auth, timeouts, validation of what returns |

## 4. Patterns that apply to every design

**Human gates.** Put a person where an action is irreversible, expensive, outward-facing or legally significant. The gate is a state the system waits in, not a message the agent may skip. Record who approved what and when.

**Rules before models.** If a fixed rule can decide something (a threshold, an allowlist, a schema), a rule decides it and the model never sees the choice. Model judgement goes only where judgement is needed, and the result is checked by code where it can be.

**Context engineering.** Give each agent the least context that lets it do its job: its brief, its tools, and references (ids, paths) instead of payloads. Workers return short, structured results with sources. Long transcripts are never passed between agents. Compact or summarise at known points rather than letting context fill up.

**State and memory.** Keep three kinds apart:
- **Run state:** what this run has done. It is checkpointed so the run can resume.
- **Artifacts:** files and results, stored by reference.
- **Long-term memory:** facts kept across runs, each with where it came from. Only allowed agents may write it, and it can be deleted.

Untrusted content must never be written into memory that a more trusted agent later reads as instructions.

**Tools.** Use few, well-named tools with typed inputs and outputs and clear descriptions of when to use them. Make side-effecting tools idempotent (keyed by a request id), so a retry cannot double-act. Return errors the model can act on. A tool that can do anything (a shell, raw HTTP, SQL) is a trust decision, not a convenience.

**Protocols.**
- **MCP** connects an agent to tools and data.
- **A2A** connects an agent to another agent, usually one owned by someone else.
- Neither is a security boundary on its own: authenticate, authorise and validate at every hop.

**Durable execution.** Runs that last minutes to days need checkpoints, retries with idempotency keys, timeouts and resume, from a workflow engine (for example Step Functions, Temporal or Kestra), not from the agent's memory of what it did.

## 5. Security: contain by design, not by instruction

- **The lethal trifecta.** An agent that has (1) access to private data, (2) exposure to untrusted content and (3) a way to send data out can be turned against its owner by prompt injection. Design so that no single agent holds all three. Splitting agents along this line is the best use of multi-agent architecture.
- **Quarantine untrusted input.** One agent reads hostile content with no tools that matter and no secrets; it returns structured, validated data. A privileged agent acts only on that structured data, never on the raw text (the dual-model or quarantined-reader pattern).
- **Least reach, per agent and per run:**
  - Credentials scoped to the run and expiring with it.
  - Network egress on an allowlist.
  - A sandbox for any code the agent runs.
  - No standing access to production.
- **Stop paths outside the agent.** Budgets (steps, tokens, wall clock, money), a kill switch, and loop limits are enforced by the platform. A stop that needs the agent to cooperate is not a stop.
- **Validate outputs outside the model.** Use a schema, a policy check, a reproducer, or a second context. "The agent said it checked" is not a check.
- **Audit.** Every tool call is recorded, with the identity of the run and the agent, in a log the agent cannot change.

## 6. How multi-agent systems fail

The MAST study (UC Berkeley and others) annotated more than 1,600 traces from seven multi-agent frameworks. It grouped 14 failure modes into three categories. Use the categories as a review checklist.

| Category | Typical failures | Design answer |
|---|---|---|
| **System design and specification** | Agents ignore the task or their role; steps repeat; history is lost; nobody knows when the task is done | Written briefs per agent; explicit completion criteria in code; checkpointed state |
| **Inter-agent misalignment** | Agents talk past each other; information is withheld; one ignores another's input; reasoning and action do not match | Typed handoff payloads; summaries with sources; one owner per decision |
| **Task verification and termination** | Stops too early; stops never; verification is missing or shallow | A verifier with criteria, outside the maker's context; hard limits; outcome checks against ground truth |

Also plan for the failures of any distributed system: timeouts, partial failure, retries that double-act, poison inputs, and cost runaways.

## 7. Making it production-grade

- **Evaluations before scale.**
  - A fixed task set with known answers (for security work, a regression set of known findings).
  - Outcome metrics, plus trajectory checks (did it use the right tools, in a sensible order).
  - An LLM-as-judge only where it has been calibrated against people.
  - Re-run it on every change to prompts, tools, models or the harness.
- **Observability.** One trace per run, with a span per agent, model call and tool call, carrying tokens, latency, cost and the decision taken. Standard conventions (OpenTelemetry's generative-AI conventions) keep traces portable.
- **Cost and yield model.**
  - Cost per run, per successful outcome and per human hour saved or spent.
  - A budget cap per run and per day.
  - A kill criterion for the whole programme.
- **Versioning.** Prompts, tool definitions, model ids and the agent graph are versioned together. Every result records the configuration that produced it.
- **Rollout.** Shadow mode, then human-in-the-loop, then human-on-the-loop. Earn autonomy with measured accuracy, one action class at a time.

## 8. Mapping patterns onto frameworks

Check names against current documentation, and against the version actually pinned, before building. At the firm, an agent is built on **SmartSDK**, the firm's wrapper around Google ADK, which exposes only part of ADK. A pattern is available only if SmartSDK exposes the primitive it needs. Finding that out is the job of `smartsdk-enablement.md`.

**Google ADK changed shape in 2.0** (Python GA 19 May 2026). Agents, tools and functions are nodes in a `Workflow` graph. `SequentialAgent`, `ParallelAgent` and `LoopAgent` are deprecated from 2.0.0: they still run, but new flows should be written as a `Workflow`. When this guide was checked, a `Workflow` could not yet be used as an `LlmAgent` sub-agent. A wrapper may pin 1.x or an early 2.x, so read the pinned version from SmartSDK's own dependency files.

| Pattern | ADK 2.x | ADK 1.x (deprecated in 2.x) | Claude Agent SDK / Claude Code | Engine-agnostic |
|---|---|---|---|---|
| Chain | `Workflow` with edges in order | `SequentialAgent`, state through `output_key` | Skills or a script calling steps in order | Workflow-engine state machine |
| Fan-out / fan-in | `Workflow` fan-out edges, joined by a join node | `ParallelAgent`, then a merging agent | Parallel subagents; parent merges | Map state (Step Functions, Temporal) |
| Maker-checker loop | `Workflow` with a conditional edge back and a counter | `LoopAgent` with escalation exit and max iterations | Read-only reviewer subagent, fresh context | Loop with a counter |
| Orchestrator-workers | A coordinator `Agent` delegating to sub-agents, or the Task API | `LlmAgent` with `sub_agents`, or `AgentTool` | Main agent dispatching subagents with briefs | Task queue and worker pool |
| Agent as tool | Task API (single-turn, controlled output) | `AgentTool(agent)` | Subagent returning a result | Internal service |
| Remote agent | A2A support | A2A support | A2A or MCP, depending on the other side | HTTP contract with auth |
| Human gate | Workflow waits for human input; tool confirmation | Tool confirmation, long-running tool | Permission prompts, hooks, a pause state | Workflow wait state with a task token |
| Stop path | Graph limits, callbacks, plugins, platform limits | `max_iterations`, callbacks | Hooks, permission rules, `maxTurns`, sandbox | Orchestrator timeout and kill |

## 9. Deciding: the questions to answer, in order

1. What is the outcome, and how will we know a run succeeded? (If you cannot say, stop here.)
2. Is the path known in advance? Yes: a workflow. No: an agent.
3. Can one agent with good tools do it? Try it and measure it before you split.
4. Which of the five reasons to split applies? Name it. If none applies, do not split.
5. For each agent: what does it see, what must it never see, what can it reach, what stops it?
6. Where is the trust boundary, and does any agent hold the lethal trifecta?
7. Where does a person decide? Where does a rule decide?
8. What is the run's budget, and who or what enforces it?
9. How is a run evaluated, and what is the regression set?
10. What does a run cost, what is it worth, and what result would make us stop the programme?

Record the answer as a decision record (below). An open answer is an open question with an owner, not an assumption.

## 10. Decision record template

```markdown
# ADR-<n>: <decision in a few words>

Status: proposed | accepted | superseded by ADR-<m>     Date: <yyyy-mm-dd>     Decides: <who>

## Context
The problem, the constraints (trust, data, latency, cost, ownership) and the facts, each with a source.

## Options
For each option: the pattern(s), a sketch, what it costs (tokens, latency, people), how it fails, how it is contained.
Always include the simplest option (one call, or one agent).

## Decision
The option chosen and the reason to split, if it splits (one of the five).

## Consequences
What gets easier, what gets harder, what we must now build (evals, budgets, gates), and the signal that would make us revisit.

## Open questions
Each with who to ask.
```

## Sources

- Anthropic, "Building effective agents": https://www.anthropic.com/engineering/building-effective-agents
- Anthropic, "How we built our multi-agent research system": https://www.anthropic.com/engineering/multi-agent-research-system
- Model Context Protocol specification, version 2026-07-28 (stateless core): https://modelcontextprotocol.io/specification/2026-07-28
- A2A protocol (v1.0, Linux Foundation): https://a2a-protocol.org/latest/specification/
- Google ADK 2.0 (Workflow runtime, GA 19 May 2026): https://adk.dev/2.0/
- Google ADK, multi-agent systems: https://google.github.io/adk-docs/agents/multi-agents
- Google, "Developer's guide to multi-agent patterns in ADK": https://developers.googleblog.com/en/developers-guide-to-multi-agent-patterns-in-adk/
- Cemri et al., "Why Do Multi-Agent LLM Systems Fail?" (MAST): https://arxiv.org/abs/2503.13657
