# Discover, connect the dots, research

Read `core.md` first. This is Rhea's main reference; anyone reading sources or opening items follows it.

## Discover

Read before you draw, and record what you find as you go. First work out what kind of project this is, because it changes where the truth lives.

**A project with code.** Read in this order:

1. Orientation: README, docs, ADRs, onboarding guides, existing diagrams.
2. What actually runs: infrastructure code, CI/CD pipelines, container files.
3. Interfaces: API specs, route definitions, message schemas, topic and queue names.
4. Data: migrations, entity models, schemas. Who writes each table or topic.
5. Behaviour settings: config and environment variables. Timeouts, retries, limits, flags, dependency hostnames.
6. Code entry points: controllers, consumers, schedulers, outbound clients. Enough to confirm the flow.
7. Operations: runbooks, alerts, dashboards, incident write-ups.
8. Firm knowledge: wiki pages, tickets, standards, if a tool reaches them.

**A design-only project (documents, no code).** Read every document in date order, oldest first, and build a timeline of decisions. For each document note: date, what it covers, what it says it supersedes, and whether it is a design, a decision record, a review, a question log, or an inference. Then read saved notes and owner statements.

**A project with several systems.** List the systems first. Each gets its own design hierarchy; you add one top view above them (C0, see `structure.md`).

For a large project, split the reading: one helper agent per area (see "Research through other agents" below) and merge findings into the ledger.

For each component capture, where it exists: purpose, owner, runtime and scaling, interfaces offered, dependencies called, data owned, timeouts and retries, authentication, data classification, deployment target, alerts.

### Evidence ledger

`design/evidence-ledger.md`, one row per fact:

```
| ID  | Fact                                  | Source                                 | Status    | Stage    |
|-----|---------------------------------------|----------------------------------------|-----------|----------|
| E12 | Card call timeout is 2 seconds        | src/main/resources/application.yml:41  | confirmed | built    |
| E13 | Findings go to a separate database    | question-log.md D-15 (open)            | assumed   | proposed |
| E14 | Owner of the dead-letter queue        | not found                              | unknown   | built    |
```

**Status: how sure we are.**

- `confirmed` — seen directly in the strongest source available for this project (code or infrastructure if they exist; otherwise the governing document), or stated by the accountable person.
- `assumed` — a reasonable inference nobody has verified. This includes anything taken from a document that is itself a guess.
- `unknown` — needed, and not found.

**Stage: how far along it is.**

- `proposed` — written in a draft; nobody has decided.
- `decided` — the owner has decided; not yet built.
- `built` — exists and runs.
- `disputed` — sources or people disagree, and it is not settled.
- `deferred` — agreed, but not in the first version.
- `superseded` — replaced by a later decision; shown only so readers recognise the old design.

In a design-only project most rows will be `confirmed` (the document really says it) and `proposed`. That is expected: there, stage carries most of the meaning, and status mainly separates what a document states from what you inferred.

The two are independent. "The owner decided on PostgreSQL" is `confirmed` + `decided`. "The docs imply a queue here" is `assumed` + `proposed`.

### Which source wins

When sources disagree, rank them. Highest first:

1. Running code and deployed infrastructure (when the project has them).
2. A decision the owner has recorded (a decision log entry, a "decided" row, an explicit statement).
3. A document that explicitly says it supersedes another, for the parts it covers. A narrower later document replaces only its own scope; the rest of the older one still stands.
4. The current design document.
5. An independent review. A review is an argument, not a decision: it does not change the design until the owner accepts it. Draw the design as the owner has it and log each disagreement.
6. An inference or reconstruction.

Within the same rank, newer wins. If that still does not settle it (for example the two newest sources contradict each other, or a design was parked and then extended), **do not pick**: mark the part `disputed`, draw the best-supported version, and open a `conflict` item with both positions.

The same applies when the owner's own decisions contradict each other, or a decision log marks something "decided" in one place and still open in another: that is `disputed`, with the owner as the one who decides.

A stale document (one that still follows a superseded design) is not a part you can mark; record it as a `conflict` item naming the document and what it should be updated to.

Also keep a list of **sources that are cited but not available to you** (a walkthrough, a whiteboard, a missing appendix). They go in `DIAGRAM.missing` and usually deserve a research brief.

## Connect the dots

Cross-check the ledger and look for what nobody wrote down:

- **Dangling ends:** a consumer with no producer; a queue nobody reads; a hostname that matches no component; an API nobody calls.
- **Doc vs doc, doc vs reality:** two documents giving different numbers; a decision that silently breaks a feature described elsewhere; a document still describing something a later one replaced.
- **One name, two meanings:** the same term used for different things in different documents.
- **Rules and their exceptions:** a stated principle, and every place a later design violates it.
- **Missing return paths:** requests with no visible response or failure handling.
- **Implied components:** an outbox table implies a publisher; a token check implies an identity provider.
- **Ownership gaps:** two services writing one store; anything with no owner.
- **Boundary crossings:** data leaving a trust zone without stated protection; a path that lets restricted data reach a less restricted place.
- **Unstated numbers:** timeouts, limits, volumes and budgets that the design depends on but nobody has set.
- **Questions that already have an answer tool:** an open question in one place, and something elsewhere in the project that could answer it.
- **Use cases with holes:** walk each persona's journey and each external input end to end. Any step you cannot point to in the evidence is a gap.

Each finding becomes a fix to the diagram or an entry in `design/open-items.md`.

### Open items

Kinds: `question` (we need a fact), `risk` (it could go wrong), `conflict` (sources or people disagree). For each record: id, kind, status (`open` / `answered`), who to ask, the boxes it concerns (in every design where they appear), and the text. For a **conflict** also record each position with its source, what you drew, and who decides. Link the research brief and the ledger rows. All of these fields go on the page too (see the schema).

If the project already keeps its own question log, cite its ids; do not copy it.

## Research through other agents

You do not stall on a gap and you do not guess. You brief someone to find out.

**Who to ask, in order of preference:**

1. A sub-agent you can spawn in this session. Run independent briefs in parallel.
2. A teammate persona in the framework you are running in (analyst, architect, developer).
3. A connected tool that reaches firm knowledge (wiki, tickets, code search). Use it directly for simple lookups.
4. A person. If no agent or tool can reach the answer, write the brief for the user to route.

Only use the tools this session actually has. If you cannot reach a source, say so; do not imply you looked.

**Group briefs by who can answer**, not one per question: one brief per team or source, listing every question for them, most important first.

**Brief format** (`design/research/<id>-<topic>.md`):

```
Brief R07 — Dead-letter queue ownership
Status:        drafted | sent | answered | closed
Route to:      Payments on-call lead (or: sub-agent, Confluence search)
Open items:    q2, r5
Questions:     1. Who is responsible for draining payments-dlq?
               2. Is there an alarm on its depth?
Why it matters: Decides whether "receipt lost" is a handled failure or a silent one.
What I know:   Queue is defined in infra/sqs.tf:30. No consumer, runbook or alarm found.
Where to look: Ops runbooks space, alerting config repo, team on-call page.
Answer format: Owner (team), alarm yes/no with link, source for each. Say "not found" where applicable.
Do not:        Infer from naming. Report only what a source states.
Answer:        (filled in when it returns, with source and date)
```

Brief ids are stable. If you regroup between versions, retire the old id in the README ("R06 merged into R03") and do not reuse it.

When an answer returns: add it to the ledger with its source, update the affected status, stage and items, set the brief to `answered`, and redraw. An answer without a source stays `assumed`.

## Working from a spec: requirement traceability

When the starting point is a specification (a requirements document, a PRD, a ticket, an SOP), prove the design covers it.

1. **Build the register** in `design/requirements.md`, one row per requirement. Split compound sentences: one testable statement per row. Keep the spec's own numbering where it has one.

```
| ID   | Requirement (in the spec's words, shortened)   | Spec ref | Kind        | Covered by                          | Coverage  |
|------|------------------------------------------------|----------|-------------|-------------------------------------|-----------|
| R-07 | A repeated request must not charge twice       | §4.2     | functional  | containers/pay, use case "pay"      | covered   |
| R-12 | Recover within 4 hours if the Region is lost   | §7.1     | quality     | (nothing)                           | uncovered |
| R-15 | Support staff can refund                       | §5.3     | functional  | use case "refund"; no approval rule | partial   |
```

   Kinds: `functional`, `quality` (performance, availability, security, recovery), `constraint` (must use, must not use), `out of scope` (the spec says so).
2. **Link each one** to what covers it: boxes, arrows, use cases. A functional requirement needs a use case that walks it; a quality requirement needs a part of the design that delivers it, with evidence; a constraint needs to hold on every view.
3. **Put the gaps on the page.** For every `partial` or `uncovered` requirement add an item with `kind: "requirement"`, `status: "uncovered"` or `"partial"`, the requirement as its text, its spec reference in `ledger`, and `refs` to the nearest boxes. They then filter like any other open item. Covered requirements stay in the register only.
4. **Look the other way too.** A box or use case that no requirement asks for is either an undocumented requirement or scope creep. Open a question.
5. **Vague requirements are findings.** "Handle errors gracefully", "be secure", "scale": log a question asking for the testable version. Do not design to your own guess.

Report coverage in plain numbers: how many requirements, how many covered, partial, uncovered, out of scope.

## Keeping the files honest

- `deferred` means agreed, but not in the first version. Something merely proposed for later is `proposed` with a tag such as `later`; something argued over is `disputed`.
- `design/open-items.md` mirrors the page's items: one section per kind (conflicts, risks, questions, requirements), and per item its id, status, who to ask, the text, where it is drawn, and its brief if one exists. The page is the source; when they differ, fix the file. `python3 <design-kit>/page.py summary <page> --items` lists what the page holds.
