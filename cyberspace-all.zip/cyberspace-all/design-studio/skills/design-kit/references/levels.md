# One use case at every level, C0 to C4

Read `core.md` first. Maya and Finn both own this: Maya keeps the levels linked and named consistently, Finn writes the use cases through the deepest design.

## How it works

A reader picks a use case once and then asks for it at any level the design has (C0 to C4), on the map or as a sequence diagram, with the switch under the canvas or in the use case panel. The choice stays as they move from one use case to the next. You do not draw a use case four times. You write it **once, at the most detailed level you have**, and the page rolls it up:

- A step between two boxes becomes, one level up, a step between the boxes that stand for them there. A box stands for the box of the **same name** one level up; if there is none, it stands for the box that drills down into its design.
- Steps that end up inside one box are merged into a single "work inside this box" step.
- If two boxes are joined at the detailed level but the coarser design has no arrow between their stand-ins, the page shows the step in amber and the check warns. That is a real finding: the two levels of the design disagree. The warning names the detailed step. See "Settling an amber step" below.

So, to make every use case work at every level:

1. **Link the levels.** Every C2 view is the `child` of a box on its C1 view; every C3 view the `child` of a box on its C2 view; and so on. A view nothing drills into cannot be rolled up.
2. **Name the same thing the same way at every level.** "Ledger DB" on C2 and "Ledger DB" on C3 are one thing; "Ledger DB" and "Postgres" are two. Things outside the box being expanded (a neighbour service, a store, an external party) should appear on the detailed view under the same name they have above.
3. **Write each use case through the deepest design that covers it.** If a container has a component view, route the steps through the components. A use case written only at C2 looks the same at C3 and C4, and the page says so.
4. **Keep each level's arrows honest.** If a detailed step crosses between two containers, the C2 view needs that arrow, and the C1 view needs the arrow between their systems.
5. **Check it.** Run the check, then open two or three use cases and step through every level and the sequence diagram at each. A good use case reads as the same story told four times at different zoom.

When someone says "show me this use case at C2" or "draw the sequence for it at C1", there is nothing new to draw: confirm the use case is written at the deepest level, fix any amber steps, and point them at the switch.

## Flowcharts, deployments and other views that are not a C level

- **A flowchart (level `Flow`) never produces a call.** Its arrows are an order of states or decisions, so the page rolls every step in it up into one "work inside this box" step on the box the flowchart hangs from. A flowchart's boxes are states and decisions: name them as such ("Wait for approval", not the approver's name). If a step in the story really crosses between two components (a person approves, another service is called), tell that step on the structural view (C2 or C3), then go back into the flowchart.
- **Say which coarser box a box is, when the names differ:** `up: "<box id one level up>"` on the box. Use it for a resource on an AWS view ("Agent task" is the "Analysis" container) or any box whose name cannot match.
- **A view whose use cases should read the same at every level** (a deployment view of a whole system, a cross-cutting view) takes `rollup: false`. Without it, steps whose boxes map to nothing above are left out at coarser levels and the check warns.
- **A box can open more than one design.** `child` is the main drill-down and takes part in the roll-up; `also: ["<view id>", ...]` adds more ("Also open: …" in the box's panel), for example the AWS view of the system the box stands for.

## Settling an amber step

The check prints, for each one, the use case, the level, the two boxes and the detailed step number. There are four possible fixes; pick the true one and say which in the change log.

1. **The coarser design is missing an arrow.** Add it there (with its own status and stage).
2. **The use case takes a path the design does not have.** Fix the use case.
3. **Two boxes share a name but are not the same thing** (a state called "Sanitise" in a flowchart and a "Sanitise" service above). Rename the detailed one, or give it `up`.
4. **The detailed view hangs from the wrong box.** Move its `child` link to the box it really expands.

To see where a page stands before and after: `python3 <design-kit>/page.py summary design/<project>-design.html`, then `check.py`.
