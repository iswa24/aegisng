# Layout: give a drawing its shape before you place a box

Read `core.md` first. Everyone who draws follows this guide; Maya owns it.

A reader sees the shape of a drawing before reading one label. If the shape says nothing (boxes wherever they fitted, arrows running every way), the drawing looks scattered however correct its content is. So decide the shape first, in words. Then place boxes.

## The plan: five decisions per design

Write these down before you draw. One short line each is enough.

1. **Direction.** Left to right for anything that happens in an order: a request, data moving, a lifecycle, a use case. Top to bottom only for layers (people on top, stores at the bottom). Never right to left, never bottom to top.
2. **Columns say when.** What happens first is on the left. Name the columns, even where the drawing will not print the names. Example for a container design: *who asks · front door · does the work · keeps the data · outside systems*.
3. **Rows or lanes say who, or what kind.** One row per kind of thing (people in one row, stores in one row), or one lane per actor, team or zone.
4. **The main path is a straight line.** Pick the one story this design must tell, usually its main use case. Put that story's boxes on one row, in order, so its arrows run straight from left to right. Everything else hangs above or below the box it serves.
5. **Arrows that run back are the exception.** A reply rides on the forward arrow (its label, or `reply` on the use case step); it is not a second arrow. A true loop or feedback arrow is drawn once and marked `back: true`.

Record the plan on the design as `reads`, in one or two plain sentences. The page shows it under the design's question as "How to read it", and the next person who edits the design keeps to it:

```js
reads: "Left to right: who asks, the front door, the services, the stores. People sit on the top row, stores on the bottom row."
```

## The moves

These are the moves that turn a scattered design into an ordered one. Use them on every design, new or existing.

1. **Find the main path and lay it on one row.** Take the design's main use case and list its boxes in order. They become the middle row, left to right, evenly spaced. If the main path does not fit on one row, the design holds two stories; split it.
2. **People go on the top row or in the left column.** Never in the middle. A person or input that starts one system sits level with that system (left column); people who approve or oversee sit above what they approve (top row).
3. **Hang each dependency on the box that uses it.** A store, a substrate or an outside system used by one box goes straight above or below that box, so the arrow is short and vertical. Used by several boxes: put it in the column after the last of them.
4. **Move a box to the column before its targets.** If every arrow from a box points left, the box is in the wrong column. Put it left of what it points at.
5. **Keep zones as columns.** A frame is a zone; zones follow each other left to right in the order work passes through them. Do not stack a zone under another unless it serves only that one.
6. **Two-column form for "what may reach what".** For a design about permissions, crossings or blocked paths: actors in the left column, what they reach in the right column, one row per pair that is meant to work. Order the two columns so that the fewest lines cross.
7. **Long arrows are deliberate, and few.** A way back (a result returned to the start) runs along the bottom and is marked `back: true`. A way round (a path that skips a gate) runs just outside the frame it skips. Give each a `via` and `keep: true`. More than two long arrows means the columns are in the wrong order.
8. **Where two lines must cross, keep their labels apart.** Put each label near the start of its own line with `labelAt`, so nobody has to guess which line a label belongs to.
9. **Stay inside the page.** About six columns and five rows, 1,850px wide at most. If the order needs more, the design needs a child design.
10. **Say it.** Write the result in `reads`: direction, what the main row is, where the people are, what the long arrows are.

## How to work: plan, arrange, check, look

Do not nudge boxes one at a time. Write the whole plan for a design, apply it in one go, then look.

1. `python3 <design-kit>/page.py structure <page>`: read the numbers for the design.
2. Write a plan file. It holds positions and the `reads` line, nothing else:

```json
{
  "note": "Why this was re-laid (goes in the change log).",
  "designs": {
    "bounds": {
      "reads": "Left to right. On the left, what acts. On the right, what each could reach.",
      "place":  { "build": [0, 0], "sandbox": [0, 200], "uat": [520, 0], "prod": [520, 200] },
      "frames": { "Targets": { "x": 480, "y": -40, "w": 260, "h": 320, "labelPos": "tl" } },
      "routes": [ { "from": "rel", "to": "build", "via": [[1530, 900], [90, 900]], "fromSide": "bottom", "toSide": "bottom", "back": true, "keep": true },
                  { "from": "sandbox", "to": "uat", "labelAt": [282, 162] } ]
    }
  }
}
```

   - `place`: `[x, y]`, or `[x, y, w]`, or `[x, y, w, h]`, on the 20px grid. Boxes you leave out stay where they are.
   - `frames`: keyed by the start of the frame's label; a frame can only be moved or resized.
   - `routes`: only for the few arrows that need a set path or label position. Arrows touching a box you moved lose their old hand-set route, so they are drawn the simple way again.
3. `python3 <design-kit>/page.py arrange <page> <plan.json>`. It applies the plan, prints the before and after numbers, adds the change log entry, and **refuses to save if any box, arrow, label, use case or open item would differ**. A plan cannot rename, add or remove anything.
4. `python3 <design-kit>/check.py <page> <shots-dir>` and look at the screenshot of every design you moved. Fix the plan and run `arrange` again; do not hand-edit positions afterwards.

A design is done when it has no structure warning, its screenshot reads from the left without tracing a line backwards, and `reads` says what the reader sees.

## Which shape for which drawing

| Drawing | Shape |
|---|---|
| Use case diagram | Generated as swimlanes: one lane per actor, one column per phase. You supply the phases (below). |
| Flowchart, approval path, lifecycle, failure path: anything that is "who does what, in which order" | A **swimlane design**: lanes say who does the step, columns say when (below). |
| C0 to C3 structure | Columns by place in the request path, rows by kind, frames for zones. The main use case runs along one row. |
| AWS diagram | Nested AWS frames; traffic enters at the left. See `aws.md`. |
| Cross-cutting design (one concern across several systems) | One row per system and the same columns for each, so the reader compares down a column. |
| Schema | Its own rules; see `data-api.md`. |

## Swimlane designs

Give the design a `swim` block. Each box names its lane and column instead of `x` and `y`, and the page places it. Boxes in the same lane and column stack. Notes take a lane and column too.

```js
{ id: "timeout", name: "Failure: card timeout", level: "Flow", parent: "containers",
  question: "What do we do when the card network does not answer in time?",
  swim: {
    lanes: [{ id: "svc", label: "Payment service" }, { id: "ops", label: "Payments operations", sub: "people, next working day" }],
    cols:  [{ id: "call", label: "Call" }, { id: "decide", label: "Decide" }, { id: "act", label: "Act" }, { id: "hand", label: "Hand over" }]
  },
  nodes: [
    { id: "p", type: "service",  cat: "service", lane: "svc", col: "call",   label: "Payment service", sub: "calls card network" },
    { id: "d", type: "decision", cat: "edge",    lane: "svc", col: "decide", w: 180, h: 112, label: "Reply\nwithin 2s?" },
    ...
  ],
  edges: [{ from: "p", to: "d", label: "authorize" }, ...] }
```

To turn an existing flow design into lanes, write a lanes file and run `python3 <design-kit>/page.py lanes <page> <lanes.json>`. It sets the lanes, drops the coordinates and old arrow routes, adds the questions, and refuses to save if a box, an arrow, a label or an existing open item would change:

```json
{ "designs": { "disclosure": {
    "reads": "Each lane says who does the step. The columns run in order: find, review, decide, tell.",
    "lanes": [{ "id": "pipe", "label": "Scan pipeline" }, { "id": "rev", "label": "Findings reviewer" }, { "id": "ns", "label": "Not stated" }],
    "cols":  [{ "id": "find", "label": "Find" }, { "id": "review", "label": "Review" }, { "id": "tell", "label": "Tell" }],
    "cells": { "fdb": ["pipe", "find"], "rev": ["rev", "review"], "ticket": ["ns", "tell"] },
    "questions": [{ "text": "Who raises the internal ticket for a confirmed finding?", "owner": "Owner (architecture)", "refs": ["ticket"] }]
} } }
```

`cells` must name every box of the design, notes included. A "Not stated" lane needs at least one question saying whom to ask.

Rules that keep a swimlane design honest and readable:

- **A lane is a fact.** It says who does the step. Take it from the evidence. If the sources do not say who does a step, put it in a lane named "Not stated" and open a question. Do not guess an owner to make the picture tidy.
- **Three to six columns, two to six lanes.** More than that is two designs.
- **Columns are stages in order.** A step never sits to the left of a step that comes before it. If the story loops, draw the loop arrow and mark it `back: true`.
- **Most arrows stay in their lane.** An arrow that changes lane is a hand-over; a design that is all hand-overs has the wrong lanes.
- **Give labels room.** Columns are as wide as the widest box plus 90px. If the check says a label overlaps a box, set `colWidth` on `swim` (or in the lanes file) a little wider, or move one of the two boxes to the next column. Two boxes in one cell that an arrow joins are spaced for its label automatically.
- Leave the arrows unrouted. In edit mode, dragging a box drops it into the lane and column under the pointer.

## The use case diagram

The page draws it from the use cases. You make it read left to right by saying which phase each use case belongs to:

```js
phases: [{ id: "pay", label: "Take a payment" }, { id: "refund", label: "Refund" }, { id: "fail", label: "When something fails" }],
flows: [
  { id: "pay",    phase: "pay",    then: ["refund"], name: "Customer pays by card", actor: "Customer", ... },
  { id: "refund", phase: "refund", name: "Support agent refunds a payment", actor: "Support agent", ... }
]
```

- **Phases are the life of the work, in order**: what must exist first is on the left. Use three to six. Typical: *set up · start · run · review · close*. Name them in the project's own words.
- **Every use case gets one phase.** A failure belongs in the phase where it happens, not in a "failures" column at the end. A tour or an end-to-end story goes in a first phase such as "See the whole".
- **`then`** names the use cases this one leads to. Add it only where the use cases themselves say so (the last step of one is the start of the next). It draws an arrow, across lanes when the work changes hands.
- **Lanes are the actors**, taken from `actor`. Use cases with no single actor (`group`) get a lane of their own under the actors.
- Aim for no more than three use cases in one cell. A fuller cell means a phase is too broad or two use cases are one.

With no phases, the diagram still draws in lanes but cannot show an order, and the check says so.

## What the check measures

`python3 <design-kit>/page.py structure <page>` prints one line per design: boxes, arrows, how many arrows run right, left, down and up, how many rows and columns the boxes share, and whether the design is in lanes. The design check raises a warning when:

- most arrows run right to left or bottom to top;
- three or more arrows, and more than about a third of the arrows on the main axis, run against the main direction (not counting `blocked` arrows and arrows marked `back: true`);
- the boxes share almost no rows or columns (rows + columns is more than the number of boxes + 2);
- a flow design of eight or more steps is not in lanes.

The check also raises one warning listing the designs of six or more boxes that have no `reads` line: a design nobody has planned.

Fix the layout; do not silence the warning. The only way to switch it off is `structure: "free"` on a design, with the reason in `reads`. Use that for a drawing whose shape is its meaning, such as a hub with spokes.

## Starting from an existing design

Restructure before you add. Content changes on top of a scattered layout make it worse.

1. Run `python3 <design-kit>/page.py structure <page>` and read the table.
2. For each design it flags, write the five-line plan from the boxes that are already there.
3. Re-place the boxes with the moves above, through a plan file and `page.py arrange`, which guarantees **positions only**: same boxes, same arrows, same ids, same labels. Flow designs become swimlane designs; that adds who does each step, so take each lane from the evidence and do it as a separate, named change.
4. Give the use cases `phase` and, where the stories say so, `then`.
5. Run the check, take screenshots, and compare each design with its old screenshot. Record it in the change log as "restructured, content unchanged".
6. Only then make the content changes you came to make.

## Starting a new design

1. Choose the designs and their questions (`structure.md`).
2. For each design, write the five-line plan. For the use cases, list the phases.
3. Place boxes with the moves above: main path first, on one row; then people; then what each box depends on. Stay on the 20px grid and leave the arrows alone (`page.md`, "Layout rules").
4. Run `page.py structure` before the first screenshot. A design that fails here is re-planned, not nudged.
