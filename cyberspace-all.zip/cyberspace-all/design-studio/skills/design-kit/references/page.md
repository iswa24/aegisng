# The page: marking, visual language, layout, building, checking

Read `core.md` first. Field names are in `schema.md`.

### Mark confidence, stage and change

- Set `DIAGRAM.defaultStage` to the stage most parts are in (`built` for a running system, `proposed` for a draft design). A view can override it with its own `defaultStage` (for example one already-built system inside a mostly proposed project). Then set `stage` only on the parts that differ, arrows included. The page says "unmarked parts are …" in the legend.
- Set `status: "assumed"` or `"unknown"` on anything not confirmed.
- Use `style: "blocked"` for a path that is deliberately impossible (a sandbox that cannot reach production, a service with no database access). Containment designs need these. Both ends must be boxes on the view, so add a small external box for the thing that must not be reached ("Internet", "Production").
- `changed: true` marks what you added or altered **since the previous version**. In version 1 set none. Clear old flags when you bump the version.
- `tags` for cross-cutting concerns you want a lens for (card data, PII, internet-facing, "the review disagrees"). Add a matching entry to `lenses`.
- `details` and `facts` on important boxes **and arrows**, so a click shows owner, runtime and evidence. Give each fact its `source` and, where you can, its `ledger` id.

### Visual language (Lucid style)

- **Canvas:** white, light 20px dot grid.
- **Shapes** (`type`): `service` rounded rectangle; `db` cylinder; `queue` pill; `external` dashed grey rectangle; `actor` rectangle with person icon; `decision` diamond; `note` yellow sticky.
- **Colour means category** (`cat`), never decoration: `client` blue, `edge` purple, `service` green, `data` orange, `messaging` pink, `external` grey, `note` yellow. A new colour must be added to `CATS` so the legend shows it.
- **Arrows:** right-angle, rounded elbows. Solid = synchronous. Dashed (`style: "async"`) = asynchronous. Red dotted with a cross (`style: "blocked"`) = cannot reach.
- **Groups:** labelled frames. `kind: "boundary"` (dashed) for trust or account boundaries. `labelPos` moves the title: `tl` (default), `tr`, `bl`, `br`.

### Layout rules

**First decide the shape** (`layout.md`): direction, columns, rows or lanes, the main path. Flow designs are swimlane designs and need no coordinates at all. The rules below are for placing boxes once the shape is decided.

The page measures text, wraps it inside boxes, spreads arrows that share a side of a box, and moves an arrow's label off boxes and other labels. You still own where the boxes go.

**Draw lines the way a person would.** Nobody folds an arrow to join five boxes. The page picks the simplest line for every arrow you leave alone:

1. **straight across or straight down** when the two boxes line up (their sides overlap by 24px or more);
2. otherwise **one straight line at an angle**, when no other box is in the way;
3. otherwise **one corner**;
4. **two corners** only when nothing simpler is clear.

So the way to get clean lines is to place boxes well and then leave the arrows alone:

- Put boxes that talk to each other in the same row or the same column. Most arrows should come out straight.
- Do **not** set `fromSide`, `toSide`, `fromPort`, `toPort` or `via` on a first draft. Each one forces a folded line. Add one only after the check or a screenshot shows a real fault (an arrow through a box, two arrows on one line), and prefer moving a box.
- After drawing, run `python3 <design-kit>/page.py straighten <page>`. It lists every arrow whose hand-set hints make it bend more than it needs to; `--apply` removes them. Put `keep: true` on an arrow whose hand-set route you want left alone.
- The check warns about a small jog ("move one of the two boxes 20px"). Fix those; they are boxes a few pixels out of line.
- Schema views, AWS views and flowcharts keep right-angled lines, because that is their convention. Any view can choose: `lines: "elbow"` (right angles only) or `lines: "direct"` on the view, or on `DIAGRAM` for the whole page; `line` on one arrow.
- Look at the screenshot and count: in a view of up to about eight boxes, an arrow with two corners is a fault in the layout.

- Snap box positions to the 20px grid. Default box 180 x 72; make a box taller (92 or 100) when its text needs three lines. Diamonds about 180 x 112.
- Main flow left to right; supporting parts above or below the box that uses them.
- Column pitch **340** (180 box + 160 gap), row pitch 200. Arrow labels wrap at about 150px, so a 160px gap fits any label. Use a wider pitch only for a label you do not want wrapped.
- Keep labels short: a box name of 2 to 3 words, a sub-line of one fact, an arrow label of 2 to 5 words.
- 40px between a group frame and its boxes; leave about 30px at the top for the group title.
- An arrow must never pass through a box. The page already goes round a box when it can. If the check still reports one, move a box first; only then use `fromSide` / `toSide` or `via` waypoints (consecutive points share an x or a y). An arrow with `via` is not spread automatically, so it leaves from the centre of its side unless you also set `fromPort` / `toPort`.
- Arrows that fan out of one box, or into one box, are staggered for you. Two unrelated arrows can still bend on the same line; the check tells you, and a `via` or a small box move fixes it.
- Avoid crossings; if unavoidable, cross at right angles in open space.
- Decisions fan out from different sides (yes from top, no from bottom).
- Box ids are unique within a view. Use the same id for the same component across views where you can. Do not put `/` or `|` in ids.
- Two arrows between the same pair of boxes in the same direction each need an explicit `id`.

### Build the page

Copy `template.html` (in the design-kit folder) to `design/<project>-design.html`. Replace **only section 1** (`DIAGRAM`) and the `<title>`, and leave the `AWS-ICONS` block at the end of section 1 in place (run `aws_icons.py embed` to refill it). Keep the page title short (under about 40 characters). The page is one self-contained file with no outside libraries or fonts; do not add CDN links.

If the engine cannot express something you need, or you find a bug in it, do not patch it: draw the closest honest version, and report it.

What the reader can do, so you design for it:

- **Drill down** into a box marked `+`; breadcrumbs lead back; the menu shows the design tree with open-item counts.
- **Follow a use case** with numbered steps, Back / Next / Play, across designs, as a map or as a **sequence diagram**, **at any level from C0 to C4**. The C1 · C2 · C3 · C4 switch under the canvas also moves between levels when no use case is selected.
- **Use case diagram** generated from the use cases as swimlanes (a lane per actor, a column per phase, left to right); **data flow** switch on any view whose arrows carry `data`.
- **Click a box or an arrow** for its stage, evidence, the use cases through it and its open items.
- **Lenses:** gaps, one per stage in use, asynchronous, blocked, changed, plus your tag lenses.
- **Open items:** filtered to the current design by default, by kind and by who to ask; a conflict shows both positions, what is drawn and who decides.
- **Search** across boxes, use cases and open items; shareable links; export SVG.
- **Schema:** click a table for columns, notes and who writes it. **API:** click a service or a calling arrow for the endpoint; "API catalogue" lists them all. **Agents:** "Show what this can reach" on any box.
- **Run design check** (button at the bottom of the right panel).

## Check before anyone sees it

Run the check before anyone sees the page:

```
python3 <design-kit>/check.py design/<project>-design.html design/shots
```

It reports page errors, **problems** (must fix: missing links, arrows through boxes, overlapping boxes, flow steps that name an arrow that does not exist) and **warnings** (judgement calls: text that does not fit, overlapping labels, arrows sharing a line, off-grid boxes, very wide designs). Fix every problem. Fix warnings unless you have a reason; say which you left and why.

If you cannot run a browser, open the page yourself and use the **Run design check** button, which runs the same checks.

Then look at the screenshots, one per design. The check cannot see everything: read each design as a stranger would. Then confirm by hand:

- Each persona and external input has a use case, and each use case reads as a story from first step to last.
- Open two or three sequence diagrams and the use case diagram: do replies, conditions and actor names read correctly?
- Step two or three use cases through C1, C2, C3 and C4: does each level tell the same story, with no amber "no arrow here" steps?
- On views with `data`, switch to data flow: is any arrow that carries data left unlabelled?
- On an agent design, press "Show what this can reach" on each agent: can any of them reach something it should not?
- On a schema, does every table have a writer, and every foreign key a relationship line?
- On an AWS diagram: is every resource in the frame it really lives in, is every way in and out of the VPC drawn, and is every icon embedded?
- Nothing unverified is drawn as confirmed; nothing undecided is drawn as decided.
- Every `assumed` or `unknown` part is covered by an open item or an assumption note.
- Every fact shown in evidence is in the ledger with a source.
- Each view answers its stated question.
- Version, change log and `changed` flags reflect this round only.

### Publishing the page to Confluence (or any wiki or portal)

The page is one file and works inside a frame: the side columns shrink, the ☰ and Details buttons hide either one, and a Full screen button appears. Confluence does not run an HTML file as a page, so the design is shown in a frame on a Confluence page. Run `python3 <design-kit>/page.py confluence <page>`; it writes two snippets and says which to use:

- **Hosted copy** (the file sits on an internal web address; Confluence has an HTML or iframe macro): the frame points at the address. Links to one design or use case work (`...design.html#<view id>`), so several Confluence pages can each open on their own design.
- **Attached copy** (no hosting; the HTML macro is enabled): attach the file to the Confluence page and paste the snippet. To publish a new version, attach the new file under the same name.
- **Neither macro available:** the interactive page cannot be shown inside Confluence. Attach the file for download and put the screenshots from `check.py` on the page.

The HTML macro is switched off by default in Confluence Data Center and only an administrator can switch it on, so find out which macros exist before promising anyone an embedded page. Never paste the page's own HTML straight into a macro without the frame: its styles and scripts would collide with Confluence's.

### Zoom

A control at the bottom right of the drawing shows the zoom as a percentage, with minus and plus beside it (steps of ten). Clicking the number lists Fit all, 25%, 50%, 75%, 100%, 125%, 150%, 200%, 300% and 400%. 100% means one unit of the drawing is one pixel on screen, so text is at its designed size. The mouse wheel and a two-finger pinch change it too. Keys: `+` and `-` zoom, `0` fits, `1` is 100%. The percentage stays put when a panel opens or the window is resized; at Fit all the drawing stays fitted instead. Zoom runs from 10% to 400%.

### Editing in the page

A reader can add to the design without touching the data by hand. The **Edit** button in the header turns editing on; then:

- **Click a box or an arrow:** change its name or label, the line under the name, how sure it is, how far along it is, and its details (name and value pairs); add a note; raise a question, risk, conflict or requirement on it.
- **Click an open item:** set its status, write the answer or decision, and say who decided.
- **With nothing picked:** raise an item on the whole design, and set the name that goes on notes and the change log.
- **Draw:** in edit mode two buttons sit on the drawing. **+ Box**, then a click where it should go, adds a box (give it a name and a kind in the form). **+ Arrow** draws an arrow in either of two ways: click the start box and then the end box, or press on the start box and drag to the end box (a dashed line follows the pointer). A picked box also shows a blue handle beside it; dragging the handle onto another box draws an arrow from it. Give the arrow a label and a line kind in the form. Drag a box to move it; it snaps to the grid. A box or an arrow can be deleted from its form, with a second click to confirm, unless a use case walks through it or it opens another design.

Each change in the form shows on the drawing at once: picking a kind changes the shape, typing a name changes the label. There is no save button for the form; **Done** only closes it. Every edit is a small record. Edits are kept in that browser (the header shows "3 unsaved edits") and survive a reload. **Save file** downloads a copy of the page with the edits inside and a change log line; that copy is the new page. **Export edits** downloads just the edit records as a JSON file, for sending to whoever keeps the design.

The page works on a phone and in a narrow pane: the menu (☰) and the details open as drawers over the drawing, a tap selects, one finger pans and two fingers zoom. In a locked preview (a viewer that cannot store or download anything) editing still works, but nothing can be kept: the page says so and offers the edits as text to copy. To edit for real, open the file in a browser.

What a reader cannot do in the page: add or change designs, frames (zones) or use cases and their steps, or resize boxes. Those stay with the design team. Frames do not follow a box that is dragged out of them. The page does not route a hand-drawn arrow round a box that sits between its two ends; the design check reports it, and the fix is to move a box.

**When edits come back to the design team** (an edited page, or an exported edits file):

1. Put them into the working page: `python3 <design-kit>/page.py apply-edits <page> <edits.json>`. An edited page needs nothing; it already holds them.
2. Treat each edit as a statement by the person who made it. An answer or a decision becomes a ledger row with that person and date as its source, and the item's stage follows it. A note that states a fact becomes a ledger row too; a note that asks something becomes an item.
3. Boxes and arrows a reader added arrive with ids `new1`, `new2`, ... and the page's default stage. Give them a status, evidence or an open item like anything else; fit them into a frame and the use cases if they belong there; tidy the layout.
4. Bring `open-items.md` in line, add a change log entry, clear `changed` flags from the round before, run the check.

Never undo a reader's edit silently. If it is wrong, say so in a note or an item beside it.
