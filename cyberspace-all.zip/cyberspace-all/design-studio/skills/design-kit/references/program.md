# The program: direction, and reading everything first

Read `core.md` first. Sage, the program lead, owns this guide. Two rules in it bind every persona: **read everything before any work**, and **trace every piece of work to a goal**.

## 1. Read everything, in detail, before any work

People and agents both fall into the same trap: they read enough to form an impression, then start working, and the details they skipped come back as rework. In this team, nobody works on a source they have not read in full.

**What "read" means.** Every file in scope, every line, start to end. A summary in your own words of what the file says. At least one exact quote from every part of the file, to prove you got to the end and not just the top. Questions you could not answer from the file. Reading more than the scope is fine; reading less is not.

**The reading gate** (`<design-kit>/readgate.py`) makes this checkable:

1. **Declare the scope**, once per project:
   ```
   python3 <design-kit>/readgate.py init . cyberspace design/sources req agentic-work/smartsdk agentic-work/harness agentic-work/playbook
   ```
   - Folders mean every text file under them.
   - PDF, Word, slides and spreadsheets must be converted to text first, into `reading/<scope>/converted/`; the gate refuses them until then.
   - Different personas can have different scopes (for example `smartsdk` for Theo, `harness` for Hana).
2. **See the size of the job:** `readgate.py plan . <scope>` lists every file, its length, and the parts that each need a quote. The parts are about 120 lines, or a 25th of the file for long ones.
3. **Read, and log as you go,** in `reading/<scope>/<your name>.json`:
   ```json
   {"reader": "theo", "files": [{"path": "agentic-work/smartsdk/src/smartsdk/tools/registry.py",
     "sha256": "<sha256 of the file you read>",
     "summary": "At least 25 words of your own on what the file says and does.",
     "quotes": [{"line": 40, "quote": "words copied exactly from line 40"}],
     "questions": ["What happens to a confirmation when the process restarts?"]}]}
   ```
4. **Check:** `readgate.py check . <scope> <your name>`. It refuses the log when:
   - a file is missing from it, or new files have appeared since you read;
   - a file has changed since you read it (its hash no longer matches);
   - a quote is not on its line, or is too short to prove anything;
   - a part of a file has no quote;
   - a summary is thin.
5. **Only then work.** With the hooks installed (section 4), Claude Code blocks writing to `design/`, `agentic/` and `program/` until every scope has a reader who passed. When a source changes, the gate closes again until someone re-reads it.

The gate proves that every part of every file was opened and read. It cannot prove understanding; your summary, your questions and the quality of your work do that. Questions go to the open items, with who to ask. Never fill a gap in your reading with a guess.

**For very large sources** (a whole SDK repo), split the reading across agents, one scope or folder each. Each reader logs its own files, and the gate needs every file read by someone in that scope's logs. Then each persona reads the summaries and questions of the parts it did not read itself, before using them.

## 2. The charter (`program/charter.md`)

The charter is what "the right direction" means. The owner decides it; Sage keeps it.

```markdown
---
program: Cyberspace
status: draft            # draft | agreed (only when the owner says so)
owner: <role>
updated: YYYY-MM-DD
---
## North star           the owner's words, cited
## Goals                | Id | Goal | Measure | Source |          G1, G2, ...
## Non-goals            | Id | Not doing | Why | Source |         NG1, ...
## Decisions            | Id | Decision | Decided by | Date | Source |   only decisions the owner (or whoever holds that right) made
## Open decisions       | Id | Question | Who decides | Needed by |
## Priorities           the goals, in order (1. G3  2. G1 ...)
## Guardrails           rules everyone follows
```

`python3 <design-kit>/program.py check program` checks the charter. Every goal needs a measure and a source. Every decision needs who decided it and when. Priorities must order the goals.

**Everything traces to it.**
- Uma's use cases name their goals (`goals: [G1]`) and any decisions they rest on (`decisions: [D2]`).
- Theo's capabilities trace to goals through Uma's needs, and stories through capabilities.
- A use case that touches a non-goal says so (`nongoals_touched: [NG1]`), and that stops work until the owner answers.

## 3. The drift check (`program.py drift`)

```
python3 <design-kit>/program.py drift program . [--page design/<page>.html]
```

It reports:
- work that traces to no goal, or to a non-goal;
- work resting on a decision that is still open;
- stories and capabilities that lead back to no goal;
- open decisions past their date;
- goals with no work, and high priorities starved while lower ones get the effort;
- reading scopes nobody has read in full.

`program.py report program .` writes `program/report.md`: direction, work by goal in priority order, open decisions, features.

The script finds what can be counted. Sage reads the rest:
- does the work actually serve the goal it names, or only name it;
- are two personas solving the same problem;
- is a persona drifting into another's ground;
- is effort going where the owner's priorities say it should;
- has the latest work quietly changed something the owner decided?

## 4. Keeping it running

An agent cannot watch a project while nobody runs it, so Sage runs at three moments.

| When | How | What happens |
|---|---|---|
| **Every session** | Claude Code SessionStart hook | `program.py context` prints the briefing into the session: north star, goals in order, non-goals, open decisions, the rules, and the direction now. Every persona starts every session knowing where the program is going. |
| **Every write** | Claude Code PreToolUse hook | `readgate.py hook` blocks writing to `design/`, `agentic/` and `program/` until every reading scope has been read in full. |
| **On a schedule** | A scheduled job (CI nightly, or a scheduled Claude Code run) | `program.py report`, then Sage's DIRECTION review, posted where the team reads it |

The hook settings are in `<design-kit>/hooks/cyberspace-hooks.json`. Merge them into the project's `.claude/settings.json` and replace `SKILLS` with where the design kit is installed. The hooks guard Claude's Write and Edit tools, not shell commands. Persona rules forbid writing project files through the shell, and Vera's review checks it.

A scheduled run, for example nightly from CI on the build plane:

```
python3 <skills>/design-kit/program.py report program . --page design/<page>.html
claude -p "Act as Sage (design-agent-sage). Action DIRECTION. Read program/report.md and the work changed since the last report, and write program/direction-<date>.md."
```

## 5. Sage's direction review (DIRECTION)

1. Read the charter, the last report and every file changed since; pass the reading gate for anything new.
2. Run `program.py drift` and `report`.
3. For each feature and persona, answer in one line each:
   - Which goal is this serving?
   - Is it the right priority now?
   - Is it resting on anything undecided?
   - Is anyone else doing the same thing?
4. Write `program/direction-<date>.md` with four parts:
   - **On course:** what is fine.
   - **Off course:** what to stop or change, and who.
   - **Waiting on the owner:** open decisions, oldest first.
   - **Next:** the three most important pieces of work, by goal.
5. Never change another persona's work. Sage says what is off course and to whom, and checks next time that it moved.
