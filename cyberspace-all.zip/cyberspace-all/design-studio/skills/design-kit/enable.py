#!/usr/bin/env python3
"""Feature enablement on SmartSDK: registers, checks and hand-off.

  python3 enable.py init <agentic-dir> <feature>   create the folders and empty registers for one feature
  python3 enable.py check <agentic-dir> <feature>  check the registers: every claim about SmartSDK, the harness, the
                                                   requirements or the firm playbook points at a real file and line
                                                   that contains the quoted text; every gap is covered and decided;
                                                   every story is buildable and blocked by what it depends on
  python3 enable.py render <agentic-dir> <feature> write the hand-off: one story file per story (BMad story format),
                                                   the enablement report, and a stub design brief if none exists
  python3 enable.py playbook <agentic-dir>         check the firm playbook on its own

The layout and the meaning of every field are in references/smartsdk-enablement.md.
Nothing here imports, installs or runs SmartSDK or the harness: they are read as text.
"""
import sys, json, re, pathlib, datetime

STATUS = ["exposed", "partial", "not-exposed", "not-in-adk", "blocked-by-policy", "unknown"]
GAP_TYPES = ["expose", "extend", "build-in-app", "bridge-service", "policy", "unknown"]
SEVERITY = ["blocker", "major", "minor"]
ROOTS = ["smartsdk", "harness", "req", "playbook", "work"]   # work = the agentic folder itself (AOPs, eval sets, prototypes)

def load(p, default):
    p = pathlib.Path(p)
    if not p.exists(): return default
    try: return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e: sys.exit(f"{p}: not valid JSON ({e})")

def init(base, feature):
    base = pathlib.Path(base); f = base / feature
    (f / "change-requests").mkdir(parents=True, exist_ok=True); (f / "handoff" / "stories").mkdir(parents=True, exist_ok=True)
    src = base / "sources.json"
    if not src.exists():
        src.write_text(json.dumps({"smartsdk": "path/to/smartsdk-repo", "harness": "path/to/claude-harness", "req": "path/to/requirements",
                                   "playbook": "path/to/firm-agent-builder-knowledge", "smartsdk_version": "", "adk_pinned": "",
                                   "adk_latest_checked": "", "checked_on": ""}, indent=1))
    pb = base / "playbook.json"
    if not pb.exists(): pb.write_text("[]\n")
    for name in ("capabilities", "gaps", "stories"):
        p = f / f"{name}.json"
        if not p.exists(): p.write_text("[]\n")
    print(f"ready: {f}\nFill sources.json first (where the SmartSDK repo, the harness, the requirements and the firm's agent-builder knowledge are).")

class Ctx:
    def __init__(self, base):
        self.base = pathlib.Path(base); self.src = load(self.base / "sources.json", None)
        if self.src is None: sys.exit(f"{self.base}/sources.json is missing. Run: enable.py init {self.base} <feature>")
        self.err, self.warn = [], []
    def root(self, k):
        if k == "work": return self.base.resolve()
        p = self.src.get(k)
        if not p: return None
        p = pathlib.Path(p); return p if p.is_absolute() else (self.base / p).resolve()

def norm(t): return re.sub(r"\s+", " ", t).strip()

def cite_ok(ctx, c, where, need_quote=True):
    """A cite is {"ref": "<root>:<path>:<line or start-end>", "quote": "text found in those lines"} or {"url": "https://..."}."""
    if not isinstance(c, dict): ctx.err.append(f"{where}: a citation must be an object with ref and quote, or url"); return False
    if c.get("url"):
        if not re.match(r"https?://", c["url"]): ctx.err.append(f"{where}: url must start with http(s)://"); return False
        return True
    m = re.fullmatch(r"([a-z]+):(.+):(\d+)(?:-(\d+))?", c.get("ref", "") or "")
    if not m: ctx.err.append(f"{where}: ref must look like smartsdk:src/pkg/file.py:120-134 (got {c.get('ref')!r})"); return False
    root, rel, a, b = m.group(1), m.group(2), int(m.group(3)), int(m.group(4) or m.group(3))
    if root not in ROOTS: ctx.err.append(f"{where}: unknown root {root!r}; use one of {', '.join(ROOTS)}"); return False
    r = ctx.root(root)
    if r is None: ctx.err.append(f"{where}: sources.json does not say where {root!r} is"); return False
    fp = (r / rel).resolve()
    if not str(fp).startswith(str(r)): ctx.err.append(f"{where}: {c['ref']} points outside {root}"); return False
    if not fp.is_file(): ctx.err.append(f"{where}: {c['ref']}: no such file"); return False
    lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
    if not (1 <= a <= b <= len(lines)): ctx.err.append(f"{where}: {c['ref']}: lines {a}-{b} outside the file ({len(lines)} lines)"); return False
    q = c.get("quote")
    if not q:
        if need_quote: ctx.err.append(f"{where}: {c['ref']}: add the quote (the text the claim rests on) so it can be re-checked"); return False
        return True
    if norm(q) not in norm(" ".join(lines[a - 1:b])): ctx.err.append(f"{where}: {c['ref']}: the quote {q[:60]!r} is not in those lines"); return False
    return True

def check_playbook(ctx):
    pb = load(ctx.base / "playbook.json", []); ids = set()
    for i, r in enumerate(pb):
        w = f"playbook[{r.get('id', i)}]"
        if not r.get("id") or not r.get("rule"): ctx.err.append(f"{w}: needs id and rule"); continue
        if r["id"] in ids: ctx.err.append(f"{w}: duplicate id")
        ids.add(r["id"])
        if r.get("status") not in ("confirmed", "proposed"): ctx.err.append(f"{w}: status must be confirmed (the firm's agent builders say so) or proposed (learned here, not yet confirmed)")
        if r.get("status") == "confirmed":
            cs = r.get("cites") or []
            if not cs: ctx.err.append(f"{w}: a confirmed rule cites where the firm says it")
            for j, c in enumerate(cs): cite_ok(ctx, c, f"{w}.cites[{j}]")
        elif not r.get("learned_from"): ctx.err.append(f"{w}: a proposed rule says which feature or run it was learned from")
    return {r["id"]: r for r in pb if r.get("id")}

def check(base, feature, quiet=False):
    ctx = Ctx(base); f = ctx.base / feature
    if not f.is_dir(): sys.exit(f"no feature folder {f}. Run: enable.py init {base} {feature}")
    for k in ("smartsdk", "harness", "req"):
        r = ctx.root(k)
        if r is None or not r.exists(): ctx.warn.append(f"sources.json: {k} is not set or does not exist ({ctx.src.get(k)!r})")
    if not ctx.src.get("adk_pinned"): ctx.err.append("sources.json: adk_pinned is empty. Read the ADK version SmartSDK pins from its dependency files, and cite it in a capability or say unknown")
    if not ctx.src.get("checked_on"): ctx.warn.append("sources.json: checked_on is empty (the date the ADK and harness facts were checked)")
    PB = check_playbook(ctx)
    caps = load(f / "capabilities.json", []); gaps = load(f / "gaps.json", []); stories = load(f / "stories.json", [])
    C = {}
    for i, c in enumerate(caps):
        w = f"capability {c.get('id', i)}"
        for k in ("id", "need", "acceptance"):
            if not c.get(k): ctx.err.append(f"{w}: needs {k}")
        if c.get("id") in C: ctx.err.append(f"{w}: duplicate id")
        C[c.get("id")] = c
        if not c.get("from_req"): ctx.err.append(f"{w}: from_req must cite the requirement it comes from")
        else: cite_ok(ctx, c["from_req"], f"{w}.from_req")
        h = c.get("harness")
        if h:
            for j, x in enumerate(h.get("cites") or []): cite_ok(ctx, x, f"{w}.harness.cites[{j}]")
            if not h.get("cites"): ctx.err.append(f"{w}: harness says how the Claude harness does it; cite the files")
        a = c.get("adk") or {}
        if not a.get("primitive"): ctx.err.append(f"{w}: adk.primitive is empty (the ADK primitive that provides this, or 'none')")
        elif a["primitive"] != "none" and not a.get("cites"): ctx.err.append(f"{w}: adk.cites: cite ADK source or documentation at the pinned version")
        for j, x in enumerate(a.get("cites") or []): cite_ok(ctx, x, f"{w}.adk.cites[{j}]")
        s = c.get("smartsdk") or {}
        if s.get("status") not in STATUS: ctx.err.append(f"{w}: smartsdk.status must be one of {', '.join(STATUS)}")
        elif s["status"] == "unknown":
            if not s.get("question"): ctx.err.append(f"{w}: status unknown needs a question and who to ask (smartsdk.question, smartsdk.ask)")
        elif s["status"] != "not-in-adk" and not s.get("cites"): ctx.err.append(f"{w}: smartsdk.cites: cite the SmartSDK source that shows it is {s['status']}")
        for j, x in enumerate(s.get("cites") or []): cite_ok(ctx, x, f"{w}.smartsdk.cites[{j}]")
        for p in c.get("playbook") or []:
            if p not in PB: ctx.err.append(f"{w}: playbook rule {p} does not exist")
    G = {}; covered = {}
    for i, g in enumerate(gaps):
        w = f"gap {g.get('id', i)}"
        if not g.get("id"): ctx.err.append(f"{w}: needs id"); continue
        G[g["id"]] = g
        if g.get("type") not in GAP_TYPES: ctx.err.append(f"{w}: type must be one of {', '.join(GAP_TYPES)}")
        if g.get("severity") not in SEVERITY: ctx.err.append(f"{w}: severity must be one of {', '.join(SEVERITY)}")
        if not g.get("capabilities"): ctx.err.append(f"{w}: name the capabilities it blocks")
        for x in g.get("capabilities") or []:
            if x not in C: ctx.err.append(f"{w}: capability {x} does not exist")
            covered.setdefault(x, []).append(g["id"])
        if not (g.get("decision") or g.get("question")): ctx.err.append(f"{w}: needs a decision (what we will do) or an open question with who to ask")
        if g.get("question") and not g.get("ask"): ctx.err.append(f"{w}: say who to ask (ask)")
        if not isinstance(g.get("ladder"), int) or not 1 <= g["ladder"] <= 5: ctx.err.append(f"{w}: ladder is 1 to 5 (1 configuration, 2 code in our app, 3 a different structure inside ADK, 4 a SmartSDK change, 5 a separate service)")
        if g.get("type") in ("expose", "extend"):
            cr = g.get("change_request")
            if not cr: ctx.err.append(f"{w}: a gap SmartSDK must close needs a change_request (CR id)")
            elif not (f / "change-requests" / f"{cr}.md").exists(): ctx.err.append(f"{w}: change-requests/{cr}.md does not exist")
            else:
                t = (f / "change-requests" / f"{cr}.md").read_text(encoding="utf-8")
                for sec in ("## Problem", "## Proposed API", "## Acceptance tests", "## Alternatives"):
                    if sec not in t: ctx.err.append(f"change-requests/{cr}.md: missing section {sec!r}")
        for p in g.get("playbook") or []:
            if p not in PB: ctx.err.append(f"{w}: playbook rule {p} does not exist")
    inv = load(f / "inventory.json", None)
    if inv is not None:   # Hana's harness inventory: every construct is delivered by a capability or left out with a reason
        oos = {o.get("construct"): o for o in load(f / "out-of-scope.json", [])}
        for o in oos.values():
            if not o.get("reason"): ctx.err.append(f"out-of-scope.json: {o.get('construct')} needs a reason")
        used = {x for c in caps for x in (c.get("constructs") or [])}
        ids = {k["id"] for k in inv.get("constructs", [])}
        for x in sorted(used - ids): ctx.err.append(f"a capability names harness construct {x}, which is not in inventory.json")
        for k in inv.get("constructs", []):
            if k["id"] not in used and k["id"] not in oos: ctx.err.append(f"harness construct {k['id']} ({k['kind']}: {k['name']}) is neither delivered by a capability (constructs) nor in out-of-scope.json")
    for cid, c in C.items():
        st = (c.get("smartsdk") or {}).get("status")
        if st in ("partial", "not-exposed", "not-in-adk", "blocked-by-policy") and cid not in covered: ctx.err.append(f"capability {cid}: SmartSDK status is {st} but no gap covers it")
    S = {s.get("id"): s for s in stories}
    for i, s in enumerate(stories):
        w = f"story {s.get('id', i)}"
        for k in ("id", "epic", "title", "as_a", "i_want", "so_that", "context"):
            if not s.get(k): ctx.err.append(f"{w}: needs {k}")
        ac = s.get("acceptance") or []
        if not ac: ctx.err.append(f"{w}: needs acceptance criteria")
        for j, x in enumerate(ac):
            if not all(x.get(k) for k in ("given", "when", "then")): ctx.err.append(f"{w}: acceptance[{j}] needs given, when and then")
        if not s.get("tests"): ctx.err.append(f"{w}: say how each criterion is tested (tests)")
        if not s.get("capabilities"): ctx.err.append(f"{w}: name the capabilities it delivers")
        deps = set(s.get("depends_on") or [])
        for d in deps:
            if not (d in S or d in G or (f / "change-requests" / f"{d}.md").exists()): ctx.err.append(f"{w}: depends on {d}, which is not a story, gap or change request here")
        for x in s.get("capabilities") or []:
            if x not in C: ctx.err.append(f"{w}: capability {x} does not exist"); continue
            for gid in covered.get(x, []):
                g = G[gid]
                if g.get("severity") == "blocker" and gid not in deps and g.get("change_request") not in deps:
                    ctx.err.append(f"{w}: delivers {x}, which blocker {gid} stops; add {g.get('change_request') or gid} to depends_on")
        for j, x in enumerate(s.get("smartsdk_apis") or []): cite_ok(ctx, x, f"{w}.smartsdk_apis[{j}]")
        for j, x in enumerate(s.get("replaces") or []): cite_ok(ctx, x, f"{w}.replaces[{j}]")
        if not s.get("smartsdk_apis") and not s.get("no_smartsdk_reason"): ctx.err.append(f"{w}: cite the SmartSDK APIs the developer will use (smartsdk_apis), or say why none (no_smartsdk_reason)")
        if not s.get("guardrails"): ctx.warn.append(f"{w}: no guardrails listed (what the agent must never see, reach or do)")
        if s.get("fits_one_session") is not True: ctx.err.append(f"{w}: fits_one_session must be true: split the story until one agent session can build and test it")
    for k, s in S.items():
        seen, stack = set(), list(s.get("depends_on") or [])
        while stack:
            d = stack.pop()
            if d == k: ctx.err.append(f"story {k}: depends on itself through {', '.join(sorted(seen))}"); break
            if d in seen or d not in S: continue
            seen.add(d); stack += S[d].get("depends_on") or []
    brief = f / "handoff" / "design-brief.md"
    if stories and not brief.exists(): ctx.err.append("handoff/design-brief.md is missing: write the brief for the designers (render writes a stub)")
    elif brief.exists():
        t = brief.read_text(encoding="utf-8")
        if "TODO" in t: ctx.err.append("handoff/design-brief.md still has TODO sections")
        for gid, g in G.items():
            if g.get("severity") == "blocker" and gid not in t: ctx.err.append(f"handoff/design-brief.md does not mention blocker {gid}")
    if not quiet:
        for m in ctx.err: print("PROBLEM:", m)
        for m in ctx.warn: print("warning:", m)
        n = {k: sum(1 for c in caps if (c.get("smartsdk") or {}).get("status") == k) for k in STATUS}
        print(f"\n{len(caps)} capabilities ({', '.join(f'{v} {k}' for k, v in n.items() if v)}), {len(gaps)} gaps "
              f"({sum(1 for g in gaps if g.get('severity') == 'blocker')} blockers), {len(stories)} stories, {len(PB)} playbook rules.")
        print(f"Problems: {len(ctx.err)}   Warnings: {len(ctx.warn)}")
    return ctx, caps, gaps, stories, PB

def slug(t): return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")[:50]
def show(c): return c.get("url") or f"`{c['ref']}`" + (f" — `{c['quote']}`" if c.get("quote") else "")

def render(base, feature):
    ctx, caps, gaps, stories, PB = check(base, feature, quiet=True)
    if ctx.err:
        for m in ctx.err: print("PROBLEM:", m)
        sys.exit(f"\nNot rendered: fix the {len(ctx.err)} problem(s) first. The hand-off is only as good as the registers.")
    f = pathlib.Path(base) / feature; out = f / "handoff"; (out / "stories").mkdir(parents=True, exist_ok=True)
    C = {c["id"]: c for c in caps}; G = {g["id"]: g for g in gaps}
    for p in (out / "stories").glob("*.md"): p.unlink()
    for s in stories:
        L = [f"# Story {s['id']}: {s['title']}", "", "Status: Draft", "", f"Epic: {s['epic']}", "", "## Story", "",
             f"As {s['as_a']},", f"I want {s['i_want']},", f"so that {s['so_that']}.", "", "## Acceptance Criteria", ""]
        for i, a in enumerate(s["acceptance"], 1): L.append(f"{i}. **Given** {a['given']}, **when** {a['when']}, **then** {a['then']}.")
        L += ["", "## Tasks / Subtasks", ""]
        for t in s.get("tasks") or ["Implement to the acceptance criteria", "Write the tests below"]: L.append(f"- [ ] {t}")
        L += ["", "## Dev Notes", "", s["context"], "", "### SmartSDK APIs to use", ""]
        L += [f"- {show(x)}" for x in s.get("smartsdk_apis") or []] or [f"- None: {s.get('no_smartsdk_reason')}"]
        if s.get("replaces"): L += ["", "### What it replaces in the Claude harness", ""] + [f"- {show(x)}" for x in s["replaces"]]
        L += ["", "### Capabilities", ""]
        for x in s["capabilities"]:
            c = C[x]; L.append(f"- **{x}** {c['need']} (SmartSDK: {c['smartsdk']['status']}). Done when: {c['acceptance']}")
        pr = sorted({p for x in s["capabilities"] for p in (C[x].get("playbook") or [])})
        if pr: L += ["", "### Firm rules that apply", ""] + [f"- **{p}** ({PB[p]['status']}) {PB[p]['rule']}" for p in pr]
        if s.get("guardrails"): L += ["", "### Guardrails", ""] + [f"- {g}" for g in s["guardrails"]]
        L += ["", "### Testing", ""] + [f"- {t}" for t in s["tests"]]
        if s.get("depends_on"):
            L += ["", "### Depends on", ""]
            for d in s["depends_on"]:
                L.append(f"- {d}" + (f": {G[d].get('decision') or G[d].get('question')}" if d in G else f" (change request, `change-requests/{d}.md`)" if (f / 'change-requests' / f'{d}.md').exists() else ""))
        if s.get("out_of_scope"): L += ["", "### Out of scope", ""] + [f"- {x}" for x in s["out_of_scope"]]
        if s.get("open_questions"): L += ["", "### Open questions", ""] + [f"- {x}" for x in s["open_questions"]]
        L += ["", "### References", "", f"- Enablement analysis: `{feature}/capabilities.json`, `gaps.json`", "", "## Dev Agent Record", "", "### Agent Model Used", "", "### Completion Notes List", "", "### File List", ""]
        (out / "stories" / f"{s['id']}-{slug(s['title'])}.md").write_text("\n".join(L), encoding="utf-8")
    R = [f"# Enablement report: {feature}", "", f"Generated {datetime.date.today().isoformat()} from the registers. SmartSDK {ctx.src.get('smartsdk_version') or '(version not stated)'}, "
         f"ADK pinned {ctx.src.get('adk_pinned')}, latest ADK checked {ctx.src.get('adk_latest_checked') or '(not stated)'}, facts checked on {ctx.src.get('checked_on') or '(not stated)'}.", "",
         "## Capabilities", "", "| Id | The feature needs | Claude harness today | ADK primitive | SmartSDK | Gap |", "|---|---|---|---|---|---|"]
    cov = {}
    for g in gaps:
        for x in g["capabilities"]: cov.setdefault(x, []).append(g["id"])
    for c in caps:
        R.append(f"| {c['id']} | {c['need']} | {(c.get('harness') or {}).get('how', '-')} | {c['adk']['primitive']} | {c['smartsdk']['status']} | {', '.join(cov.get(c['id'], [])) or '-'} |")
    R += ["", "## Gaps", "", "| Id | Severity | Type | Ladder | Decision or question | Change request |", "|---|---|---|---|---|---|"]
    for g in sorted(gaps, key=lambda g: SEVERITY.index(g["severity"])):
        R.append(f"| {g['id']} | {g['severity']} | {g['type']} | {g['ladder']} | {g.get('decision') or 'Open: ' + g['question'] + ' (ask ' + g['ask'] + ')'} | {g.get('change_request') or '-'} |")
    R += ["", "## Stories", "", "| Id | Epic | Title | Depends on |", "|---|---|---|---|"]
    for s in stories: R.append(f"| {s['id']} | {s['epic']} | {s['title']} | {', '.join(s.get('depends_on') or []) or '-'} |")
    unknown = [c for c in caps if c["smartsdk"]["status"] == "unknown"]
    if unknown: R += ["", "## Unknown", ""] + [f"- {c['id']}: {c['smartsdk']['question']} (ask {c['smartsdk'].get('ask', '?')})" for c in unknown]
    (out / "enablement-report.md").write_text("\n".join(R) + "\n", encoding="utf-8")
    print(f"wrote {len(stories)} stories to {out/'stories'} and {out/'enablement-report.md'}")

def stub_brief(base, feature):
    p = pathlib.Path(base) / feature / "handoff" / "design-brief.md"
    if p.exists(): return
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("# Design brief: " + feature + "\n\nTODO: written by Theo for Maya, Aria and Finn. Sections, in order:\n\n"
                 "## What the feature does\n## The chosen pattern and why\n## Agents: what each sees, must never see, reaches, and what stops it\n"
                 "## Flows to draw (main and every failure path)\n## Blockers (every blocker gap id, and what the drawing must show until it is closed)\n"
                 "## What SmartSDK gives us and what it does not\n## Open questions\n", encoding="utf-8")
    print(f"wrote a stub {p}: Theo fills it before render")

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) == 3 and a[0] == "init": init(a[1], a[2]); stub_brief(a[1], a[2])
    elif len(a) == 3 and a[0] == "check":
        ctx = check(a[1], a[2])[0]; sys.exit(1 if ctx.err else 0)
    elif len(a) == 3 and a[0] == "render": render(a[1], a[2])
    elif len(a) == 2 and a[0] == "playbook":
        ctx = Ctx(a[1]); pb = check_playbook(ctx)
        for m in ctx.err: print("PROBLEM:", m)
        print(f"{len(pb)} rules ({sum(1 for r in pb.values() if r.get('status') == 'confirmed')} confirmed). Problems: {len(ctx.err)}"); sys.exit(1 if ctx.err else 0)
    else: print(__doc__); sys.exit(2)
