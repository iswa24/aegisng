#!/usr/bin/env python3
"""Find official AWS icons and embed the ones a design uses into its page.

  python3 aws_icons.py search <words>        find icon keys, e.g. "search load balancer"
  python3 aws_icons.py list [Category]       list categories, or the keys in one category
  python3 aws_icons.py embed <design.html>   embed every icon the page refers to (boxes with icon: "aws:<key>", and AWS frames)

Only the icons a page uses are embedded, so the page stays one self-contained file.
The icons are unmodified AWS Architecture Icons; see AWS-ICONS-NOTICE.txt.
"""
import sys, re, json, difflib, pathlib

HERE = pathlib.Path(__file__).resolve().parent
PACK = json.loads((HERE / "aws-icons.json").read_text(encoding="utf-8"))
ICONS, CATS = PACK["icons"], PACK["categories"]
CAT_OF = {k: c for c, ks in CATS.items() for k in ks}
FRAMES = {"aws-cloud": "aws-cloud", "aws-account": "aws-account", "region": "region", "vpc": "vpc",
          "public-subnet": "public-subnet", "private-subnet": "private-subnet", "asg": "auto-scaling-group",
          "datacenter": "corporate-data-center"}
BEGIN, END = "/* AWS-ICONS:BEGIN", "/* AWS-ICONS:END */"

def search(words):
    short = {"s3": "simple-storage-service", "sqs": "simple-queue-service", "sns": "simple-notification-service",
             "ecs": "elastic-container-service", "eks": "elastic-kubernetes-service", "ecr": "elastic-container-registry",
             "ebs": "elastic-block-store", "efs": "efs", "iam": "identity-and-access-management", "kms": "key-management-service",
             "alb": "application-load-balancer", "nlb": "network-load-balancer", "elb": "elastic-load-balancing",
             "ses": "simple-email-service", "acm": "certificate-manager", "nat": "nat-gateway", "igw": "internet-gateway"}
    words = [short.get(w.lower(), w.lower()) for w in words]
    hits = [k for k in ICONS if all(w in k or w in CAT_OF.get(k, "").lower() for w in words)]
    if not hits:
        hits = difflib.get_close_matches("-".join(words), list(ICONS), n=12, cutoff=0.6)
        if hits: print("No icon has all of those words. Closest names (check they are what you mean):")
    for k in sorted(hits, key=len)[:40]:
        print(f"aws:{k:<60} {CAT_OF.get(k, '')}")
    if not hits: print("No match. Try one word, or: python3 aws_icons.py list")

def embed(path):
    p = pathlib.Path(path); s = p.read_text(encoding="utf-8")
    keys = set(re.findall(r'''["']?icon["']?\s*:\s*["']aws:([^"']+)["']''', s))
    for kind in re.findall(r'''["']?kind["']?\s*:\s*["']([a-z-]+)["']''', s):
        if kind in FRAMES: keys.add(FRAMES[kind])
    bad = sorted(k for k in keys if k not in ICONS)
    if bad:
        for k in bad:
            print(f'Unknown icon "aws:{k}". Closest: ' + ", ".join("aws:" + m for m in difflib.get_close_matches(k, list(ICONS), n=4, cutoff=0.3)))
        sys.exit(1)
    out = {k: {"body": ICONS[k]["body"], "w": ICONS[k].get("width", PACK.get("width", 48)), "h": ICONS[k].get("height", PACK.get("height", 48)), "cat": CAT_OF.get(k, "")} for k in sorted(keys)}
    js = json.dumps(out, separators=(",", ":")).replace("</", "<\\/")
    block = (f"{BEGIN} — filled by: python3 aws_icons.py embed <this file>. Do not edit by hand.\n"
             f"   AWS Architecture Icons (c) Amazon Web Services, CC BY-ND 2.0, release {PACK['info']['version']}, used unmodified. */\n"
             f"const ICONS = {js};\n{END}")
    if BEGIN in s and END in s:
        a, b = s.index(BEGIN), s.index(END) + len(END); s = s[:a] + block + s[b:]
    else:
        mark = "/* ============ 2. VISUAL LANGUAGE"
        if mark not in s: sys.exit("This does not look like a Maya design page.")
        s = s.replace(mark, block + "\n\n" + mark, 1)
    p.write_text(s, encoding="utf-8")
    print(f"Embedded {len(out)} icon(s) into {p.name} ({len(js) // 1024} KB).")

def main():
    a = sys.argv[1:]
    if not a: print(__doc__); return
    if a[0] == "search" and len(a) > 1: search(a[1:])
    elif a[0] == "list":
        if len(a) > 1 and a[1] in CATS: [print("aws:" + k) for k in CATS[a[1]]]
        else: [print(f"{c:<32} {len(k)} icons") for c, k in CATS.items()]
    elif a[0] == "embed" and len(a) > 1: embed(a[1])
    else: print(__doc__)

if __name__ == "__main__":
    main()
