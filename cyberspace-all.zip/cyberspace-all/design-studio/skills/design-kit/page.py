#!/usr/bin/env python3
"""Work with a design page without opening it by hand.

  python3 page.py summary <page.html>              what is on the page: designs, use cases, open items, last change
  python3 page.py extract <page.html> <data.js>    write the page's data (section 1, the DIAGRAM block) to a file
  python3 page.py build   <data.js> <page.html>    make a page from a data file and this kit's template
  python3 page.py upgrade <page.html>              keep the page's data, replace its engine with this kit's template
  python3 page.py structure <page.html>            the shape of every design before anyone reads a label: which way its arrows
                                                   run, how many rows and columns its boxes share, whether it is in lanes, and
                                                   how the use case diagram is grouped. Run it first on an existing page.
  python3 page.py arrange <page.html> <plan.json>  re-lay designs to a written layout plan: where each box goes, where frames go,
                                                   the few arrows that need a set route, and the "how to read it" line. It moves
                                                   things and nothing else: it refuses to save if any box, arrow, label, use case
                                                   or open item would differ. `references/layout.md` gives the plan's format.
  python3 page.py lanes <page.html> <lanes.json>   turn flow designs into swimlane designs from a written lanes file: the lanes
                                                   (who), the columns (when), the lane and column of every box, the "how to read
                                                   it" line, and a question for every step whose owner the sources do not state.
                                                   Boxes, arrows and labels stay as they are. `references/layout.md` has the format.
  python3 page.py straighten <page.html> [--apply] find arrows whose hand-set sides, ports or via points make them bend more than
                                                   they need to; with --apply, drop those hints and save (the data is rewritten
                                                   as JSON, so comments inside the data block are lost; the icons are kept)

  python3 page.py apply-edits <page.html> <edits.json>   put edits that someone exported from the page ("Export edits") into this page
  python3 page.py confluence <page.html>           write the two snippets that show the whole interactive page inside a
                                                   Confluence page (one for a hosted copy, one for an attached copy)

`summary`, `structure`, `arrange`, `lanes`, `straighten` and `apply-edits` need playwright and a Chrome/Chromium (same as check.py). The others need nothing.
"""
import os, re, sys, json, shutil, pathlib

A, B = "/* ============ 1. DIAGRAM DATA", "/* ============ 2. VISUAL LANGUAGE"
KIT = pathlib.Path(__file__).resolve().parent

def split(text, name):
    if A not in text or B not in text: sys.exit(f"{name}: not a design page (section markers not found)")
    a, b = text.index(A), text.index(B)
    return text[:a], text[a:b], text[b:]

def extract(page, out):
    _, data, _ = split(pathlib.Path(page).read_text(encoding="utf-8"), page)
    pathlib.Path(out).write_text(data, encoding="utf-8"); print(f"wrote {out} ({len(data):,} characters)")

def build(data_file, out, title=None):
    data = pathlib.Path(data_file).read_text(encoding="utf-8")
    if not data.lstrip().startswith(A): sys.exit(f"{data_file}: must start with the section 1 marker line, as written by `extract`")
    head, _, engine = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")
    if title is None:
        m = re.search(r'"?title"?:\s*"((?:[^"\\]|\\.)*)"', data); title = (m.group(1) if m else "System design") + " — system design"
    head = re.sub(r"<title>.*?</title>", lambda _: "<title>" + title + "</title>", head, count=1, flags=re.S)
    pathlib.Path(out).write_text(head + data + engine, encoding="utf-8"); print(f"wrote {out}")

def upgrade(page):
    text = pathlib.Path(page).read_text(encoding="utf-8"); _, data, old = split(text, page)
    _, _, engine = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")
    khead = split((KIT / "template.html").read_text(encoding="utf-8"), "template.html")[0]; strip = lambda h: re.sub(r"<title>.*?</title>", "", h, flags=re.S)
    if old == engine and strip(text[:text.index(A)]) == strip(khead): print("already on this kit's engine"); return
    t = re.search(r"<title>(.*?)</title>", text, flags=re.S)
    tmp = pathlib.Path(page).with_suffix(".data.tmp.js"); tmp.write_text(data, encoding="utf-8")
    build(tmp, page, t.group(1) if t else None); tmp.unlink(); print("engine replaced; data untouched. Now run check.py")

def summary(page):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        d = pg.evaluate("""() => ({ title: DIAGRAM.title, version: DIAGRAM.version, defaultStage: DIAGRAM.defaultStage || null,
          views: DIAGRAM.views.filter(v => !v.auto).map(v => ({ id: v.id, name: v.name, level: v.level || "", parent: v.parent || "", boxes: v.nodes.length, arrows: v.edges.length,
            frames: v.groups.length, gaps: [...v.nodes, ...v.edges].filter(x => x.status === "assumed" || x.status === "unknown").length,
            open: DIAGRAM.items.filter(it => !["answered","covered","closed"].includes(it.status) && [it.view, ...it.where.map(w => w.view)].includes(v.id)).length })),
          flows: DIAGRAM.flows.map(f => ({ id: f.id, name: f.name, who: f.actor || (f.actors || []).join(", ") || "", group: f.group || "", steps: f.steps.length, views: [...new Set(f.steps.map(s => s.view))] })),
          items: DIAGRAM.items.map(it => ({ id: it.id, kind: it.kind, status: it.status, owner: it.owner || "", text: it.text })),
          changes: (DIAGRAM.changes || []).slice(0, 3), check: MAYA_CHECK().reduce((a, r) => (a[r.level] = (a[r.level] || 0) + 1, a), {}) })""")
        b.close()
    if "--json" in sys.argv: print(json.dumps(d, indent=1)); return
    print(f"{d['title']}   {d['version']}   (unmarked parts are: {d['defaultStage'] or 'not stated'})")
    print(f"\nDESIGNS ({len(d['views'])})   id · level · boxes/arrows · assumed-or-unknown · open items")
    by = {v["id"]: v for v in d["views"]}
    for v in d["views"]:
        n, cur, seen = 0, v, set()
        while cur["parent"] in by and cur["id"] not in seen: seen.add(cur["id"]); cur = by[cur["parent"]]; n += 1
        print(f"  {'  ' * n}{v['name']}  [{v['id']} · {v['level'] or '-'} · {v['boxes']}/{v['arrows']} · {v['gaps']} · {v['open']}]")
    print(f"\nUSE CASES ({len(d['flows'])})")
    for f in d["flows"]: print(f"  {f['name']}  [{f['id']} · {f['steps']} steps · {f['who'] or 'no actor'}{' · ' + f['group'] if f['group'] else ''} · on: {', '.join(f['views'])}]")
    kinds = {}
    for it in d["items"]: kinds.setdefault(it["kind"], []).append(it)
    openn = [it for it in d["items"] if it["status"] not in ("answered", "covered", "closed")]
    print(f"\nITEMS ({len(d['items'])}, {len(openn)} still open)   " + "   ".join(f"{k}: {len(v)}" for k, v in kinds.items()))
    if "--items" in sys.argv:
        for it in d["items"]: print(f"  {it['id']:<6} {it['kind']:<11} {it['status']:<9} {it['owner'][:28]:<28} {it['text'][:110]}")
    else: print("  (add --items to list them, --json for everything)")
    print("\nLAST CHANGES")
    for c in d["changes"]: print(f"  {c.get('version', '')} {c.get('date', '')}  {c.get('text', '')[:160]}")
    print(f"\nDESIGN CHECK   problems: {d['check'].get('error', 0)}   warnings: {d['check'].get('warn', 0)}   (run check.py for the list and screenshots)")

def structure(page):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        if not pg.evaluate("typeof MAYA_STRUCTURE === 'function'"): sys.exit("This page has an older engine. Run: python3 page.py upgrade " + page)
        rows = pg.evaluate("MAYA_STRUCTURE()")
        uc = pg.evaluate("""() => { const v = DIAGRAM.views.find(v => v.id === "_usecases"); if (!v) return null;
          return { phases: (DIAGRAM.phases || []).map(p => p.label || p.id), lanes: v.swim.lanes.map(l => l.actor || l.label), unplaced: DIAGRAM.flows.filter(f => (DIAGRAM.phases || []).length && !f.phase).map(f => f.name),
                   then: DIAGRAM.flows.reduce((n, f) => n + (f.then || []).length, 0), cells: v.swim.lanes.map(l => v.swim.cols.map(c => v.nodes.filter(n => n.lane === l.id && n.col === c.id).length)) }; }""")
        b.close()
    say = {"right": "left to right", "left": "RIGHT TO LEFT", "down": "top to bottom", "up": "BOTTOM TO TOP"}
    print(f"{'Design':<42}{'boxes':>6}{'arrows':>7}   {'->':>3}{'<-':>4}{'dn':>4}{'up':>4}   {'rows':>4}{'cols':>5}   reads")
    for r in rows:
        print(f"{r['name'][:40]:<42}{r['boxes']:>6}{r['arrows']:>7}   {r['right']:>3}{r['left']:>4}{r['down']:>4}{r['up']:>4}   {r['rows']:>4}{r['cols']:>5}   " + ("in lanes" if r["swim"] else say[r["main"]] if r["arrows"] else "-") + ("" if not r["issues"] else "   <- restructure") + ("" if r.get("planned", True) or r["boxes"] < 6 else "   (no 'reads')"))
    bad = [r for r in rows if r["issues"]]
    print(f"\n{len(rows) - len(bad)} of {len(rows)} designs have a clear structure." + ("" if not bad else " To restructure:"))
    for r in bad:
        for m in r["issues"]: print(f"  [{r['name']}] {m}")
    if uc:
        print("\nUse case diagram: " + str(len(uc["lanes"])) + " lanes (" + ", ".join(uc["lanes"]) + ")")
        print("  phases, left to right: " + (" -> ".join(uc["phases"]) if uc["phases"] else "NONE GIVEN. List `phases` on the page and give each use case a `phase`, or the diagram cannot show an order."))
        if uc["unplaced"]: print("  use cases with no phase: " + "; ".join(uc["unplaced"]))
        print(f"  'then' links between use cases: {uc['then']}   fullest cell: {max(max(r) for r in uc['cells'])} use cases")

HINTS = ("fromSide", "toSide", "fromPort", "toPort", "via", "keep", "back", "line", "labelAt")
def content_of(d):
    """Everything on a page that is not layout. Two pages with the same content_of say the same things."""
    views = []
    for v in d["views"]:
        views.append([v["id"], v.get("name"), v.get("level"), v.get("parent"), v.get("question"),
                      sorted([n["id"], n.get("type"), n.get("cat"), n.get("label"), n.get("sub"), n.get("stage"), n.get("status"), n.get("child"), n.get("lane"), n.get("col"),
                              json.dumps({k: n[k] for k in n if k not in ("x", "y", "w", "h", "id", "changed")}, sort_keys=True)] for n in v["nodes"]),
                      sorted([e["from"], e["to"], e.get("label") or "", json.dumps({k: e[k] for k in e if k not in HINTS + ("changed",)}, sort_keys=True)] for e in v.get("edges", [])),
                      sorted(json.dumps({k: g[k] for k in g if k not in ("x", "y", "w", "h", "labelPos")}, sort_keys=True) for g in v.get("groups", [])), json.dumps(v.get("swim"), sort_keys=True)])
    return json.dumps([views, d.get("flows"), d.get("items"), d.get("phases"), d.get("lenses")], sort_keys=True)

def arrange_data(d, plan):
    """Apply a layout plan to page data in place. Returns the names of the designs it re-laid."""
    V = {v["id"]: v for v in d["views"]}; done = []
    for vid, pl in plan.get("designs", {}).items():
        if vid not in V: sys.exit(f'plan names a design "{vid}" that the page does not have')
        v = V[vid]; N = {n["id"]: n for n in v["nodes"]}
        unknown = set(pl) - {"reads", "place", "frames", "routes", "keepRoutes"}
        if unknown: sys.exit(f'{vid}: a plan may only set reads, place, frames, routes and keepRoutes; it has {sorted(unknown)}. This tool moves things; it does not change what a design says')
        if not (pl.get("reads") or v.get("reads")): sys.exit(f'{vid}: the plan has no "reads". Say in one or two sentences how the design reads (direction, what the columns and rows mean) before placing boxes')
        if v.get("swim") and pl.get("place"): sys.exit(f'{vid}: is a swimlane design; its boxes are placed by lane and column, not by a plan')
        moved = set()
        for nid, at in pl.get("place", {}).items():
            if nid not in N: sys.exit(f'{vid}: plan places a box "{nid}" that the design does not have')
            if not (isinstance(at, list) and 2 <= len(at) <= 4 and all(isinstance(k, (int, float)) for k in at)): sys.exit(f'{vid}/{nid}: a place is [x, y], [x, y, w] or [x, y, w, h]')
            n = N[nid]; was = (n.get("x"), n.get("y"), n.get("w"), n.get("h"))
            n["x"], n["y"] = at[0], at[1]
            if len(at) > 2: n["w"] = at[2]
            if len(at) > 3: n["h"] = at[3]
            if was != (n.get("x"), n.get("y"), n.get("w"), n.get("h")): moved.add(nid)
        if not pl.get("keepRoutes"):
            for e in v.get("edges", []):
                if e["from"] in moved or e["to"] in moved:
                    for k in HINTS: e.pop(k, None)
        for starts, box in pl.get("frames", {}).items():
            gs = [g for g in v.get("groups", []) if (g.get("label") or "").startswith(starts)]
            if len(gs) != 1: sys.exit(f'{vid}: "{starts}" matches {len(gs)} frames; give the start of exactly one frame\'s label')
            bad = set(box) - {"x", "y", "w", "h", "labelPos"}
            if bad: sys.exit(f'{vid}: a frame may only be moved or resized ({sorted(bad)} given)')
            gs[0].update(box)
        for r in pl.get("routes", []):
            es = [e for e in v.get("edges", []) if e["from"] == r.get("from") and e["to"] == r.get("to") and (e.get("label") or "").startswith(r.get("label", ""))]
            if len(es) != 1: sys.exit(f'{vid}: route {r.get("from")} > {r.get("to")} matches {len(es)} arrows; add "label" with the start of the arrow\'s label')
            bad = set(r) - set(HINTS) - {"from", "to", "label"}
            if bad: sys.exit(f'{vid}: a route may only set {", ".join(HINTS)} ({sorted(bad)} given)')
            for k in HINTS: es[0].pop(k, None)
            es[0].update({k: r[k] for k in r if k in HINTS})
        if pl.get("reads"): v["reads"] = pl["reads"]
        done.append(v["name"])
    return done

def arrange(page, plan_file):
    from playwright.sync_api import sync_playwright
    import datetime
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    plan = json.loads(pathlib.Path(plan_file).read_text(encoding="utf-8")); ids = list(plan.get("designs", {}))
    if not ids: sys.exit('the plan has no "designs"')
    uri = pathlib.Path(page).resolve().as_uri()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(uri)
        if not pg.evaluate("typeof MAYA_STRUCTURE === 'function'"): sys.exit("This page has an older engine. Run: python3 page.py upgrade " + page)
        d = json.loads(pg.evaluate("MAYA_DATA()")); was = {r["id"]: r for r in pg.evaluate("MAYA_STRUCTURE()")}
        before = content_of(d); names = arrange_data(d, plan)
        if content_of(d) != before: sys.exit("Refused: the result would change what a design says, not only where things are. Nothing was saved.")
        note = "Re-laid to a clear order, positions only, content unchanged: " + ", ".join(names) + "." + (" " + plan["note"] if plan.get("note") else "")
        d.setdefault("changes", []).insert(0, {"version": d.get("version", ""), "date": datetime.date.today().isoformat(), "text": note})
        write_data(page, json.dumps(d, indent=1, ensure_ascii=False))
        pg.goto(uri); now = {r["id"]: r for r in pg.evaluate("MAYA_STRUCTURE()")}; chk = pg.evaluate("MAYA_CHECK()"); b.close()
    line = lambda r: f"right {r['right']}, left {r['left']}, down {r['down']}, up {r['up']}; {r['rows']} rows, {r['cols']} columns"
    for vid in ids:
        print(f"{now[vid]['name']}\n  before: {line(was[vid])}\n  after:  {line(now[vid])}")
        for r in chk:
            if r.get("view") == vid and r["level"] in ("error", "warn"): print(f"  {'PROBLEM' if r['level'] == 'error' else 'warning'}: {r['msg']}")
    print("\nSaved. Content unchanged. Now run check.py with a screenshot folder and look at each design you moved.")

def lanes_data(d, plan):
    """Turn the named designs into swimlane designs, in place. Returns the names of the designs changed and the ids of the questions added."""
    V = {v["id"]: v for v in d["views"]}; done, asked = [], []
    for vid, pl in plan.get("designs", {}).items():
        if vid not in V: sys.exit(f'the lanes file names a design "{vid}" that the page does not have')
        v = V[vid]; unknown = set(pl) - {"reads", "lanes", "cols", "cells", "questions", "colWidth"}
        if unknown: sys.exit(f'{vid}: a lanes entry may only set reads, lanes, cols, cells, colWidth and questions ({sorted(unknown)} given)')
        lanes, cols, cells = pl.get("lanes") or [], pl.get("cols") or [], pl.get("cells") or {}
        if not pl.get("reads"): sys.exit(f'{vid}: no "reads". Say what the lanes and the columns mean')
        if not (2 <= len(lanes) <= 7 and 2 <= len(cols) <= 7): sys.exit(f'{vid}: use two to seven lanes and two to seven columns ({len(lanes)} lanes, {len(cols)} columns given)')
        L, C = {l.get("id") for l in lanes}, {c.get("id") for c in cols}
        if any(not l.get("id") or not l.get("label") for l in lanes) or any(not c.get("id") or not c.get("label") for c in cols): sys.exit(f'{vid}: every lane and every column needs an id and a label')
        ids = {n["id"] for n in v["nodes"]}
        if set(cells) != ids: sys.exit(f'{vid}: "cells" must name every box of the design exactly once, notes included. Missing: {sorted(ids - set(cells))}. Not in the design: {sorted(set(cells) - ids)}')
        for nid, at in cells.items():
            if not (isinstance(at, list) and len(at) == 2 and at[0] in L and at[1] in C): sys.exit(f'{vid}/{nid}: a cell is [lane id, column id] using the ids listed above; got {at}')
        open_lane = [l["id"] for l in lanes if l["label"].strip().lower() == "not stated"]
        if open_lane and not pl.get("questions"): sys.exit(f'{vid}: there is a "Not stated" lane but no question. Ask who does those steps')
        v["swim"] = {"lanes": [{k: l[k] for k in ("id", "label", "sub") if l.get(k)} for l in lanes], "cols": [{k: c[k] for k in ("id", "label") if c.get(k)} for c in cols], **({"colWidth": pl["colWidth"]} if pl.get("colWidth") else {})}
        for n in v["nodes"]:
            n["lane"], n["col"] = cells[n["id"]]; n.pop("x", None); n.pop("y", None)
        for e in v.get("edges", []):
            for k in HINTS:
                if k != "back": e.pop(k, None)
        v["reads"] = pl["reads"]
        nums = [int(it["id"][1:]) for it in d.get("items", []) if isinstance(it.get("id"), str) and it["id"][:1] == "Q" and it["id"][1:].isdigit()]; nxt = max(nums, default=0) + 1
        for q in pl.get("questions") or []:
            bad = set(q) - {"text", "owner", "refs", "ledger"}
            if bad or not q.get("text") or not q.get("owner"): sys.exit(f'{vid}: a question needs "text" and "owner" (who to ask), and may list "refs" (box ids in this design) and "ledger" (evidence ids)')
            refs = [f"{vid}/{r}" for r in q.get("refs", [])]
            if any(r.split("/")[1] not in ids for r in refs): sys.exit(f'{vid}: a question refers to a box the design does not have')
            d.setdefault("items", []).append({"id": f"Q{nxt}", "kind": "question", "status": "open", "owner": q["owner"], "text": q["text"], "refs": refs, **({"ledger": q["ledger"]} if q.get("ledger") else {}), "view": vid}); asked.append(f"Q{nxt}"); nxt += 1
        done.append(v["name"])
    return done, asked

def lanes(page, plan_file):
    from playwright.sync_api import sync_playwright
    import datetime
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    plan = json.loads(pathlib.Path(plan_file).read_text(encoding="utf-8")); ids = list(plan.get("designs", {}))
    if not ids: sys.exit('the lanes file has no "designs"')
    uri = pathlib.Path(page).resolve().as_uri()
    def bare(dd):   # the page's content with lanes, positions and open items left out
        c = json.loads(json.dumps(dd)); c.pop("items", None)
        for v in c["views"]:
            v.pop("swim", None); v.pop("reads", None)
            for n in v["nodes"]: n.pop("lane", None); n.pop("col", None)
        return content_of(c)
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(uri)
        if not pg.evaluate("typeof MAYA_STRUCTURE === 'function'"): sys.exit("This page has an older engine. Run: python3 page.py upgrade " + page)
        d = json.loads(pg.evaluate("MAYA_DATA()")); before = bare(d); items = json.dumps(d.get("items", []), sort_keys=True); n0 = len(d.get("items", []))
        names, asked = lanes_data(d, plan)
        if bare(d) != before or json.dumps(d["items"][:n0], sort_keys=True) != items: sys.exit("Refused: the result would change a box, an arrow, a label or an existing open item. Nothing was saved.")
        note = "Drawn as swimlanes (who does each step, in which order); boxes, arrows and labels unchanged: " + ", ".join(names) + "." + (f" Questions raised: {', '.join(asked)}." if asked else "") + (" " + plan["note"] if plan.get("note") else "")
        d.setdefault("changes", []).insert(0, {"version": d.get("version", ""), "date": datetime.date.today().isoformat(), "text": note})
        write_data(page, json.dumps(d, indent=1, ensure_ascii=False))
        pg.goto(uri); chk = pg.evaluate("MAYA_CHECK()"); b.close()
    for vid in ids:
        mine = [r for r in chk if r.get("view") == vid and r["level"] in ("error", "warn")]
        print(f"{vid}: in lanes" + ("" if mine else ", check clean"))
        for r in mine: print(f"  {'PROBLEM' if r['level'] == 'error' else 'warning'}: {r['msg']}")
    print(("Questions raised: " + ", ".join(asked) + ". " if asked else "") + "Saved. Now run check.py with a screenshot folder and look at each design.")

def straighten(page, apply):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        if not pg.evaluate("typeof MAYA_RELAX === 'function'"): sys.exit("This page is on an older engine. Run: python3 page.py upgrade " + page)
        done = pg.evaluate("MAYA_RELAX()"); data = pg.evaluate("MAYA_DATA()"); b.close()
    if not done: print("Nothing to straighten: no hand-set hint is making an arrow bend more than it needs to."); return
    for d in done: print(f"  [{d['view']}] {d['arrow']}: without {', '.join(d['dropped'])} it has {d['saved']} fewer corner(s)")
    print(f"{len(done)} arrow(s), {sum(d['saved'] for d in done)} corner(s) fewer.")
    if not apply: print("Nothing saved. Add --apply to save, or remove those fields yourself."); return
    text = pathlib.Path(page).read_text(encoding="utf-8"); head, blk, engine = split(text, page)
    i = blk.index("const DIAGRAM = "); j = blk.find("/* AWS-ICONS:BEGIN")
    blk = blk[:i] + "const DIAGRAM = " + data + ";\n\n" + (blk[j:] if j >= 0 else "")
    pathlib.Path(page).write_text(head + blk + engine, encoding="utf-8"); print(f"saved {page}. Now run check.py and look at the screenshots.")

def write_data(page, data):
    text = pathlib.Path(page).read_text(encoding="utf-8"); head, blk, engine = split(text, page)
    i = blk.index("const DIAGRAM = "); j = blk.find("/* AWS-ICONS:BEGIN")
    blk = blk[:i] + "const DIAGRAM = " + data.replace("</script", "\\u003c/script") + ";\n\n" + (blk[j:] if j >= 0 else "")
    pathlib.Path(page).write_text(head + blk + engine, encoding="utf-8")

def apply_edits(page, edits_file):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0, str(KIT)); from check import find_browser; chrome = find_browser()
    log = json.loads(pathlib.Path(edits_file).read_text(encoding="utf-8")); edits = log.get("edits", log) if isinstance(log, dict) else log
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=chrome, args=["--no-sandbox"]) if chrome else p.chromium.launch()
        pg = b.new_page(); pg.goto(pathlib.Path(page).resolve().as_uri())
        if not pg.evaluate("typeof MAYA_APPLY === 'function'"): sys.exit("This page is on an older engine. Run: python3 page.py upgrade " + page)
        n = pg.evaluate("log => MAYA_APPLY(log)", edits); data = pg.evaluate("MAYA_DATA()"); b.close()
    print(f"{n} of {len(edits)} edit(s) applied" + ("" if n == len(edits) else " (the rest point at a box, arrow or item this page does not have, or were already there)"))
    for e in edits: print("  " + e.get("at", "")[:10], e.get("by", "") or "-", e.get("t"), e.get("kind", ""), e.get("view", ""), e.get("id", "") or (e.get("item") or {}).get("id", ""))
    if n: write_data(page, data); print(f"saved {page}. Add a change log entry, update the ledger and open-items file to match, then run check.py")

FRAME = 'allowfullscreen style="width:100%;height:85vh;min-height:720px;border:1px solid #dfe1e6;border-radius:6px"'
def confluence(page):
    p = pathlib.Path(page); name = p.name; stem = p.with_suffix("")
    hosted = f"""<!-- Paste into an HTML macro (or use the iframe macro with the same address).
     Replace the address with where {name} is hosted inside your firm.
     Add #<view id> to the address to open on one design, for example .../{name}#scan -->
<iframe src="https://YOUR-INTERNAL-HOST/path/{name}" {FRAME}></iframe>
"""
    attached = f"""<!-- 1. Attach {name} to this Confluence page.  2. Paste all of this into an HTML macro on the same page.
     To publish a new version later, attach the new file under the same name. Nothing else changes. -->
<iframe id="design-frame" {FRAME}></iframe>
<script>
(function () {{
  var file = "{name}";
  var meta = document.querySelector('meta[name="ajs-page-id"]');
  var pageId = (window.AJS && AJS.params && AJS.params.pageId) || (meta && meta.content);
  var base = (window.AJS && AJS.contextPath && AJS.contextPath()) || "";
  var frame = document.getElementById("design-frame");
  fetch(base + "/download/attachments/" + pageId + "/" + encodeURIComponent(file), {{ credentials: "same-origin" }})
    .then(function (r) {{ if (!r.ok) throw new Error("status " + r.status); return r.text(); }})
    .then(function (t) {{ frame.srcdoc = t; }})
    .catch(function (e) {{ frame.outerHTML = "<p>Could not load the design (" + e.message + "). Is " + file + " attached to this page?</p>"; }});
}})();
</script>
"""
    a = pathlib.Path(str(stem) + ".confluence-hosted.html"); b = pathlib.Path(str(stem) + ".confluence-attached.html")
    a.write_text(hosted, encoding="utf-8"); b.write_text(attached, encoding="utf-8")
    print(f"""wrote {a.name} and {b.name}

Confluence does not run an HTML file as a page, so the design is shown in a frame inside a Confluence page.
Which way works depends on what your Confluence allows:

  A. The file is hosted on an internal web address, and Confluence has an HTML or iframe macro
     -> paste {a.name}. Links to one design or use case work (the address ends in #...).
  B. No hosting, but the HTML macro is enabled
     -> attach {name} to the page and paste {b.name}. Everything works except links to one design.
  C. Neither macro is available
     -> the interactive page cannot be shown inside Confluence. Attach {name} so people can download and open it,
        and put screenshots on the page (python3 check.py {name} shots).

To find out: edit any Confluence page, type {{html and {{iframe, and see which macros are offered.""")

def main():
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == "summary": summary(a[1])
    elif len(a) == 3 and a[0] == "extract": extract(a[1], a[2])
    elif len(a) == 3 and a[0] == "build": build(a[1], a[2])
    elif len(a) == 2 and a[0] == "upgrade": upgrade(a[1])
    elif len(a) == 2 and a[0] == "structure": structure(a[1])
    elif len(a) == 3 and a[0] == "arrange": arrange(a[1], a[2])
    elif len(a) == 3 and a[0] == "lanes": lanes(a[1], a[2])
    elif len(a) >= 2 and a[0] == "straighten": straighten(a[1], "--apply" in a)
    elif len(a) == 2 and a[0] == "confluence": confluence(a[1])
    elif len(a) == 3 and a[0] == "apply-edits": apply_edits(a[1], a[2])
    else: sys.exit(__doc__)

if __name__ == "__main__":
    main()
