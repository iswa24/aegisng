# Design Studio knowledge

This document covers the skills of the `design` module: what each gives the user, when to recommend it, and what to offer next.

## What the module is for

It turns a project or a spec into one interactive design page: structure from C1 to C4, use cases that can be followed at any level and as sequence diagrams, data flow, database schema, API contracts, AWS architecture with the official icons, and multi-agent designs. Every fact carries a source, and everything unverified or undecided is marked as such. The module works with or without the BMad Method module; with it, the design team sits in party mode beside the BMad agents.

## The skills

| Skill | Who | Recommend when |
|---|---|---|
| `design-agent-maya` | 🧭 Maya, Lead Design Architect | The user wants a system designed or drawn, or the design page built, merged or checked. The usual place to start. |
| `design-agent-rhea` | 🔎 Rhea, Evidence Analyst | The user wants documents or code read and the facts recorded, gaps and conflicts found, research briefs written, or a spec traced to the design. |
| `design-agent-finn` | 🎬 Finn, Flow Designer | Use cases, sequence diagrams, flowcharts, failure paths. |
| `design-agent-dara` | 🗄️ Dara, Data and API Designer | Database schema, data flow, API design. |
| `design-agent-skye` | ☁️ Skye, Cloud Architect | AWS architecture, network and deployment views. |
| `design-agent-aria` | 🤖 Aria, Agent Systems Architect | Multi-agent orchestration, what agents can reach, agent operating procedures from a spec. |
| `design-agent-vera` | 🖍️ Vera, Design Reviewer | Reviewing a design, preparing a review packet, applying feedback, comparing versions. |
| `design-party` | The whole team | The user wants several design perspectives at once, a design review session, or a decision argued out. |
| `design-kit` | Tools | Building or checking a page directly; it is also what every persona above depends on. |

## Routing

- "Design this", "draw the architecture", "read this spec and draw it": Maya. She brings in the others.
- "What do we actually know?", "what is missing?", "does the design cover the spec?": Rhea.
- "Show me the sequence", "what happens when it fails?": Finn.
- "Schema", "what data goes where", "the API": Dara.
- "AWS diagram", "where does it run": Skye.
- "The agents", "AOP", "what can this agent reach": Aria.
- "Review this", "is it ready?": Vera, or `design-party --party design-review`.
- A decision with real trade-offs: `design-party`. With the delivery team in the room: `design-party --party architecture-board`, or `bmad-party-mode --party architecture-board`.

## With the BMad Method module

- The design agents join `bmad-party-mode`'s default room while their skills are installed, so "party mode" alone already seats the design team with the BMad agents. Two rooms come with this module: `design-studio` and `design-review`. A third, `architecture-board` (the design team with the BMad architect, analyst, product manager and engineer), ships as a customization in `design-party/assets/architecture-board.toml`; `design-party` offers to add it the first time it is asked for.
- Design files live in the active initiative's output folder under `design/`. A ticket's requirements are the spec Rhea traces.
- After `bmad-architecture`, offer Maya to draw what was decided; before `bmad-build`, offer a design review party.

## What to offer next

- After a first design: a review (`design-agent-vera` or a review party), then the open items and research briefs to the people who can answer them.
- After answers or feedback arrive: Rhea records them, Maya redraws.
- After a spec changes: Rhea re-traces it; the uncovered requirements say what to draw next.
