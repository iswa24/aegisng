---
name: bmod-design
description: Required bmod metadata. Never invoke this skill.
---
This folder is the Design Studio module's record, not something to run. With BMad installed, invoke the `bmad` skill with `setup design`. Without BMad, the design skills work on their own: start with `design-agent-maya` or `design-party`.
