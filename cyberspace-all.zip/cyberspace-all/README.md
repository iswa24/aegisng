# Start here

To install everything into BMad, open `INSTALL-WITH-BMAD-PROMPT.md` and paste its prompt into Claude Code.

`program/charter.md` is a DRAFT program charter for Sage, the program lead, built from your platform definition; confirm or correct it.

Then: `SQUAD-PROMPT.md` runs the Cyberspace squad on a feature, `THEO-SMARTSDK-PROMPT.md` is Theo on his own, and `REDESIGN-PROMPT.md` re-lays existing design pages.

# Cyberspace: everything in one place

24 November 2026. Nothing in here is a decision: the design is proposed and waits for the owner.

## Start here

Open `design/cyberspace-design-v4.html` in a browser. It is one file and needs nothing else. It opens on the proposed platform landscape.

## Adding details yourself

Press **Edit** in the page's header, then click a box, an arrow or an open item. You can change names and details, add notes, raise questions and record answers. **+ Box** and **+ Arrow** on the drawing add to it, and you can drag a box to move it. Edits stay in your browser until you press **Save file**, which downloads a copy of the page with your edits inside. Use that copy from then on.

The **Use case diagram** (top of the Use cases list) is drawn as swimlanes: one lane per actor, five phases from left to right, and an arrow where one use case leads to the next.

The zoom control is at the bottom right of the drawing: it shows the zoom as a percentage, with minus and plus beside it. Click the number to pick a level (25% to 400%) or **Fit all**.

## What is in each folder

| Folder | What it holds |
|---|---|
| `design/` | The interactive design page (version 4) and the files behind it: evidence ledger, open items, requirements, change log, party notes, the two reviews, and the research briefs. |
| `party/` | The design party. `party-record.md` is the whole argument in one file. The separate rounds are beside it: the brief, five positions, the lead's draft and nine conflicts, five answers, the outcome. |
| `screenshots/` | Pictures of the three new designs: the landscape, what must not cross between zones, and a change's path. |
| `confluence/` | Two snippets for showing the page inside a Confluence page: one for an attached copy, one for a hosted copy. Both name `cyberspace-design-v4.html`. |
| `design-studio/` | The skills package: seven design personas, the design party, and the shared design kit. See its own `README.md`. |

## Three things to know

- The architects worked from the 195 facts already taken from the project documents; they could not open the documents themselves.
- The Confluence snippets were tested in a stand-in page, not in a real Confluence.
- In `design-studio/`, each skill's source still says `YOUR-ORG`; replace it with where the package will be hosted.

## Redesigning another page with the team

`REDESIGN-PROMPT.md` (also inside `design-studio/`) has the steps and the prompt for taking an existing design page and giving every design on it a clear order with the team.

## Theo, the SmartSDK specialist

`design-studio/` includes Theo (`design-agent-theo`). He reads the SmartSDK repo, a Claude Code harness and the requirements, learns from the firm's agent-builder knowledge, works out what SmartSDK must provide for a feature, and hands detailed story seeds to the story-writing agents. `THEO-SMARTSDK-PROMPT.md` has the prompts.
