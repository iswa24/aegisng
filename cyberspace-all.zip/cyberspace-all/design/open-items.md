# Open items — Cyberspace project

Version v4, 2026-11-24. 96 items: 25 conflicts, 39 questions, 21 risks, 11 requirements. All conflicts, questions and risks are open. Requirements: 0 covered, 11 partial, 0 uncovered. Items added in v4, after the design party of 2026-11-24: X21 to X25, Q29 to Q39, R01 to R10. No earlier item was closed or reworded. Items added in v3: Q23, Q24, Q25, K17, Q26, Q27, K18, Q28, K19, K20, K21.

The project's own `claude/question-log.md` holds 111 questions (95 open). They are cited by id (M-, S-, D-, BB-, GH-, AF-, N-), not copied.

No item is answered. No person has decided anything since v1; the design parties of 2026-11-23 and 2026-11-24 produced recommendations only (`party-notes.md`).

## Ask: Owner (architecture)

### X01 · conflict · open

What is SmartSDK? Two documents use the name for different things, and the runner's scope-guard and recorder library is left with no name and no owner.

- **Platform design (9 Nov):** A contracts-and-clients library (job spec, manifest, clients, scope guard, recorder) used identically in both planes, including on runners. *(source: cyberspace-platform-design.md §3)*
- **Migration document (10 Nov) and the owner:** The firm's wrapper around Google ADK, an agent runtime. The earlier description 'was a guess from the whiteboard'. *(source: harness-migration-architect.md §9; owner's project notes, smartsdk)*

- Drawn: SmartSDK as the ADK wrapper (owner statement outranks a draft). The runner library is drawn as a separate box, name unknown.
- Who decides: Owner, with the SmartSDK owners
- Boxes: Runner VM and its credentials: Scope guard + recorder; Cyberspace platform: Component repo; Cyberspace project: the whole picture: SmartSDK
- Brief: research/R02-smartsdk.md · Ledger: E008, E009, E056, E057

### X02 · conflict · open

Which rule holds about models at run time? Two later systems run a model at run time on a network shared with prod.

- **Owner:** Claude must not touch prod and must not be deployed anywhere at runtime. *(source: owner's project notes, cyberops-runner-platform)*
- **Platform design (9 Nov):** No model, Claude or any other, runs in compute that holds prod credentials. One narrow exception, off by default. *(source: cyberspace-platform-design.md §1, §9)*
- **Scan design and pentest note:** ADK agents call a cyber or Bedrock-hosted model at run time; UAT and prod share a flat network. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §2, §8; owner's project notes, agentic-pentest)*
- **Migration document:** A ported harness means an agent loop wherever SmartSDK runs; build plane only, or execution plane, is undecided. *(source: harness-migration-architect.md §9)*

- Drawn: Each system as its own document describes it. The runner-to-model path is drawn as blocked; the rule is a sticky note.
- Who decides: Owner, with Security
- Boxes: Where a model runs, across all systems: Platform design, rule 1: no model, Claude or any other, where prod credentials live. Owner's own words: no Claude at runtime. These differ.; Where a model runs, across all systems: Scan agent task; Where a model runs, across all systems: Pentest agent; Where a model runs, across all systems: Ported harness; Where a model runs, across all systems: Runner VM; Cyberspace platform: Runner VM; Analysis: triage, agent, sandbox: Agent task; Cyberspace project: the whole picture: Pentest agent
- Brief: research/R03-owner-decisions.md · Ledger: E001, E015, E054, E085, E011, E012, E073

### X03 · conflict · open

The delivery document still builds project 2 from the October runner design, which the November platform design supersedes.

- **Runner design (14 Oct) and delivery document (19 Oct):** Claude Code runs on the runner beside target credentials; skills to build include attach-broker, a Step Functions job lifecycle and a persona bundle with CLAUDE.md. *(source: cyberops-ephemeral-runner-design.md §3-§6; agentic-delivery-operating-model.md domain skills)*
- **Platform design (9 Nov):** Supersedes the runner design where they conflict; Claude Code is not installed on the runner. *(source: cyberspace-platform-design.md header, §5)*

- Drawn: The November design (it says it supersedes). The October runner appears once, struck through, on the model view.
- Who decides: Owner (the delivery document needs an update)
- Boxes: Where a model runs, across all systems: October runner; Where a model runs, across all systems: Runner VM; How the platforms get built: Repo harness; Runner VM and its credentials: October design had Claude Code, tmux and an attach broker on this VM. The November design removed them: nothing here calls a model.
- Brief: research/R03-owner-decisions.md · Ledger: E039, E040, E077, E038

### X04 · conflict · open

Which orchestrator? Four documents give three answers, and the platform design contradicts itself.

- **Runner design and delivery document:** Step Functions runs the job lifecycle. *(source: cyberops-ephemeral-runner-design.md §4; agentic-delivery-operating-model.md)*
- **Platform design:** Kestra runs flows; 'Step Functions or Kestra itself' runs the outer lifecycle; listed as an open decision. *(source: cyberspace-platform-design.md §5, §12)*
- **Owner's sketch:** kestra is listed as a 'foundation substrate' with cosmos and portico, which may mean a Kestra already exists. *(source: cyberspace-platform-design.md §11)*
- **Code-scan companion:** Step Functions; Kestra only as a wholesale replacement, never alongside. *(source: code-scan-security-triggers-and-flows.md §5)*

- Drawn: Kestra in Cyberspace, marked disputed and assumed; Step Functions in the scan pipeline.
- Who decides: Owner
- Boxes: Cyberspace platform: Kestra orchestrator; Cyberspace platform: Control plane; Runner VM and its credentials: Kestra orchestrator; Analysis: triage, agent, sandbox: Orchestrator
- Brief: research/R03-owner-decisions.md · Ledger: E035, E036, E037, E034

### X05 · conflict · open

Is the code store immutable? The older documents were never updated after the delete-after-scan decision (question log D-24).

- **v0.3 and its companion (18 Nov):** Versioned, Object Lock in compliance mode. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §6.2; code-scan-security-triggers-and-flows.md §4)*
- **Owner decision (20 Nov) and intake v0.4:** The copy is deleted after the scan, so Object Lock cannot be used. *(source: question-log.md D-05; intake-detection-and-fetch-design.md v0.4 §6a)*

- Drawn: Deleted after scan (a recorded owner decision outranks the design document).
- Who decides: Owner (already decided; documents to be updated)
- Boxes: Code scan pipeline: S3 code store; Code scan pipeline: Cleaner; Intake: listen, fetch, verify: S3 code store; Analysis: triage, agent, sandbox: S3 code store; Code scan pipeline in AWS: S3 code store
- Brief: — · Ledger: E090, E145, E102, E144

### X06 · conflict · open

The companion's IAM and database-role tables still describe the old intake. The new 'core' intake functions and the cleaner hold database access with no role or grants defined.

- **v0.3 and its companion:** Intake is Fargate tasks on a nightly schedule; both intake lanes have no database role and no network path to the database. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §6.1; code-scan-security-triggers-and-flows.md §2, §4, T1)*
- **Intake v0.4 (decided: Lambda):** Edge functions have no database credentials; core functions (normaliser, relay, dispatcher, verifier, cataloguer) hold database access through RDS Proxy. *(source: intake-detection-and-fetch-design.md v0.4 §2, §10; question-log.md D-04)*

- Drawn: v0.4 (it replaces the v0.3 intake layer; the rest of v0.3 still stands).
- Who decides: Owner
- Boxes: Intake: listen, fetch, verify: Feed reader; Intake: listen, fetch, verify: Normaliser; Intake: listen, fetch, verify: PostgreSQL; Intake: listen, fetch, verify: Outbox relay; Code scan pipeline: Cleaner; Catalog and findings schema: package_version; Code scan pipeline in AWS: Core functions
- Brief: — · Ledger: E134, E152, E089, E136

### X07 · conflict · open

'One ECS task type for the agent, S3 access only' does not match the only detailed analysis design. The owner's own decisions point both ways.

- **Owner:** Just one ECS task type for the agent; it does nothing external and has S3 access only. *(source: question-log.md D-04; owner's project notes, artifact-intake)*
- **Owner (earlier) and v0.3:** A sandbox where code runs, fuzzing in v1; v0.3 has triage, agent, sandbox tasks, a fuzz tier, a session broker and a model endpoint. *(source: owner's project notes, artifact-intake; oss-vulnerability-discovery-pipeline-design.md v0.3 §6.3-§6.5)*
- **Intake v0.4:** Bringing the analysis side down to one task type is 'not addressed here'. *(source: intake-detection-and-fetch-design.md v0.4 §10)*
- **Independent review:** Merging agent and sandbox puts model credentials beside hostile build scripts; keep the sandbox separate, cut fuzzing. *(source: design-review-distinguished-engineer.md §3.7)*

- Drawn: The v0.3 analysis side, with triage and the fuzz tier marked disputed.
- Who decides: Owner (question log S-04, S-05)
- Boxes: Analysis: triage, agent, sandbox: Triage task; Analysis: triage, agent, sandbox: Agent task; Analysis: triage, agent, sandbox: Sandbox task; Analysis: triage, agent, sandbox: Fuzz tier; Code scan pipeline: Analysis; Scan agent: reach and guards: Scan agent; Scan agent: reach and guards: Sandbox task; Code scan pipeline in AWS: Agent task; Code scan pipeline in AWS: Sandbox task
- Brief: research/R03-owner-decisions.md · Ledger: E089, E085, E097, E105, E106, E108, E156, E152

### X08 · conflict · open

How much intake machinery is needed? The review would cut most of it; the owner kept it 'for now'.

- **Intake v0.4:** One-minute readers, per-source reconcilers, outbox relay, staging and verifier; intake_unreconciled must be zero. *(source: intake-detection-and-fetch-design.md v0.4 §2, §7)*
- **Independent review:** Completeness is over-bought: hourly or daily polling, the catalog as backlog, one reconcile, scope from Artifactory. *(source: design-review-distinguished-engineer.md §3.3, §3.4, §5)*
- **Owner:** Must not miss a single change, as soon as possible; and also the simplest possible intake; work need not be scanned the same day. Keeps the fuller document for now; hourly polling still open. *(source: owner's project notes, artifact-intake; question-log.md D-08, D-11, D-12)*

- Drawn: The fuller v0.4. Polling every minute is marked disputed; parts the review would cut carry the review tag.
- Who decides: Owner
- Boxes: Intake: listen, fetch, verify: Feed reader; Intake: listen, fetch, verify: Reconciler; Intake: listen, fetch, verify: Outbox relay; Intake: listen, fetch, verify: Hash verifier; Intake: listen, fetch, verify: Webhook receiver; Code scan pipeline: Intake
- Brief: — · Ledger: E094, E095, E092, E099, E135, E143, E154

### X09 · conflict · open

Scope: every public package, or what the firm uses?

- **Owner and v0.3:** Every ecosystem; public registries are primary. The earlier manual effort scanned 'all'. *(source: owner's project notes, artifact-intake; oss-vulnerability-discovery-pipeline-design.md v0.3 §1, §2; question-log.md S-01 (partly answered))*
- **Independent review:** At least 13 million deep runs for a backfill and daily inflow above any stated capacity; make the firm's own usage the scope. *(source: design-review-distinguished-engineer.md §2)*

- Drawn: Public registries as the primary source, as decided.
- Who decides: Owner (question log S-01, S-02)
- Boxes: Code scan pipeline: Public registries; Code scan pipeline: Analysis; Cyberspace project: the whole picture: Code scan pipeline
- Brief: research/R11-earlier-manual-scan.md · Ledger: E081, E096, E153

### X10 · conflict · open

One AWS account or two? Decided as one; the risk the design named still stands, and which account it is has not been said.

- **v0.3 and its companion:** Preferably two accounts so an intake compromise cannot touch findings; a single account is residual risk 6. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §8; code-scan-security-triggers-and-flows.md §9)*
- **Owner decision:** One account. *(source: question-log.md D-06)*

- Drawn: One account.
- Who decides: Owner (already decided)
- Boxes: Code scan pipeline: Intake; Code scan pipeline: Analysis
- Brief: research/R05-model-access.md · Ledger: E091, E114

### X11 · conflict · open

Should findings share a database with the catalog?

- **v0.3:** One PostgreSQL database, two schemas, separate roles; findings can move later. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §2, §9; code-scan-security-triggers-and-flows.md D1)*
- **Independent review:** Not acceptable once first-party findings exist; a separate cluster and key is cheap now. *(source: design-review-distinguished-engineer.md §3.9)*

- Drawn: One database, with Findings marked disputed.
- Who decides: Owner (question log D-15)
- Boxes: Code scan pipeline: Catalog; Code scan pipeline: Findings; Analysis: triage, agent, sandbox: Findings; Intake: listen, fetch, verify: PostgreSQL; Catalog and findings schema: finding_group; Catalog and findings schema: finding; Code scan pipeline in AWS: Catalog + findings
- Brief: — · Ledger: E104, E158, E087

### X12 · conflict · open

Is fuzzing in the first version?

- **Owner and v0.3 §2:** Fuzzing is in v1. *(source: owner's project notes, artifact-intake; oss-vulnerability-discovery-pipeline-design.md v0.3 §2)*
- **v0.3 build order:** Fuzzing tier is step 7 of 10. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §12)*
- **Independent review:** Cut fuzzing from v1. *(source: design-review-distinguished-engineer.md §3.7, §5)*

- Drawn: The fuzz tier, marked disputed and 'not in the first version'.
- Who decides: Owner
- Boxes: Analysis: triage, agent, sandbox: Fuzz tier
- Brief: — · Ledger: E097, E108, E156

### X13 · conflict · open

Which two versions are scanned, and is Artifactory really 'later'?

- **Owner and v0.3:** Latest and most-downloaded; Artifactory is secondary, a later sub-branch, no gating. *(source: owner's project notes, artifact-intake; oss-vulnerability-discovery-pipeline-design.md v0.3 §2)*
- **Owner decision for PyPI, intake v0.4:** Second version is the firm's most-used version from Artifactory counts; Maven has no download counts at all. *(source: question-log.md D-10, D-14 (open); intake-detection-and-fetch-design.md v0.4 §5)*

- Drawn: Artifactory as a source, tagged 'not in the first version' as v0.3 says. In practice the first version already needs it.
- Who decides: Owner (question log D-14, S-09)
- Boxes: Code scan pipeline: Artifactory; Code scan pipeline: Intake; Cyberspace project: the whole picture: Firm code hosts
- Brief: research/R09-artifactory.md · Ledger: E082, E083, E150, E081, E093

### X14 · conflict · open

How are pushes to firm repos detected? The review's preferred options cannot be drawn because they are defined in a document that is not in the project.

- **v0.3:** A verified push webhook starts the first-party lane. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §6.8)*
- **Intake v0.4:** A webhook is never sufficient; Bitbucket needs a plugin or push-log access; otherwise a daily sweep. *(source: intake-detection-and-fetch-design.md v0.4 §1, §5)*
- **Independent review:** 'Option D alone' for Bitbucket, 'option C alone' for GitHub. *(source: design-review-distinguished-engineer.md §4 (options defined in the missing walkthrough))*

- Drawn: v0.4: the source's change record is the main path, the webhook a speed hint.
- Who decides: Owner, after the Bitbucket and GitHub teams answer
- Boxes: Intake: listen, fetch, verify: Webhook receiver; Intake: listen, fetch, verify: Feed reader; Intake: listen, fetch, verify: A source; Code scan pipeline: Bitbucket + GitHub
- Brief: research/R07-bitbucket.md · Ledger: E101, E132, E147, E093, E160

### X15 · conflict · open

The companion contradicts itself in two places.

- **Companion §4:** Alarm on any read of the drop by a principal other than the validator. *(source: code-scan-security-triggers-and-flows.md §4)*
- **Companion §2:** The drop router and the review UI both read the drop. *(source: code-scan-security-triggers-and-flows.md §2)*
- **Companion §2 vs T11:** The orchestrator submits fuzz jobs; and the router submits fuzz jobs. *(source: code-scan-security-triggers-and-flows.md §2, T11)*

- Drawn: Router reads the drop and passes fuzz requests to the orchestrator.
- Who decides: Owner (same document, same date: cannot be ranked)
- Boxes: Analysis: triage, agent, sandbox: Findings drop; Analysis: triage, agent, sandbox: Drop router; Analysis: triage, agent, sandbox: Orchestrator; Analysis: triage, agent, sandbox: Fuzz tier; Code scan pipeline: Review UI; Code scan pipeline: arrow Analysis → Validator; Scan agent: reach and guards: Drop router
- Brief: — · Ledger: E118, E117, E119

### X16 · conflict · open

Delete-after-scan removes copies that other parts of the design still rely on.

- **Owner decision:** Delete the copy once scanned; keep only the record. *(source: question-log.md D-05; intake-detection-and-fetch-design.md v0.4 §6a)*
- **v0.3 and its companion:** Nightly diff against the previous version; variant hunt over every stored package; patch replay ('build first'); re-queue when the agent changes; cross-lane reachability runs. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §6.3; code-scan-security-triggers-and-flows.md §6, §8, T19)*
- **Independent review:** Keep the previous scanned version and anything with a finding. *(source: design-review-distinguished-engineer.md §3.6)*

- Drawn: Cleaner deletes after every run, as decided. Whether first-party bundles are also deleted is not stated.
- Who decides: Owner (question log D-13, D-25)
- Boxes: Code scan pipeline: Cleaner; Code scan pipeline: S3 code store; Code scan pipeline: Analysis; Analysis: triage, agent, sandbox: S3 code store; Catalog and findings schema: package_version
- Brief: — · Ledger: E090, E144, E105, E125, E124, E155

### X17 · conflict · open

Where do a library's dependencies come from when the sandbox is offline?

- **v0.3:** An intake-side bundler stages the full dependency closure next to the package. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §3.2, §6.1)*
- **Intake v0.4:** Closure from registry metadata only; where build code would have to run, it is flagged incomplete. *(source: intake-detection-and-fetch-design.md v0.4 §6)*
- **Independent review:** So offline builds will mostly fail; let the sandbox reach one read-only Artifactory repository. *(source: design-review-distinguished-engineer.md §3.8)*

- Drawn: A sandbox with no route out, and no bundler box (v0.4 replaced it).
- Who decides: Owner
- Boxes: Analysis: triage, agent, sandbox: Sandbox task; Analysis: triage, agent, sandbox: S3 code store; Intake: listen, fetch, verify: Fetch worker
- Brief: — · Ledger: E151, E157, E106

### X18 · conflict · open

Is a full backfill needed at all?

- **v0.3:** One full backfill run as a long campaign, then nightly. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §7, §12)*
- **Owner:** The firm already scanned 'all' by hand over about 7 months; mainly the incremental is needed, plus a from-scratch load for registries not yet done. *(source: owner's project notes, artifact-intake; question-log.md M-01 to M-03)*

- Drawn: No backfill box. What 'all' covered and where it stopped is unknown (M-04, M-10).
- Who decides: Owner, after the earlier team answers
- Boxes: Code scan pipeline: Public registries; Code scan pipeline: Intake
- Brief: research/R11-earlier-manual-scan.md · Ledger: E096, E081

### K02 · risk · open

The access layer has an API and is reachable from the desktop where Claude Code works. Nothing says a submission or approval must be a human action, so a model could drive jobs against prod.

- Boxes: Cyberspace platform: Human access layer; Cyberspace platform: CyberSpace VDI; Cyberspace platform: Devspace + Claude Code; One job, state by state: Submit in access layer
- Brief: research/R03-owner-decisions.md · Ledger: E032, E018

### K07 · risk · open

The agent stage has no size: no runs per day, cost per run, budget, yield or number of reviewers. Reviewers are the real limit and none is named.

- Boxes: Code scan pipeline: Analysis; Code scan pipeline: Review UI; Code scan pipeline: Findings reviewer; Analysis: triage, agent, sandbox: Dispatcher; Cyberspace project: the whole picture: Findings reviewer; Scan agent: reach and guards: Findings reviewer
- Brief: research/R03-owner-decisions.md · Ledger: E153, E120, E159

### K10 · risk · open

Code is fetched at detection but scanned when the queue allows. The lifecycle backstop will delete copies still waiting once the backlog is older than its age limit.

- Boxes: Code scan pipeline: S3 code store; Code scan pipeline: Work queue; Code scan pipeline: Cleaner
- Brief: — · Ledger: E144, E092

### K14 · risk · open

Three unrelated ways for an agent or component to get permission to run: Cyberspace's signed catalog, the scan pipeline's regression-set promotion, and a plain PR merge. The scan and pentest agents never pass the Cyberspace gate, and no document says whether they should.

- Boxes: Cyberspace project: the whole picture: Cyberspace platform; Cyberspace project: the whole picture: Code scan pipeline; Cyberspace project: the whole picture: Pentest agent; Promotion gate: Sign; How the platforms get built: Engineer merges
- Brief: research/R03-owner-decisions.md · Ledger: E030, E124, E079

### K16 · risk · open

Eleven bespoke source readers sit on interfaces the documents call unstable, and nobody is named to be paged or to run this in year three.

- Boxes: Intake: listen, fetch, verify: Feed reader; Intake: listen, fetch, verify: Reconciler
- Brief: — · Ledger: E154

### Q01 · question · open

What are cosmos and portico, and is each build-side, exec-side or both? Is G34 a practice range or real infrastructure?

- Boxes: Cyberspace platform: Prod substrates; Cyberspace platform: UAT substrates; Cyberspace project: the whole picture: Prod substrates; Runner VM and its credentials: Prod substrates
- Brief: research/R03-owner-decisions.md · Ledger: E026, E025

### Q03 · question · open

How does Kestra hand tasks to a runner that has no inbound ports, now that the attach broker is gone?

- Boxes: Runner VM and its credentials: Kestra orchestrator; Runner VM and its credentials: Flow tasks; Cyberspace platform: Kestra orchestrator; Cyberspace platform: Runner VM; Cyberspace platform: arrow Control plane → Runner VM
- Brief: research/R03-owner-decisions.md · Ledger: E058, E037

### Q04 · question · open

Is 'CyberSpace VDI' the existing AWS Workspaces in G35 or something new, and how does it relate to Devspace?

- Boxes: Cyberspace platform: CyberSpace VDI; Cyberspace platform: Devspace + Claude Code; Cyberspace platform: G35 Model Route
- Brief: research/R05-model-access.md · Ledger: E018, E002

### Q06 · question · open

Is the 'SAST sandbox' (project 1 in the delivery document) the code scan pipeline, an earlier name for it, or a separate system?

- Boxes: Cyberspace project: the whole picture: Code scan pipeline; Cyberspace project: the whole picture: Platform engineer; How the platforms get built: Repo harness
- Brief: research/R03-owner-decisions.md · Ledger: E078, E007

### Q07 · question · open

Where may a ported harness run, and what are ccsec and the other harnesses in the use-case inventory?

- Boxes: Where a model runs, across all systems: Ported harness; Where a model runs, across all systems: Existing harnesses; Harness migration tool: Harness archive; Cyberspace project: the whole picture: Harness migration tool
- Brief: research/R03-owner-decisions.md · Ledger: E073, E074

### Q08 · question · open

Can the documents that are cited but missing be added? See 'Sources cited but not available'. The pentest agent is known from two sentences.

- Boxes: Cyberspace project: the whole picture: Pentest agent; Cyberspace project: the whole picture: Code scan pipeline
- Brief: research/R03-owner-decisions.md · Ledger: E160, E011

### Q15 · question · open

Which ticketing system receives first-party findings, and where does repo ownership come from?

- Boxes: Code scan pipeline: Owning teams; Code scan pipeline: Review UI; Review and disclosure: Internal ticket; Review and disclosure: Owning teams
- Brief: research/R03-owner-decisions.md · Ledger: E127

### Q16 · question · open

How does the advisory mirror get into a VPC with no internet, and who builds the toolchain images and where? Neither has an intake path.

- Boxes: Analysis: triage, agent, sandbox: Advisory mirror; Analysis: triage, agent, sandbox: Sandbox task; Code scan pipeline in AWS: Image + log endpoints
- Brief: — · Ledger: E128, E129

### Q18 · question · open

Where does the reconciler write the events it re-emits? The document does not say.

- Boxes: Intake: listen, fetch, verify: Reconciler; Intake: listen, fetch, verify: Normaliser
- Brief: — · Ledger: E141, E142

### Q19 · question · open

Which CI system runs the promotion gate, and may it reach the model route for the security reviewer?

- Boxes: Promotion gate: CI checks; Promotion gate: Security reviewer; Promotion gate: G35 Model Route; Where a model runs, across all systems: Security reviewer in CI; Cyberspace platform: arrow Promotion gate → G35 Model Route
- Brief: research/R03-owner-decisions.md · Ledger: E060, E027

### Q20 · question · open

Build the persona image pipeline now or reuse the October plan? The October persona bundle no longer applies.

- Boxes: Runner VM and its credentials: Flow tasks
- Brief: — · Ledger: E059

### Q25 · question · open · new in v3

The schema has column names but no column types and no stated keys. Are the inferred primary and foreign keys right? Does source_cursor (v0.4) replace adapter_cursor (companion)?

- Boxes: Catalog and findings schema: package_version; Catalog and findings schema: analysis_run; Catalog and findings schema: finding; Catalog and findings schema: Lines are drawn only between neighbouring tables. Every other reference is in the table's column list (click a table). All keys are inferred: the document names columns and four unique rules, nothing else.; Catalog and findings schema: Not drawn. catalog: package_digest, package_source; operational: adapter_cursor, webhook_delivery, outbox, fuzz_job, spend_ledger; v0.4 adds source_cursor and event. Deferred: package_file, repo_component.
- Brief: research/R03-owner-decisions.md · Ledger: E168, E169, E173

### K17 · risk · open · new in v3

package_version has four writers: the cataloguer inserts it, the state-writer advances its state, triage updates its priority, and the cleaner marks it deleted. Column-level grants are stated only for the state-writer; the cleaner has no database role at all. repo_branch and finding_group have two writers each. A row stuck in a state has no single owner.

- Boxes: Catalog and findings schema: package_version; Catalog and findings schema: repo_branch; Catalog and findings schema: finding_group; Intake: listen, fetch, verify: Cataloguer; Analysis: triage, agent, sandbox: Orchestrator; Analysis: triage, agent, sandbox: Triage task; Code scan pipeline: Cleaner
- Brief: research/R03-owner-decisions.md · Ledger: E170, E172, E173

### Q26 · question · open · new in v3

Who writes advisory_match, notification and agent_config, and who stores the reachability verdict on dependency_edge? No database role covers them.

- Boxes: Catalog and findings schema: advisory_match; Catalog and findings schema: notification; Catalog and findings schema: agent_config; Catalog and findings schema: dependency_edge
- Brief: research/R03-owner-decisions.md · Ledger: E174

### Q27 · question · open · new in v3

Is the drop router part of the analysis side or the findings side? The design reads it as analysis, which is why the pipeline view now has an arrow from Analysis to Validator.

- Boxes: Code scan pipeline: arrow Analysis → Validator; Analysis: triage, agent, sandbox: Drop router; Scan agent: reach and guards: Drop router
- Brief: research/R03-owner-decisions.md · Ledger: E165, E117

### Q28 · question · open · new in v3

No document defines an API endpoint for any service, so the page has no API list. Is there a spec for the access layer's API or the Bitbucket plugin's 'changes since sequence N'? The only contract written down is the intake.event/1 message.

- Boxes: Intake: listen, fetch, verify: Metadata queue; Cyberspace platform: Human access layer
- Brief: research/R03-owner-decisions.md · Ledger: E177, E176

### K21 · risk · open · new in v3

Four use cases are too long to follow as sequence diagrams (the push story has 21 steps, the tour 18, detection 16, analysis 15) against a guide of about 12. They work as maps; as sequences they will not be read.

- Boxes: Code scan pipeline: Intake; Cyberspace project: the whole picture: Code scan pipeline
- Brief: — · Ledger: —

### X21 · conflict · open · new in v4

Once the gate is keyed on reach, who signs a read-only change inside a prod-capable envelope, and who approves a new tool for an agent?

- **Platform architect:** Moves to the envelope. A read-only prod runbook built from catalogued tasks, inside an approved envelope, ships on a team peer once the gate checks the fit by machine; SecOps is notified and can revoke. Until that check exists, E028 applies. A UAT read-only tool: the team alone. *(source: design party 24 Nov, round 3 (party/round3/platform.md))*
- **Security architect:** Holds the envelope. Inside an approved envelope a read-only prod runbook ships on the lead, without SecOps. A new read-only UAT tool needs the gate plus a team peer; it leaves the team when it enters a prod-capable envelope. *(source: design party 24 Nov, round 3 (party/round3/security.md))*
- **Data architect:** A team peer suffices when data reach is unchanged and the source enforces it by dataset. Where reach is only a proxy allowlist, a new prod query pack still leaves the team. *(source: design party 24 Nov, round 3 (party/round3/data.md))*
- **Agents architect:** Key the gate on reach. A new tool handed to a model leaves the team once, even read-only, because hostile input steers a model. For a fixed flow, a team engineer. *(source: design party 24 Nov, round 3 (party/round3/agents.md))*
- **Cyberops architect:** The envelope is reviewed once; read-only changes inside ship on a peer. Every new tool leaves the team, within one working day. *(source: design party 24 Nov, round 3 (party/round3/cyberops.md))*
- **Platform design (9 Nov):** An engineer for UAT-only components; lead plus SecOps for anything with a prod-capable persona or a write tool. *(source: cyberspace-platform-design.md §4)*

- Drawn: The lane flowchart shows both boxes as disputed. The envelope rule is drawn as proposed; E028 stands until the owner relaxes it.
- Who decides: Owner, with Security
- Boxes: A change's path: which lane: Sign-off inside the envelope; A change's path: which lane: A new tool for an agent; A change's path: which lane: Lead plus SecOps approve; Cyberspace platform landscape (proposed): Promotion gate; Cyberspace platform landscape (proposed): arrow Envelopes and entitlements → Promotion gate
- Brief: — · Ledger: E028, E027, E043, E056, E190

### X22 · conflict · open · new in v4

Where do the existing Claude Code harnesses run until the firm's wrapper is known, and who pays for the first port?

- **Platform architect:** An as-is harness in the sandbox is Claude at run time, against the owner's rule, and a second stack to operate. Until the wrapper is surveyed, harnesses stay in build against UAT. *(source: design party 24 Nov, round 3 (party/round3/platform.md))*
- **Agents architect:** Porting is the ticket to the sandbox, not to the platform. As-is harnesses run in build against UAT. Could live with: the owner rewords the rule as 'no Claude beside prod', and an as-is harness runs in the sandbox on UAT targets until the wrapper spike reports. *(source: design party 24 Nov, round 3 (party/round3/agents.md))*
- **Cyberops architect:** Port before the sandbox, never before entry. Harnesses keep running in G35 until the wrapper runs one real harness. Could live with: G35 is the named interim run place, never prod, and the platform funds the first port. *(source: design party 24 Nov, round 3 (party/round3/cyberops.md))*
- **Owner:** Claude must not touch prod and must not be deployed anywhere at runtime. *(source: owner's project notes, cyberops-runner-platform)*

- Drawn: Agreed and drawn as proposed: nothing un-ported runs in the agent sandbox or in execution. The arrow from today's hosts into the build workspace is drawn disputed and unproven.
- Who decides: Owner
- Boxes: Cyberspace platform landscape (proposed): arrow Where teams work today → Build workspace; Cyberspace platform landscape (proposed): Where teams work today; Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace project: the whole picture: arrow Harness migration tool → Cyberspace platform
- Brief: — · Ledger: E001, E002, E068, E073, E131, E010

### X23 · conflict · open · new in v4

May a person type a read-only query mid-investigation, and in what form?

- **Platform architect:** Yes: an ad hoc read as a catalogued job type, with a typed query, human-submitted, scope-guarded, recorded. *(source: design party 24 Nov, round 3 (party/round3/platform.md))*
- **Security architect:** Yes: a person may type a read-only query inside a running job's allowlist, recorded, results through the release gate. *(source: design party 24 Nov, round 3 (party/round3/security.md))*
- **Cyberops architect:** Needed. The string goes to the data source as a query, never to the runner as code; the scope guard checks target and read-only. Without it, responders return to the console. *(source: design party 24 Nov, round 3 (party/round3/cyberops.md))*
- **Agents architect:** Holds. Model-written free text behind a human click drives prod. An agent may only propose a catalogued runbook with parameters; a person submits. *(source: design party 24 Nov, round 3 (party/round3/agents.md))*
- **Platform design (9 Nov):** The job form is schema-validated with no free text; there is no interactive session into execution. *(source: cyberspace-platform-design.md §1, §5)*

- Drawn: A second arrow from the control plane to execution, marked disputed. Agreed by all and drawn as blocked: no arrow from the agent sandbox to execution.
- Who decides: Owner
- Boxes: Cyberspace platform landscape (proposed): arrow Access layer and control plane → Execution (read-only ad hoc query); Cyberspace platform landscape (proposed): Access layer and control plane; Cyberspace platform landscape (proposed): Execution; Cyberspace platform landscape (proposed): arrow Build workspace → Access layer and control plane
- Brief: — · Ledger: E016, E032, E006, E056

### X24 · conflict · open · new in v4

If the UAT replica holds real prod records, what must happen before a model in the build workspace may read it?

- **Data architect:** A model may read the replica only if it is synthetic or tokenised at load, by fixed rules, with no model. Otherwise build runs on the other three substrates. The tokeniser needs an owner and none is named. *(source: design party 24 Nov, round 3 (party/round3/data.md))*
- **Platform architect:** Real records in the replica are a replica defect; mask at source. Closing build sends teams back to G35. *(source: design party 24 Nov, round 3 (party/round3/platform.md))*
- **Security architect:** A replica holding real records is prod data. *(source: design party 24 Nov, round 3 (party/round3/security.md))*
- **Cyberops architect:** If the replica holds real records, the release gate comes before build. If not, no change. *(source: design party 24 Nov, round 3 (party/round3/cyberops.md))*

- Drawn: Build to UAT substrates is drawn unproven and disputed. All four agree on that drawing; they differ on the remedy.
- Who decides: Owner, with the data owners
- Boxes: Cyberspace platform landscape (proposed): arrow Build workspace → UAT substrates; Cyberspace platform landscape (proposed): UAT substrates; Cyberspace platform landscape (proposed): Release gate; Cyberspace platform landscape (proposed): Build workspace
- Brief: — · Ledger: E024, E020, E017, E047

### X25 · conflict · open · new in v4

Which host carries the build workspace first: G35 Workspaces or Devspace?

- **Platform architect:** The build workspace is a platform contract; hosts sit outside. G35 Workspaces first, Devspace once it is held to UAT. *(source: design party 24 Nov, round 3 (party/round3/platform.md))*
- **Cyberops architect:** G35 Workspaces is the first build workspace. Fix its attribution first. *(source: design party 24 Nov, round 3 (party/round3/cyberops.md))*
- **Security architect:** The host is undecided. Devspace uses the prod proxy; G35 has attribution issues. *(source: design party 24 Nov, round 3 (party/round3/security.md))*
- **Agents architect:** The workspace is a profile with no prod route. Devspace uses the prod proxy; draw it outside. *(source: design party 24 Nov, round 3 (party/round3/agents.md))*
- **Platform design (9 Nov):** The build plane uses Devspace pointed at UAT, with managed settings that deny prod endpoints. *(source: cyberspace-platform-design.md §3, §8)*

- Drawn: Both hosts in one box outside the platform. Build to prod is drawn unproven, not blocked.
- Who decides: Owner
- Boxes: Cyberspace platform landscape (proposed): Where teams work today; Cyberspace platform landscape (proposed): Build workspace; Cyberspace platform landscape (proposed): arrow Where teams work today → Build workspace; Cyberspace platform landscape (proposed): arrow Build workspace → Prod substrates
- Brief: — · Ledger: E020, E013, E014, E002, E003

### Q29 · question · open · new in v4

Does 'no Claude at run time' cover the agent sandbox, or only compute with prod reach? The landscape rests on the weaker rule (no model beside prod credentials), which is still only proposed. See X02.

- Boxes: Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace platform landscape (proposed): arrow Execution → Model gateway; Cyberspace platform landscape (proposed): arrow Where teams work today → Build workspace
- Brief: — · Ledger: E001, E015

### Q30 · question · open · new in v4

May SecOps review an envelope once instead of each prod-capable change? Self-service as the room recommends it depends on this, and it relaxes the platform design's approval rule.

- Boxes: Cyberspace platform landscape (proposed): Envelopes and entitlements; Cyberspace platform landscape (proposed): arrow Envelopes and entitlements → Promotion gate; A change's path: which lane: Sign-off inside the envelope; A change's path: which lane: Lead plus SecOps approve
- Brief: — · Ledger: E028

### Q31 · question · open · new in v4

Does the UAT replica hold real prod records? If it does, who owns the tokeniser or the redaction rules?

- Boxes: Cyberspace platform landscape (proposed): arrow Build workspace → UAT substrates; Cyberspace platform landscape (proposed): UAT substrates; Cyberspace platform landscape (proposed): arrow Release gate → Build workspace
- Brief: — · Ledger: E024, E047

### Q32 · question · open · new in v4

Which clocks will the gate and the approvers commit to (same day for content, one working day outside the team, fifteen minutes for a prod job in an incident), and where is a prod job approved?

- Boxes: A change's path: which lane: A team peer approves; A change's path: which lane: Lead plus SecOps approve; A change's path: which lane: A new tool for an agent; Cyberspace platform landscape (proposed): arrow SecOps and data owners → Access layer and control plane
- Brief: — · Ledger: E162, E028, E050, E199

### Q34 · question · open · new in v4

Who owns envelopes, who is the data owner for each prod source, where does a team ask for an entitlement, and must an existing firm entitlement and classification scheme be used?

- Boxes: Cyberspace platform landscape (proposed): Envelopes and entitlements; Cyberspace platform landscape (proposed): SecOps and data owners; Cyberspace platform landscape (proposed): arrow SecOps and data owners → Envelopes and entitlements; Cyberspace platform landscape (proposed): arrow Access layer and control plane → Envelopes and entitlements
- Brief: — · Ledger: E049

### Q35 · question · open · new in v4

Who may compose a persona inside an approved envelope: any team member, or only the team lead?

- Boxes: Cyberspace platform landscape (proposed): Catalogue; Cyberspace platform landscape (proposed): Envelopes and entitlements; A change's path: which lane: Sign-off inside the envelope
- Brief: — · Ledger: E022, E038

### Q36 · question · open · new in v4

Must the scan and pen-test agents pass the one gate, live in the one catalogue and be launched through the platform's control plane? Today the scan pipeline has its own promotion path, orchestrator and broker. See K14.

- Boxes: Cyberspace platform landscape (proposed): Promotion gate; Cyberspace platform landscape (proposed): Catalogue; Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace platform landscape (proposed): arrow Access layer and control plane → Agent sandbox
- Brief: — · Ledger: E030, E124, E079, E115

### Q37 · question · open · new in v4

Is a cyber team the tenant, and where does the team record (members, lead, quota) live?

- Boxes: Cyberspace platform landscape (proposed): Cyber team; Cyberspace platform landscape (proposed): Envelopes and entitlements
- Brief: — · Ledger: E198

### Q38 · question · open · new in v4

Is the code scan pipeline's intake (listen, fetch, verify) a platform capability or the tenant's own? The landscape has no box for it.

- Boxes: Cyberspace platform landscape (proposed): Agent sandbox; Code scan pipeline: Intake
- Brief: — · Ledger: E197, E100

The ten items below are the owner's definition of the platform (ledger E196, E198), one per phrase, with what the design carries today and what is missing.

### R01 · requirement · partial · new in v4

"secure": Carried by the gate, the signed catalogue, per-run credentials and guards outside the workload. Missing: 'secure' has no testable definition, and four lines that matter are unproven.

- Boxes: Cyberspace platform landscape (proposed): Promotion gate; Cyberspace platform landscape (proposed): Catalogue; Cyberspace platform landscape (proposed): Access layer and control plane; Cyberspace platform landscape (proposed): arrow Agent sandbox → Prod substrates; Cyberspace platform landscape (proposed): arrow Build workspace → Access layer and control plane
- Brief: — · Ledger: E196

### R02 · requirement · partial · new in v4

"isolated": Drawn as three kinds of workspace that do not share credentials. Missing: proof. UAT and prod share one flat network, and how the sandbox is attached to it is unknown.

- Boxes: Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace platform landscape (proposed): Execution; Cyberspace platform landscape (proposed): Build workspace; Cyberspace platform landscape (proposed): arrow Agent sandbox → Prod substrates; Cyberspace platform landscape (proposed): arrow Agent sandbox → UAT substrates; Cyberspace platform landscape (proposed): arrow Build workspace → Prod substrates
- Brief: — · Ledger: E196

### R03 · requirement · partial · new in v4

"persona-configurable workspace": The room's reading: Security owns an envelope, a team composes personas inside it the same day. Missing: any decision, the fit check, and how a same-day persona squares with a persona image that has to be built.

- Boxes: Cyberspace platform landscape (proposed): Envelopes and entitlements; Cyberspace platform landscape (proposed): Catalogue; Cyberspace platform landscape (proposed): Build workspace; A change's path: which lane: Sign-off inside the envelope; A change's path: which lane: A new or wider envelope
- Brief: — · Ledger: E196

### R04 · requirement · partial · new in v4 (lowered from covered after review)

"compute": Three kinds: build workspace, execution, agent sandbox. Missing: sizes, quotas and a team record; none of it is built.

- Boxes: Cyberspace platform landscape (proposed): Build workspace; Cyberspace platform landscape (proposed): Execution; Cyberspace platform landscape (proposed): Agent sandbox
- Brief: — · Ledger: E196

### R05 · requirement · partial · new in v4

"governed data access": A record of envelopes and entitlements, two restricted stores, one release gate. Missing: a data owner for any source, a classification scheme, redaction rules, retention, and whether the UAT replica holds real records.

- Boxes: Cyberspace platform landscape (proposed): Envelopes and entitlements; Cyberspace platform landscape (proposed): Release gate; Cyberspace platform landscape (proposed): Evidence store; Cyberspace platform landscape (proposed): Findings store; Cyberspace platform landscape (proposed): arrow Build workspace → UAT substrates; Cyberspace platform landscape (proposed): arrow Release gate → Build workspace
- Brief: — · Ledger: E196

### R06 · requirement · partial · new in v4

"operational tooling": Runbooks, tools, query packs and detection rules live in the catalogue and run in execution. Missing: the follow-up query (disputed), an inventory of the tools teams need, and what cosmos and portico are.

- Boxes: Cyberspace platform landscape (proposed): Catalogue; Cyberspace platform landscape (proposed): Execution; Cyberspace platform landscape (proposed): Access layer and control plane; Cyberspace platform landscape (proposed): arrow Access layer and control plane → Execution (read-only ad hoc query); Cyberspace platform landscape (proposed): Prod substrates
- Brief: — · Ledger: E196

### R07 · requirement · partial · new in v4

"agent capabilities": One agent sandbox with a model gateway, shared by scan, pen-test and ported harnesses. Missing: what the firm's wrapper supports, access to a cyber model, and a first real harness ported.

- Boxes: Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace platform landscape (proposed): Model gateway; Cyberspace platform landscape (proposed): arrow Where teams work today → Build workspace
- Brief: — · Ledger: E196

### R08 · requirement · partial · new in v4

"build, test, investigate, automate and respond": Build and test have a home. Missing: investigate lacks the follow-up query; automate stops at agents that cannot touch prod; respond has no approval clock and no place where a prod job is approved.

- Boxes: Cyberspace platform landscape (proposed): Build workspace; Cyberspace platform landscape (proposed): arrow Build workspace → UAT substrates; Cyberspace platform landscape (proposed): arrow Access layer and control plane → Execution (read-only ad hoc query); Cyberspace platform landscape (proposed): Agent sandbox; Cyberspace platform landscape (proposed): arrow SecOps and data owners → Access layer and control plane
- Brief: — · Ledger: E196

### R09 · requirement · partial · new in v4

"without risking production": One line is closed by design: no model route from execution. Missing: sandbox to prod, build to prod, a model driving jobs from the desktop, and UAT data that may be prod data are all unproven.

- Boxes: Cyberspace platform landscape (proposed): arrow Execution → Model gateway; Cyberspace platform landscape (proposed): arrow Agent sandbox → Prod substrates; Cyberspace platform landscape (proposed): arrow Build workspace → Prod substrates; Cyberspace platform landscape (proposed): arrow Build workspace → Access layer and control plane; Cyberspace platform landscape (proposed): arrow Build workspace → UAT substrates
- Brief: — · Ledger: E196

### R10 · requirement · partial · new in v4

"Cyber teams can come in and modify their own agents": Drawn as lanes by reach: content alone with a team peer, the same day; reach through people outside the team. Missing: the owner's agreement to relax E028, the fit check (about a quarter of platform work), and three disputes on who signs.

- Boxes: A change's path: which lane: A team peer approves; A change's path: which lane: Sign-off inside the envelope; A change's path: which lane: A new tool for an agent; A change's path: which lane: A new or wider envelope; Cyberspace platform landscape (proposed): Promotion gate; Cyberspace platform landscape (proposed): arrow Envelopes and entitlements → Promotion gate
- Brief: — · Ledger: E198

## Ask: Artifactory team


### R11 · requirement · partial · new in v4 (added after review)

"The agent sandbox is an engineering effort inside Cyberspace, not the whole thing": Drawn as one capability of sixteen, in the Run zone beside execution, with today's code scan and pen-test agents named on its face. Missing: the owner's word that those agents share this one sandbox and pass the same gate (K14).

- Ask: Owner (architecture) · Drawn on: Cyberspace platform landscape (Agent sandbox, Execution, Build workspace) · Ledger: E197

### Q11 · question · open

Artifactory: a read-only identity with query access, the repository list by type, whether download statistics are on, and whether it proxies every ecosystem in scope.

- Boxes: Code scan pipeline: Artifactory; Cyberspace project: the whole picture: Firm code hosts
- Brief: research/R09-artifactory.md · Ledger: E150

## Ask: Bitbucket team

### K11 · risk · open

A long-lived Bitbucket token gives read access to first-party source in every project.

- Boxes: Intake: listen, fetch, verify: Fetch worker; Code scan pipeline: Bitbucket + GitHub
- Brief: research/R07-bitbucket.md · Ledger: —

### Q10 · question · open

Bitbucket: is '600K to 700K' the repository count, which repositories matter, and is a plugin, push-log access, a mirror or an exempt service account allowed?

- Boxes: Intake: listen, fetch, verify: A source; Intake: listen, fetch, verify: Feed reader; Code scan pipeline: Bitbucket + GitHub
- Brief: research/R07-bitbucket.md · Ledger: E147, E148

## Ask: Devspace platform team

### K03 · risk · open

The build plane assumes Devspace can be held to UAT. Today Devspace connects through prod and UAT proxies and to a target account; its design is undocumented and another team owns it. Cyberops currently use Claude Code through AWS Workspaces in G35 or outside the firm, not Devspace.

- Boxes: Cyberspace platform: Devspace + Claude Code; Cyberspace platform: CyberSpace VDI; Devspace (inferred, not documented): Firm proxies; Devspace (inferred, not documented): Target account role; Cyberspace project: the whole picture: Devspace
- Brief: research/R01-devspace.md · Ledger: E020, E013, E014, E002, E004

### K12 · risk · open

Claude Code in Devspace runs with permission prompts bypassed, so the container is the only boundary. Whether one employee's session can reach another's is unknown.

- Boxes: Devspace (inferred, not documented): Per-user container; Where a model runs, across all systems: Claude Code in Devspace
- Brief: research/R01-devspace.md · Ledger: E062, E065

### Q05 · question · open

Confirm or correct the inferred Devspace design: compute and isolation, proxies, audit path, target-account role, where model calls go.

- Boxes: Devspace (inferred, not documented): Per-user container; Devspace (inferred, not documented): Control plane; Devspace (inferred, not documented): Terminal relay; Devspace (inferred, not documented): Target account role; Devspace (inferred, not documented): Model access; Devspace (inferred, not documented): Persistent volume; Devspace (inferred, not documented): Corporate sign-in
- Brief: research/R01-devspace.md · Ledger: E061, E063, E064, E066, E065

## Ask: G35 and model gateway owners

### X19 · conflict · open

What and where is the model endpoint, and does the team have access? It is described four ways.

- **Platform design:** 'G35 Model Route (LLM gateway)', build plane only. *(source: cyberspace-platform-design.md §2, §11)*
- **Owner:** G35 is an AWS account; its model access has constraints and attribution issues. The team has no access to a cyber model. *(source: owner's project notes, cyberops-runner-platform)*
- **Scan design:** Cyber models, hosted in the same AWS account, reached through SmartSDK. *(source: oss-vulnerability-discovery-pipeline-design.md v0.3 §2; question-log.md D-03)*
- **Pentest note:** A Bedrock-hosted model. *(source: owner's project notes, agentic-pentest)*

- Drawn: Two endpoint boxes on the model view, both marked as gaps.
- Who decides: Owner
- Boxes: Where a model runs, across all systems: G35 Model Route; Where a model runs, across all systems: Cyber models; Cyberspace project: the whole picture: Model access; Cyberspace platform: G35 Model Route; Analysis: triage, agent, sandbox: Cyber model; Devspace (inferred, not documented): Model access; Scan agent: reach and guards: Cyber model; Code scan pipeline in AWS: Cyber model; Cyberspace project: the whole picture: arrow Harness migration tool → Model access
- Brief: research/R05-model-access.md · Ledger: E002, E003, E005, E086, E023, E011, E130

### Q21 · question · open

Which AWS account hosts the scan pipeline, is it G35, and how does it relate to the accounts Cyberspace uses?

- Boxes: Code scan pipeline: Intake; Code scan pipeline: Analysis; Code scan pipeline in AWS: Edge functions; Code scan pipeline in AWS: Agent task
- Brief: research/R05-model-access.md · Ledger: E091, E002

### Q39 · question · open · new in v4

Is there one model gateway for the build workspace and the agent sandbox, who owns the approved model list, and where are prompt logs kept and read? See X19, K20.

- Boxes: Cyberspace platform landscape (proposed): Model gateway; Cyberspace platform landscape (proposed): arrow Model gateway → Findings store; Cyberspace platform landscape (proposed): arrow Agent sandbox → Model gateway
- Brief: — · Ledger: E130, E023, E178, E005

## Ask: GitHub team

### Q09 · question · open

Is GitHub github.com or Enterprise Server? If github.com it cannot reach a private receiver.

- Boxes: Intake: listen, fetch, verify: Webhook receiver; Intake: listen, fetch, verify: A source; Code scan pipeline: Bitbucket + GitHub
- Brief: research/R08-github.md · Ledger: E149

## Ask: Legal

### K09 · risk · open

Registry terms can stop intake: Maven Central treats bulk download as abuse (IP blocks up to 30 days, shared with the firm's builds); PyPI's policy says 'not for research'; npm caps monthly requests.

- Boxes: Intake: listen, fetch, verify: A source; Intake: listen, fetch, verify: Fetch worker; Code scan pipeline: Public registries
- Brief: research/R14-legal.md · Ledger: E146

### Q14 · question · open

Disclosure policy: who signs off, embargo length (90 and 14 days are placeholders), escalation, and whether internal teams may be told about an embargoed finding.

- Boxes: Review and disclosure: Draft disclosure; Review and disclosure: Library maintainers; Code scan pipeline: Library maintainers
- Brief: research/R14-legal.md · Ledger: E126, E111

## Ask: Network and cloud teams

### Q12 · question · open

Proxy allowlist per registry, throughput (20 MB/s is assumed), shared egress address, how a Lambda authenticates to the proxy; are Lambda MicroVMs approved in the firm's Region?

- Boxes: Intake: listen, fetch, verify: Fetch worker; Intake: listen, fetch, verify: Feed reader
- Brief: research/R10-network-cloud.md · Ledger: E139

### Q23 · question · open · new in v3

How is the Analysis VPC attached to the firm network? The same section says it has no internet gateway and no NAT, and that UAT and prod share a flat network. 'No route out' may mean 'no route to the internet' and say nothing about a route to prod.

- Boxes: Code scan pipeline in AWS: arrow Sandbox task → Prod account; Code scan pipeline in AWS: Prod account; Code scan pipeline in AWS: Sandbox task; Code scan pipeline in AWS: Data + model endpoints
- Brief: research/R10-network-cloud.md · Ledger: E187, E012

### Q24 · question · open · new in v3

Which Region is this in, and which VPC holds the Aurora cluster and RDS Proxy, the core intake functions and the review UI's load balancer? No subnet, Availability Zone or address range is named either.

- Boxes: Code scan pipeline in AWS: Catalog + findings; Code scan pipeline in AWS: Core functions; Code scan pipeline in AWS: Edge functions; Code scan pipeline in AWS: Agent task
- Brief: research/R10-network-cloud.md · Ledger: E185, E186

### Q33 · question · open · new in v4

May the agent sandbox leave the flat network (a network with no attachment to the firm's)? Until it does, who owns the risk of the pen-test agent running on it? See Q23.

- Boxes: Cyberspace platform landscape (proposed): arrow Agent sandbox → Prod substrates; Cyberspace platform landscape (proposed): arrow Agent sandbox → UAT substrates; Cyberspace platform landscape (proposed): Agent sandbox
- Brief: — · Ledger: E012, E187, E091, E011, E113

## Ask: Platform engineers (spike)

### K04 · risk · open

Sandbox network isolation rests on nono, which nobody has verified; on Fargate the task has a network interface regardless. The review says nono should be a second layer.

- Boxes: Analysis: triage, agent, sandbox: Sandbox task; Where a model runs, across all systems: Scan agent task; Cyberspace project: the whole picture: Pentest agent; Scan agent: reach and guards: Sandbox task; Code scan pipeline in AWS: Sandbox task; Scan agent: reach and guards: arrow Sandbox task → Internet
- Brief: research/R04-nono-spike.md · Ledger: E113, E112, E012

### K08 · risk · open

The session broker is a single high-value component: it issues every agent's credentials.

- Boxes: Analysis: triage, agent, sandbox: Session broker; Scan agent: reach and guards: Session broker
- Brief: — · Ledger: E115

### K15 · risk · open

The harness migration tool has only run on invented inputs, and its second reader is another agent, not a person.

- Boxes: Harness migration tool: Architect agent; Harness migration tool: Verifier; Harness migration tool: Harness archive; Cyberspace project: the whole picture: Harness migration tool
- Brief: — · Ledger: E068, E074

## Ask: Security / SecOps

### X20 · conflict · open

Who approves a prod run, and where do approvals live?

- **Runner design (14 Oct):** Manager / SecOps. *(source: cyberops-ephemeral-runner-design.md §4, §8)*
- **Platform design (9 Nov):** Lead / SecOps for jobs; lead + SecOps for promotion. In the access layer, or in the firm's change system with the access layer as the view: open. *(source: cyberspace-platform-design.md §4, §6, §12)*

- Drawn: 'Lead / SecOps' (the superseding document).
- Who decides: Security, with the owner
- Boxes: Cyberspace platform: Lead / SecOps; Cyberspace platform: Human access layer; One job, state by state: Wait for approval; Promotion gate: Lead + SecOps; Cyberspace platform: arrow Control plane → Human access layer
- Brief: research/R13-security.md · Ledger: E050, E051, E028

### K01 · risk · open

Unsanitised prod evidence can reach the build plane. A pause state shows 'the evidence collected so far' in the access layer, mid-run, before sanitisation; the access layer is reachable from the desktop where Claude Code runs. That breaks the rule that sanitisation is the only path back.

- Boxes: Cyberspace platform: Human access layer; Cyberspace platform: Kestra orchestrator; Cyberspace platform: Sanitisation; Cyberspace platform: CyberSpace VDI; One job, state by state: Approver decides
- Brief: research/R13-security.md · Ledger: E033, E017, E018, E046

### K06 · risk · open

UAT and prod share one flat network. The scan agent reads first-party source and the pentest agent runs model-written test code; both are kept from prod only by security groups, IAM and nono.

- Boxes: Where a model runs, across all systems: Scan agent task; Where a model runs, across all systems: Pentest agent; Cyberspace project: the whole picture: Pentest agent; Cyberspace project: the whole picture: UAT substrates; Code scan pipeline: Analysis; Code scan pipeline in AWS: Prod account; Code scan pipeline in AWS: arrow Sandbox task → Prod account
- Brief: research/R04-nono-spike.md · Ledger: E012, E011, E112

### K13 · risk · open

Object Lock in compliance mode cannot be undone and no retention period is set.

- Boxes: Cyberspace platform: Evidence store; Runner VM and its credentials: Evidence store
- Brief: research/R13-security.md · Ledger: E044, E045

### Q02 · question · open

Sanitisation: what must be redacted, who owns the classifier, and is the classifier itself a model? If so, a model runs on raw prod evidence.

- Boxes: Cyberspace platform: Sanitisation; One job, state by state: Sanitise
- Brief: research/R13-security.md · Ledger: E046, E047

### K19 · risk · open · new in v3

Nothing independent shows that a reproducer ran. The agent drives the sandbox and writes the finding; the validator 're-verifies the reproducer hash', which proves the file is unchanged, not that it works. Package content that steers the agent could produce a well-formed finding with a reproducer that never ran, and it would pass.

- Boxes: Scan agent: reach and guards: Validator; Scan agent: reach and guards: Sandbox task; Scan agent: reach and guards: Write to the drop; Analysis: triage, agent, sandbox: Validator
- Brief: research/R13-security.md · Ledger: E195, E107

### K20 · risk · open · new in v3

First-party source code and exploit detail go to the model in every prompt. The documents classify model invocation logs as findings but do not say where those logs are kept, who can read them, or whether the model service keeps anything.

- Boxes: Scan agent: reach and guards: arrow Scan agent → Cyber model; Code scan pipeline in AWS: arrow Data + model endpoints → Cyber model; Scan agent: reach and guards: Cyber model
- Brief: research/R05-model-access.md · Ledger: E178, E130

## Ask: SmartSDK owners

### K05 · risk · open

Three systems are designed on SmartSDK and nobody in the project knows what it can do. The harness migration tool has an SDK surveyor built for exactly this question; it has never been pointed at the real package.

- Boxes: Cyberspace project: the whole picture: SmartSDK; Cyberspace project: the whole picture: Code scan pipeline; Cyberspace project: the whole picture: Pentest agent; Cyberspace project: the whole picture: Harness migration tool; Analysis: triage, agent, sandbox: Agent task; Harness migration tool: SDK surveyor; Harness migration tool: SmartSDK package
- Brief: research/R02-smartsdk.md · Ledger: E010, E131, E130, E070, E068

### Q17 · question · open

How are the cyber models invoked and where are tokens metered? Metering must sit outside the agent for the budget kill to work.

- Boxes: Analysis: triage, agent, sandbox: Cyber model; Analysis: triage, agent, sandbox: Agent task; Cyberspace project: the whole picture: SmartSDK; Scan agent: reach and guards: Over time, token or spend limit?; Scan agent: reach and guards: Cyber model
- Brief: research/R02-smartsdk.md · Ledger: E130, E123

### Q22 · question · open

Who owns SmartSDK and will receive the ranked changes the migration tool produces?

- Boxes: Harness migration tool: SmartSDK owners; Harness migration tool: SmartSDK package; Cyberspace project: the whole picture: SmartSDK
- Brief: research/R02-smartsdk.md · Ledger: E010

### K18 · risk · open · new in v3

The run's stop path is sound in shape (the orchestrator kills, the broker refuses) but two of its triggers cannot fire yet: no limit has a number, and token use has nothing to measure it, since metering 'must sit outside the agent' and where is undecided. Until then a run that loops is stopped only by a time limit nobody has set.

- Boxes: Scan agent: reach and guards: Over time, token or spend limit?; Scan agent: reach and guards: Scan agent; Scan agent: reach and guards: Cyber model; Analysis: triage, agent, sandbox: Orchestrator
- Brief: research/R02-smartsdk.md · Ledger: E191, E192, E130

## Ask: Team that ran the 7-month scan

### Q13 · question · open

The earlier 7-month manual scan: what 'all' covered, build-and-run or read only, tooling and model, cost, where results live, and the list of what was scanned.

- Boxes: Code scan pipeline: Public registries; Code scan pipeline: Findings; Cyberspace project: the whole picture: Code scan pipeline
- Brief: research/R11-earlier-manual-scan.md · Ledger: E096
