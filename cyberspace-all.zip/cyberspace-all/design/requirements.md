# Requirement register — Cyberspace project

Version v4, 2026-11-24. The "spec" is the owner's own definition of the platform, given on 24 Nov (ledger E196, E198; dictated, wording approximate). One row per phrase. Coverage says what the design carries today, not what is built: nothing of the platform is built, and nothing on the landscape is decided.

11 requirements: 0 covered, 11 partial, 0 uncovered, 0 out of scope. Each one is also an item on the page (R01 to R11), with the one line on what is missing.

| ID | Requirement (the owner's words) | Spec ref | Kind | Covered by | Coverage |
|---|---|---|---|---|---|
| R01 | secure | E196 | quality | landscape: Promotion gate, Catalogue, Access layer and control plane | partial: no testable definition of "secure"; four lines that matter are unproven |
| R02 | isolated | E196 | quality | landscape: Build workspace, Execution, Agent sandbox as separate workspaces | partial: no proof; one flat network; sandbox attachment unknown |
| R03 | persona-configurable workspace | E196 | functional | landscape: Envelopes and entitlements, Catalogue; lane flowchart; use case "A team lead composes a persona inside an approved envelope" | partial: no decision; fit check not designed; persona image against same-day persona |
| R04 | compute | E196 | functional | landscape: Build workspace, Execution, Agent sandbox | partial: drawn, but no sizes, quotas or team record, and nothing built |
| R05 | governed data access | E196 | functional | landscape: Envelopes and entitlements, Evidence store, Findings store, Release gate; use case "Ask for a new data entitlement" | partial: no data owner named, no classification scheme, redaction rules and retention unset |
| R06 | operational tooling | E196 | functional | landscape: Catalogue, Execution, Access layer and control plane | partial: follow-up query disputed (X23); no inventory of tools; cosmos and portico unknown |
| R07 | agent capabilities | E196 | functional | landscape: Agent sandbox, Model gateway; use case "Bring in an existing harness from where it runs today" | partial: wrapper unknown; no cyber model access; no real harness ported |
| R08 | build, test, investigate, automate and respond | E196 | functional | build and test: Build workspace, UAT substrates; the rest: use cases on the landscape | partial: investigate lacks the follow-up query; automate stops at agents that cannot touch prod; respond has no approval clock |
| R09 | without risking production | E196 | constraint | landscape: blocked arrow Execution → Model gateway | partial: sandbox to prod, build to prod, jobs from the desktop and UAT data are unproven |
| R10 | cyber teams can come in and modify their own agents | E198 | functional | lane flowchart "A change's path: which lane"; four self-service use cases | partial: needs the owner to relax E028; fit check is about a quarter of platform work; three disputes on who signs (X21) |
| R11 | the agent sandbox is one effort inside Cyberspace, not the whole thing | E197 | structural | landscape: Agent sandbox is one of sixteen capabilities, beside Execution | partial: needs the owner's word that scan and pen-test agents share it and pass the same gate (K14) |

Looking the other way: the landscape has no box that no phrase asks for. One thing the documents design has no phrase and no box: the code scan pipeline's intake (question Q38).
