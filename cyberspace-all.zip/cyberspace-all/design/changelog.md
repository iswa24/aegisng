# Change log — Cyberspace project design

## v4 — 2026-11-24

Work that followed a four-round design party with five architects (`party/`, `party-notes.md`). No person was in the room, so nothing in this version is a decision. No new source document was read. Five ledger rows were added for the owner's own statements (E196 to E200); proposals from the room are not evidence and have no row.

- **New first design: "Cyberspace platform landscape (proposed)", level C0.** Cyberspace drawn as one platform: 16 boxes, 28 arrows, four zones (Build, Govern, Run, Governed data), two groups of people, three outside systems. It is the page's starting point.
- **How the old top view relates to it, and why.** "Cyberspace project: the whole picture" is kept exactly as it was and stays C0. It now sits under the landscape in the menu (`parent`), and the landscape's Build workspace, Execution and Agent sandbox boxes open it ("Also open"). The two views are two cuts at the same height: the landscape by capability, as the room recommends; the whole picture by effort, as the documents draw four systems. An effort such as the execution platform spans five capability boxes, so neither view can honestly be the parent level of the other. Keeping both at C0 means no existing use case rolls up through the new view: all 31 read as before, and the check stays clean. The landscape's own use cases are written on it and on its flowchart.
- **Where today's efforts sit.** From the landscape: Execution opens the Cyberspace platform design (also the runner and the job flowchart); Agent sandbox opens the scan pipeline's Analysis design (also the scan agent, the pipeline and its AWS view); Build workspace opens Devspace (also the harness migration tool and the Cyberspace platform design); Promotion gate opens the new flowchart (also the existing gate design); Findings store opens the schema and the disclosure flowchart; Model gateway opens the cross-cutting model view.
- **New flowchart: "A change's path: which lane"**, hung from the Promotion gate. Five lanes with the clock each architect proposed. Two lanes are drawn disputed.
- **Seven new use cases.** A tour of the landscape, and six self-service stories: change an agent's instructions, add a tool, compose a persona inside an envelope, ask for a data entitlement, ask a follow-up read-only question (disputed), bring in an existing harness. Each walks step by step and has a sequence diagram.
- **26 new items.** The owner's definition as ten requirements (R01 to R10: 1 covered, 9 partial); five conflicts the room left open (X21 to X25) with each architect's final position; eleven questions (Q29 to Q39). No existing item was closed or reworded.
- **Honest marking.** Everything new is `proposed`. Five parts are `disputed`: the arrow from today's hosts, the ad hoc query, build to UAT data, and two lanes. Eight arrows are `unknown` with a label that says what is unproven, among them sandbox to prod, build to prod and jobs submitted from the desktop. Two arrows are closed by design: execution to the model gateway, and the agent sandbox to execution. Boxes and arrows that exist only as the room's proposal are `assumed`.
- **Left off the landscape, on purpose** (listed on the page under "Left off the platform landscape"): the scan pipeline's intake, Claude Code's own model calls, the gate's candidate run in a sandbox, pause-state evidence in the access layer, a separate credential broker, the data register and the team record. Three of these were asked for by an architect as arrows or boxes; they did not fit in 16 boxes without lines crossing the core, and each is in a box's details or an open item instead.
- **Layout.** No arrow on the landscape was routed by hand except the two that run round the edge: raw evidence along the bottom to the release gate, and the sanitised copy up the left side to the build workspace (both `keep`). `page.py straighten` found nothing to remove.
- **Housekeeping.** `changed` flags from v3 cleared; everything added in v4 is flagged. The Projects copy of the documents was not touched. Rhea, Finn, Dara, Aria and Vera were not run as separate agents in this round: the lead design architect covered the evidence, flow, data, agent and review parts from the kit's guides.
- **Build script:** `design/build/v4_landscape.py` (reads the v3.2 page, writes this one).
- Design check: 0 problems, 0 warnings. 18 designs, 38 use cases walked, none stuck.


### Same day, after an independent review and a layout pass

Made by the session lead, not by the room. No new evidence and no decision.

- **Layout.** The landscape now reads left to right (build, govern, run, governed data) with one loop back and no crossing arrows. The lines that must not cross between zones moved to their own design, "What must not cross between zones" (8 boxes, 9 arrows).
- **Review fixes (review-v4.md, must-change 1 to 7):**
  - The same-day lane inside a prod-capable envelope now says on its face that it is not open yet.
  - Self-service is stated on the landscape: the team's arrow, the gate's face and a note.
  - Disputed arrows now show as disputed (a fix in the page engine); the sandbox's model line is marked disputed because it rests on Q29.
  - "No agent drives a job" is drawn unproven: agreed by all five, enforced by nothing (K02).
  - Build to prod reads "open today on Devspace: must be closed".
  - Raw evidence shown at a pause, before sanitisation, is drawn (K01). The data zone is titled "one way to the build side".
  - Zone titles say Cyberspace; the model gateway has its frame; today's efforts are named on the box faces.
- **Review fixes (should-change):** R04 lowered to partial; R11 added for the owner's sandbox sentence; the build workspace no longer opens the Devspace design by default (X25 is open); older items K01, K02, K06, K08, K14, K20 and X02 linked to the landscape; two tour steps reworded so unbuilt things are not stated as fact.
- **Not done from the review:** an outer "Cyberspace" frame (people and outside systems sit between the zones, so one rectangle cannot hold only the platform); a findings reviewer box (it is on the gate's face instead); the code store the data architect asked for.
- Design check: 19 designs, 38 use cases walked, 0 problems, 0 warnings.

## v3.2 — 2026-11-24

Drawing only, no design change. The page is on design kit 1.2.

- Arrows are drawn as the simplest line: straight when boxes line up, one line at an angle when nothing is in the way.
- 28 hand-set arrow routes were removed because the page draws them with fewer corners without them.
- Arrows with two or more corners: 74 before, 28 now, of 227. Most of the 28 are on the schema and AWS views, which keep right angles.
- Two boxes on the AWS view moved 20px to line up.
- Design check: 0 problems, 0 warnings.

## v3.1 — 2026-11-24

Page tooling only, made by the design kit's maintainer after the team run. No design decision, no new source.

- The page is on design kit 1.1.
- Menu headings (Failure paths, Across systems, Data lifecycle, Inside the analysis) are no longer drawn as actors on the use case diagram.
- The AWS view opens from the Code scan pipeline box ("Also open") and reads the same at every level.
- The Promotion gate, the Human access layer and the Validator are marked as guards, so "Show what this can reach" stops at them.
- Design check: 0 problems, 0 warnings.

## v3 — 2026-11-23

Work that followed a design party (`party-notes.md`, `party-transcript.md`). No person was in the room, so nothing in this version is a decision; no new source document was read; no brief has been sent.

- **Levels.** L0 / L2 / L3 renamed C0 / C2 / C3; the schema is C4. No C1 views were added. All ten level mismatches settled:
  - *fixed the coarser view:* Control plane → Runner VM, Promotion gate → G35 Model Route and Control plane → Human access layer (approval needed) added on the platform view; Harness migration tool → Model access on the whole picture; Analysis → Validator on the pipeline view; a blocked Agent task → Findings arrow and a Quarantine box on the Analysis view.
  - *fixed the detailed view:* "One job, start to finish" is now "One job, state by state": its *Lead / SecOps* box became the state *Wait for approval* and *Sanitise* got its own id, so neither is read as a platform-view box. "After a finding lands" became "Review and disclosure", hung off Review UI; the validator's keep-or-quarantine check moved to the agent design.
  - *fixed the use case:* "Run a read-only job against prod" and "A job is stopped early" tell their cross-container steps on the platform view; new "A job's states, one by one" walks the flowchart; four finding use cases rewritten.
- **New views (all from the documents, stopped where the documents stop).**
  - *Catalog and findings schema* (C4): 11 tables with the columns the companion lists and the two that intake v0.4 adds. Types are blank (none is stated). Keys and 11 relationship lines are inferred from column names and marked assumed.
  - *Code scan pipeline in AWS* (AWS): to VPC level only, 11 official icons embedded. No Region, subnet or Availability Zone frame. Database and core functions drawn outside both VPCs as unknown.
  - *Scan agent: reach and guards* (Agents): what the agent sees and is blind to, two fixed-rule guards, the kill path, three blocked paths.
- **Data flow** on the pipeline view (18 arrows, 9 marked sensitive); also on the AWS and agent views where data moves.
- **No API list.** No document defines an endpoint. The one written contract, the `intake.event/1` message, is in the Metadata queue's details.
- **Use cases:** 27 → 31 (new: a job's states; one agent run; an agent run stopped at its limit; one package's path through the networks). "What must never happen" grew from 5 to 10 steps.
- **Open items:** 58 → 69 (5 new risks, 6 new questions). Existing items now also point at the new boxes and, where it fits, at arrows.
- **Ledger:** 160 → 195 rows.
- **Found by the reach check and fixed before release:** one "VPC endpoints" box made the sandbox appear to reach S3 and the model; it is now two boxes with a blocked arrow between the sandbox and the data endpoints.
- **Left:** one check warning (the AWS view has no box to drill from). See `review-v3.md`.

## v2 — 2026-11-23

Rebuilt on the revised skill and template. No new source was read and no review round has happened, so the facts are the same; what changed is how honestly they are labelled and linked.

- **Two labels.** v1's single label (with an improvised `proposed` status) is replaced by status and stage. Page default stage is `proposed`; boxes that are decided, built, disputed or superseded say so.
- **Source ranking applied.** Owner decision > superseding document (own scope) > current design > independent review > inference. v1's 'disputed' tag meant 'the review disagrees'; that is now the tag `review`, and the stage `disputed` is kept for cases the ranking cannot settle (orchestrator, polling rate, one database, triage and fuzz versus 'one task type').
- **Blocked paths.** 5 new blocked arrows and a use case 'What must never happen'. These are the only parts flagged `changed` (5).
- **Open items.** Same 58; refs now span designs; all 20 conflicts carry positions, what is drawn and who decides; items link briefs and ledger rows.
- **Missing sources.** 9 cited-but-absent sources listed on the page.
- **Arrow evidence.** Facts added to 37 arrows (32 existing, 5 new blocked ones).
- **Layout.** Column pitch 340 on ten designs; manual line breaks and label positions removed; routing waypoints kept only where an arrow would otherwise cross a box.
- **Briefs.** Regrouped by who can answer: 14 to 12; status and numbered questions added.

## v1 — 2026-11-23

First draft: 13 designs, 26 use cases, 58 open items, 160 ledger rows, 14 briefs.
