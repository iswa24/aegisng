# Review of version 3 — Vera, Design Reviewer

2026-11-23. Reviewed: the page at v3 (16 designs, 31 use cases), read as the engineer who builds it, the operator paged at 3am, the security reviewer and the person who pays. Used the gaps, stage, blocked and sensitive-data lenses, stepped every use case through C0, C2, C3 and C4 (no amber steps), ran "Show what this can reach" on the agent and the sandbox, and ran the design check (0 problems, 1 warning).

No praise section. What is wrong, most serious first.

## Must change before this design is used for anything

1. **Nothing independent shows a reproducer ran.** *Scan agent view: Validator, Sandbox task, Write to the drop.* The agent drives the sandbox and writes the finding; the validator "re-verifies the reproducer hash". A hash shows the file did not change. It does not show the reproducer works. A package that steers the agent can get a well-formed finding with a dead reproducer through the one guard that is supposed to be outside the model. Settles it: the validator (or a separate fixed task) reruns the reproducer itself. Logged: **K19**, Security.
2. **Nobody knows whether the sandbox network has a route to prod.** *AWS view: Sandbox task → Prod account.* "No internet gateway, no NAT" and "UAT and prod share a flat network" are in the same section. Until the cloud team says how the Analysis VPC is attached, the only thing between hostile build scripts and prod is nono, which is unverified. Settles it: the answer to **Q23**, and the nono spike (brief R04).
3. **Two of the agent's three kill triggers cannot fire.** *Scan agent view: the limit guard.* No limit has a number and nothing meters tokens. A run that loops is stopped by a time limit nobody has set. Settles it: numbers for the limits and a metering point outside the agent. Logged: **K18**, SmartSDK owners.
4. **The design is ahead of its evidence, and getting further ahead.** 69 open items, none answered since version 1. Twelve briefs drafted, none sent. This round added three views and eleven items and answered nothing. That is not a fault on the page; it is the fault of the project. Settles it: the owner routes the briefs. R03 (owner), R10 (network and cloud) and R04 (nono) first.

Found in this review and already fixed before release: one "VPC endpoints" box on the AWS view made the sandbox appear able to reach S3 and the model through it. Skye split it into data and image endpoints with a blocked arrow. Checked: the sandbox's reach on that view is now the image and log endpoints and the unanswered route to prod.

## Should change

5. **`package_version` has four writers; the cleaner has no database role.** *Schema view.* A row stuck in "triaging" has no single owner. **K17**.
6. **First-party source and exploit detail go to the model in every prompt, and nothing says where the model's logs are kept.** *Scan agent view: Scan agent → Cyber model.* **K20**.
7. **The AWS view cannot be reached by drilling and does not roll up.** Its use case, "One package's path through the networks", looks the same at C0, C2 and C3. The page allows one child per box and the pipeline's box already opens its container view. This is the one check warning left. It needs a change to the page, or a decision to hang the view off an arbitrary box.
8. **Four use cases are too long to read as sequences** (21, 18, 16 and 15 steps). **K21**. Finn should split them.
9. **The use case diagram shows eleven "actors"; six are groupings** ("Failure paths", "Across systems", "Data lifecycle", "Inside the analysis", two "Input: …"). It reads as if "Failure paths" were a party to the system.
10. **"Show what this can reach" on the Scan agent lists Findings and the reviewer**, because it follows the finding on through the validator. A reader will take that as "the agent can reach the database". Aria put a line in the box's details; the tool should stop at a guard.
11. **Only 11 of the 17 inferred table references have a line.** The rest are in the column lists. Honest, and it says so on the view, but a reader will miss them.
12. **Frames carry no stage or status.** "One firm account" is decided, the two VPCs are proposed, the Region is unknown; on the AWS view that is in the label text only.

## Can wait

13. No C1 view per system. Maya's call; I agree.
14. No agent operating procedure (`design/aop/`) for the scan agent. There is no spec to write it from, only a design.
15. No requirement register. Same reason.
16. The "not in the first version" tag was not turned into the `deferred` stage. Fuzzing is disputed, not agreed-later, so the tag is still the honest form.
17. Devspace and the harness migration tool were not touched.

## Did the version do what the room agreed?

| Agreed in the room | In version 3 |
|---|---|
| Settle the ten level mismatches | Done: check reports none; I stepped all 31 use cases through four levels, no amber step |
| Rename levels to C0–C4, no C1 | Done |
| C4 schema, types blank, keys marked inferred | Done; question Q25, risk K17, question Q26 |
| No API list; message contract in the queue's details | Done; question Q28 |
| AWS view to VPC level only, no invented subnet | Done; no Region, subnet or zone frame; Q23, Q24 |
| Agent design with sees / blind, guards, stop path; no pentest agent | Done; K18, K19 |
| Rhea rules on status and stage; items for every gap | Done: 35 ledger rows, 11 items; nothing new is marked decided that the owner did not decide |
| Nothing recorded as decided | Confirmed: the change log, the notes and the items say "recommended" |

Still disputed after the round, unchanged: whether the AWS view should have been drawn before the cloud team answered (Skye, me); whether flowcharts belong in the level roll-up (Finn, Maya).
