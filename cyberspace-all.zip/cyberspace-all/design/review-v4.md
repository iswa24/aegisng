# Review of version 4

## Verdict in three lines
Not ready. The detail panels are honest; the faces mislead, and a leader reads only faces.
Her two key sentences do not show at a glance: self-service is one sub-label, and nothing frames "Cyberspace".
The lane chart is clean, but it sells a same-day prod lane that does not exist yet.

## Must change before the owner sees it
1. **A lane is sold that does not exist.** `lane/inside` says "same day". Today E028 applies and the fit check is a quarter of unbuilt work; only the details say so. Fix: the face reads "not open until the owner relaxes E028 and the fit check exists; until then lead plus SecOps".
2. **Self-service is invisible on the landscape.** `platform/team` has one arrow, "builds with Claude Code". Fix: relabel `team>build` "changes its own agents, tools, personas, runbooks"; `gate` sub "team alone for content; outside the team for reach"; restore the round 2 table (team alone / gate / never).
3. **Disputes do not show.** `platform/adhoc` renders amber; `hosts>build` and `build>uat` red. None reads as disputed, whatever X23 says. The model in `sandbox` rests on Q29, against an owner-decided rule (E001), yet is drawn plain. Fix: write "(disputed, X23)" into the labels; mark `sandbox>mgw` disputed, "rests on Q29".
4. **Arrows into prod say two things.** `build>prod` and `sandbox>prod` are solid arrows labelled "no ... route: unproven". Devspace reaches the prod proxy today (E013), so `build>prod` is open, not unproven. The centre has four crossings. Fix: label them "open today on Devspace: must close" and "not shown closed"; route `build>prod` along the bottom.
5. **"One way out" is not true as drawn.** The zone title and `rel` claim it. K01 says raw evidence shows in the access layer first (E033). Security asked for that arrow. `rel` has one exit, to `build`, so confirmed findings seem to reach the model's desk. Fix: draw `evid>ctl` unproven; add the disclosure exit and the findings reviewer; retitle "one way to the build side".
6. **`sandbox>exec` is drawn "cannot reach" on an agreement.** No mechanism exists; E109 does not say it. Fix: draw it unproven, "agreed rule, no mechanism", as Platform asked for `build>ctl`.
7. **"Inside Cyberspace" has no frame.** `mgw` floats outside every zone. Efforts are named only in details; round 2 promised labels. Fix: one outer frame "Cyberspace"; subs such as `sandbox` "today: code scan, pen-test agents".

## Should change
- R04 "covered" is not earned: no host, no sizes. Set partial. Add a requirement for the sandbox sentence (E197).
- `build` opens the Devspace design. That picks the host X25 leaves open. Link `hosts` instead.
- C3 and C7 read "settled". Agents ended on "persona is the envelope"; Security still wants the broker apart (K08). Log both as conflicts.
- Link K01, K02, K06, K08, K14, K20 and X02 to landscape boxes.
- The code store (Data asked) is absent and missing from the left-off note.
- `lane/envelope` runs straight to "Sign and publish": the change itself gets no approver, and no clock shows.
- "One working day" on `lane/secops` and `lane/tool` is one architect's ask.
- Tour steps 6 and 10 state unbuilt things as fact; so does `sspersona`.

## Can wait
- "Agreed by all five" on `sandbox>exec`: four said it; Data was silent.
- The legend has no entry for a red-bordered label. "Envelope" and "fit check" need plain words.

## What the landscape does well
Unproven lines are drawn unproven. Each conflict carries every architect's position and source. Nothing claims to be decided.

## Questions for the owner that the page does not yet ask
- What did "built on the initiative's own hub" mean?
- Is a persona a kind of user with a ready workspace, or a permission set? The room chose the second.
- "Their own things": does that include compute, models and network?
- Until the fit check exists, what self-service is enough?
- If the gate or control plane is down mid-incident, what may a responder do?
- Is an agent that reads first-party source "UAT only" for the same-day lane?
- What clock applies to a data grant and to a new envelope?
