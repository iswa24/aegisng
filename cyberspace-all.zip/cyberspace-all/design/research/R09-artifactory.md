Brief R09 — Artifactory: read access and usage data
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Artifactory team
Open items:    X13, Q11
Questions:     1. Can we have a read-only identity with query access to all local and cache repositories (AF-02)?
               2. Are download statistics enabled, and can our own fetches be excluded (AF-10, AF-11)?
               3. The repository list with each repository's type (AF-03).
               4. Does Artifactory proxy every ecosystem in scope (S-09)? One webhook for all repositories (AF-01)?
Why it matters: Declared a later, secondary source, but the version rule for PyPI and Maven already depends on its download counts, and the review would make it the whole scope.
What I know:   The firm uses Artifactory for all libraries; self-hosted. Full list: question-log.md section 6.
Where to look: Artifactory admins.
Answer format: Answer per question id.
Do not:        Never look up an internal package name on a public registry while testing. Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
