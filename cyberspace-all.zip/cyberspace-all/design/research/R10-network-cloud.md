Brief R10 — Network, proxy and cloud limits
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Network team and cloud team
Open items:    Q12, Q23, Q24
Questions:     1. Does intake traffic leave from the same address as the firm's builds and Artifactory (N-03)?
               2. Can each registry's hosts go on the proxy allowlist (N-01)? What throughput can it carry (N-02; 20 MB/s is assumed)?
               3. How does a Lambda authenticate to the proxy, is TLS inspected, any size or time limit per download (N-04, N-05)?
               4. Are Lambda MicroVMs approved and available in the firm's Region (D-23)?
               5. (added in v3) How is the Analysis VPC attached to the firm network? The design says 'no internet gateway, no NAT' and also 'UAT and prod share a flat network'. Is there a route from that VPC to prod (Q23)?
               6. (added in v3) Which Region? Which VPC holds the Aurora cluster and RDS Proxy, the core intake functions and the review UI's load balancer? Are subnets, Availability Zones and address ranges set (Q24)?
Why it matters: A registry that blocks the shared address also breaks the firm's builds. Throughput sets the 5 GB Lambda threshold.
What I know:   The owner says the network can be opened (D-07).
Where to look: question-log.md section 7.
Answer format: Answer per question id.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
