Brief R14 — Disclosure policy and registry terms
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Legal, with Security
Open items:    K09, Q14
Questions:     1. The disclosure policy: second sign-off, embargo length, escalation after silence (D-17).
               2. May owning teams be told about an embargoed finding in a library they use (D-18)?
               3. Does PyPI's Acceptable Use Policy allow the planned use (N-08)?
               4. Is there an agreement with Sonatype for Maven Central, and an arrangement with npm for backfill volume (N-06, N-07)?
Why it matters: The 90-day and 14-day figures in the design are placeholders, and Maven Central can block the firm's address for up to 30 days.
What I know:   Question log D-17, D-18, N-06 to N-08; companion D3, D4.
Where to look: Firm vulnerability disclosure policy; registry terms pages.
Answer format: Policy figures with reference; yes / no with conditions per registry.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
