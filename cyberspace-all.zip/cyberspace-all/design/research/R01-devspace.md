Brief R01 — Devspace: confirm the inferred design
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Devspace platform team
Open items:    K03, K12, Q05
Questions:     1. Can Devspace be held to UAT only (proxy and managed settings) for a group of users? Who decides?
               2. What does each workspace run on (shared-node pod, dedicated host, microVM), and is workspace-to-workspace traffic denied?
               3. Which identity reaches the 'target account', what does its trust policy require, and is it read-only?
               4. Where do model calls go, who owns the upstream credential, and how is use attributed to a person?
               5. Which audit trail exists: prompts, tool calls, terminal activity; where does it land?
Why it matters: Cyberspace's build plane assumes Devspace can be pinned to UAT, and Devspace runs Claude Code with permission prompts bypassed, so container and network are the only controls. All but four boxes on the Devspace design are guesses.
What I know:   Owner: Devspace runs Claude Code and a terminal in a remote container and connects through firm proxy prod and UAT to GitHub, Bitbucket, the firm's AWS account and a target account. One project document infers the rest from a screenshot.
Where to look: Devspace architecture page or runbook. Inside a workspace: /status in Claude Code; the managed-settings file; cgroup cpu.max; proxy and AWS environment variables; aws sts get-caller-identity. Full command list: enterprise-claude-code-sandbox-on-aws.md, 'Questions and commands'.
Answer format: Per inferred box: confirmed / wrong (with the correct fact) / not known, each with its source.
Do not:        Do not infer from the screenshot again. Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
