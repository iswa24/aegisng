Brief R13 — Evidence, sanitisation and approvals
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Security / SecOps, with Compliance
Open items:    X20, K01, K13, Q02, K19
Questions:     1. May an approver see unsanitised partial evidence at a pause state, and from which desktop?
               2. What must be redacted before prod evidence reaches the build plane; who owns the classifier; is it a model?
               3. Who approves prod runs, and do approvals live in the access layer or the firm's change system?
               4. Evidence retention period; is Object Lock compliance mode (irreversible) acceptable?
               5. (added in v3) What independent evidence must show that a reproducer ran before a finding is accepted? A hash check shows the file is unchanged, not that it works (K19).
Why it matters: The design's fourth rule makes sanitisation the only path back from prod; the pause-state approval queue looks like a second one.
What I know:   All listed as open decisions in the platform design §12 and the runner design §8.
Where to look: Data classification policy; change-management standard; records retention schedule.
Answer format: One decision per question with the policy reference.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
