Brief R05 — Model access: G35, the Model Route, cyber models
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      G35 account owners and the firm's model gateway team
Open items:    X10, X19, Q04, Q21, K20
Questions:     1. Is 'G35 Model Route', 'cyber models hosted in the same AWS account' and 'a Bedrock-hosted model' one endpoint or three? Who may call each today?
               2. How is each call attributed to a person, and what are the stated constraints on G35 model access?
               3. Is 'CyberSpace VDI' the existing AWS Workspaces in G35?
               4. Which AWS account hosts the scan pipeline: G35 or another?
               5. (added in v3) Prompts carry first-party source and exploit detail. Where are model invocation logs kept, who can read them, and does the model service retain anything (K20)?
Why it matters: Three systems depend on a model endpoint; the owner's notes say the team has no access to a cyber model and that G35 has attribution issues.
What I know:   Cyberops run Claude harnesses in AWS account G35 through AWS Workspaces. The platform design draws 'G35 Model Route (LLM gateway)'. Question log D-03 (cyber models, for now), D-19 open.
Where to look: G35 account owners; model gateway team; Bedrock model-access settings.
Answer format: A table: endpoint, account, models, who may call it, how identity is carried, logging, limits. Source per row.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
