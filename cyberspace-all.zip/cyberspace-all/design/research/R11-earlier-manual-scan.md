Brief R11 — The earlier 7-month manual scan
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Team that ran it
Open items:    X09, X18, Q13
Questions:     1. What did 'all' cover: registries, packages, versions, first-party code (M-04)? Is there a list of what was scanned, or a snapshot date (M-10)?
               2. Scans per day, people or workers, cost (M-08)? Where are the results, in what form (M-09)?
               3. Built and ran every library, or only read source (M-05)? Build failure rate by language (M-06)?
               4. Same cyber models and agent setup as planned now (M-07)? How was the code obtained (M-12)? What was painful (M-11)?
Why it matters: It is the only real evidence of yield, cost and throughput, and it sets where the incremental must start. The review's main objection is that the agent stage is unsized.
What I know:   A scale-up, not a pilot; one-time, manual, about 7 months; analysis of the issues is done.
Where to look: The team and its result store.
Answer format: Answer per question id, numbers where they exist, 'not measured' where not.
Do not:        Do not estimate.
Answer:        (none yet)
