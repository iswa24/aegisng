# Research briefs

One brief per team or source that can answer. Status values: drafted, sent, answered, closed.

| Brief | Topic | Route to | Questions | Open items | Status |
|---|---|---|---|---|---|
| [R01](R01-devspace.md) | Devspace: confirm the inferred design | Devspace platform team | 5 | K03, K12, Q05 | drafted |
| [R02](R02-smartsdk.md) | SmartSDK: what it is and what it can do | SmartSDK owners (the owner said she will research this herself); fastest route is to run the harness migration tool's SDK surveyor on the package | 6 | X01, K05, Q17, Q22, K18 | drafted |
| [R03](R03-owner-decisions.md) | Decisions and facts only the owner can give | Owner (architecture) | 12 | X02, X03, X04, X07, K02, K07, K14, Q01, Q03, Q06, Q07, Q08, Q15, Q19, Q25, K17, Q26, Q27, Q28 | drafted |
| [R04](R04-nono-spike.md) | Does nono block the network inside the sandbox? | Platform engineers (a pass/fail spike), with Security | 3 | K04, K06 | drafted |
| [R05](R05-model-access.md) | Model access: G35, the Model Route, cyber models | G35 account owners and the firm's model gateway team | 5 | X10, X19, Q04, Q21, K20 | drafted |
| [R07](R07-bitbucket.md) | Bitbucket: which detection option is allowed | Bitbucket team | 5 | X14, K11, Q10 | drafted |
| [R08](R08-github.md) | GitHub: hosting and access | GitHub team | 4 | Q09 | drafted |
| [R09](R09-artifactory.md) | Artifactory: read access and usage data | Artifactory team | 4 | X13, Q11 | drafted |
| [R10](R10-network-cloud.md) | Network, proxy and cloud limits | Network team and cloud team | 6 | Q12, Q23, Q24 | drafted |
| [R11](R11-earlier-manual-scan.md) | The earlier 7-month manual scan | Team that ran it | 4 | X09, X18, Q13 | drafted |
| [R13](R13-security.md) | Evidence, sanitisation and approvals | Security / SecOps, with Compliance | 5 | X20, K01, K13, Q02, K19 | drafted |
| [R14](R14-legal.md) | Disclosure policy and registry terms | Legal, with Security | 4 | K09, Q14 | drafted |

v1 briefs R06 (substrates and Kestra) and R12 (missing documents) were merged into R03, because the owner answers all three. Registry-terms questions moved from R10 to R14 (Legal).

v3: no new brief. Questions from the design party and the v3 review were added to R02, R03, R05, R10 and R13 (marked 'added in v3'). All twelve are still drafted; none has been sent.
