Brief R02 — SmartSDK: what it is and what it can do
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      SmartSDK owners (the owner said she will research this herself); fastest route is to run the harness migration tool's SDK surveyor on the package
Open items:    X01, K05, Q17, Q22, K18
Questions:     1. Does SmartSDK support custom tools, calling an external sandbox, and long-running sessions?
               2. How is a model invoked through it (IAM or a key), and where are tokens metered?
               3. Which Google ADK version does it pin; what does it forward, block and add?
               4. Is there, separately, any firm library for job specs, scope checks and evidence recording?
               5. Who owns SmartSDK and takes change requests?
               6. (added in v3) Where will token use be metered outside the agent, and what are the per-package limits (time, tokens, spend)? Until both exist, two of the run's kill triggers cannot fire (K18).
Why it matters: The scan agent, the pentest agent and every ported harness are designed on SmartSDK; the Cyberspace platform design uses the name for a different thing. Budget enforcement needs metering outside the agent.
What I know:   Owner: SmartSDK is the firm's wrapper around Google ADK; not all ADK features are available. The migration tool's SDK surveyor reads a package statically and has never been run on the real one.
Where to look: SmartSDK repository, release notes and owners.
Answer format: ADK version; a yes / no / partly table for each capability; model invocation path; metering point; owner. Source per row.
Do not:        Do not answer from Google ADK's public documentation: the wrapper hides part of it. Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
