Brief R08 — GitHub: hosting and access
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      GitHub team
Open items:    Q09
Questions:     1. github.com or Enterprise Server, and which version (GH-01)?
               2. If github.com: is a public webhook endpoint allowed (GH-02)?
               3. Can a GitHub App be installed on every organisation (GH-03)? Is audit log streaming to S3 with git events on (GH-04)?
               4. Any existing push-event feed (GH-05)?
Why it matters: If it is github.com it cannot reach a private receiver, which removes the webhook path.
What I know:   v0.3 says GitHub hosting is still to be confirmed. Full list: question-log.md section 5.
Where to look: GitHub owners.
Answer format: Answer per question id.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
