Brief R07 — Bitbucket: which detection option is allowed
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Bitbucket team
Open items:    X14, K11, Q10
Questions:     1. Do you already forward repository events anywhere (BB-02)?
               2. Is there a smart mirror reachable from AWS (BB-03)?
               3. Would you grant read access to push-log tables on a replica (BB-04), or approve a small plugin (BB-05)?
               4. Can we have a read-only service account with a rate-limit exemption, and which token type and rotation (BB-06, BB-12)?
               5. How many repositories exactly; how many personal, forks, dormant (BB-07, BB-08)? Version and Mesh (BB-01)?
Why it matters: Complete detection needs a plugin or push-log access, both owned by this team, while the owner wants to avoid depending on source teams.
What I know:   Bitbucket is Data Center inside the firm. '600K to 700K' is assumed to be the repository count. The rest of the list is question-log.md section 4.
Where to look: Bitbucket admins.
Answer format: Answer per question id, with date and who answered.
Do not:        Report only what a source or an accountable person states. Say 'not found' where applicable.
Answer:        (none yet)
