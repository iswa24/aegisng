Brief R04 — Does nono block the network inside the sandbox?
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Platform engineers (a pass/fail spike), with Security
Open items:    K04, K06
Questions:     1. Inside a Fargate task, does nono stop untrusted code from opening any connection: TCP, UDP, DNS, metadata endpoint?
               2. Can code inside the sandbox turn it off or get round it?
               3. With nono removed, what does the task's security group and routing alone still allow?
Why it matters: The sandbox runs hostile build scripts and the pentest agent runs model-written test code. UAT and prod share a flat network, so if nono does not hold, that code can reach the firm network.
What I know:   Marked unverified in three documents (v0.3 §8, companion D6, question log D-20). The review recommends a two-week spike and treating nono as a second layer.
Where to look: A test task in the analysis VPC; nono's own documentation.
Answer format: Pass or fail per attempt type, the nono version and configuration, and the test script.
Do not:        Do not rely on documentation alone; run it.
Answer:        (none yet)
