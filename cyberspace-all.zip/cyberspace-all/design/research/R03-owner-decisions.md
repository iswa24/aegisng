Brief R03 — Decisions and facts only the owner can give
Status:        drafted (not sent: no tool in this session reaches the firm; for the owner to route)
Route to:      Owner (architecture)
Open items:    X02, X03, X04, X07, K02, K07, K14, Q01, Q03, Q06, Q07, Q08, Q15, Q19, Q25, K17, Q26, Q27, Q28
Questions:     1. Which rule is the real one: no Claude at run time, or no model of any kind where prod credentials live? Under it, where may the scan agent, the pentest agent and a ported harness run, and must they pass the Cyberspace promotion gate?
               2. Does 'one ECS task type, S3 only' mean the agent never runs package code? Is read-everything, build-only-candidates acceptable (question log S-04, S-05)?
               3. Which orchestrator for Cyberspace: Kestra, Step Functions, or Kestra inside runners? Does a Kestra already exist in the firm? How would it reach a runner with no inbound ports?
               4. What are cosmos and portico (build-side, exec-side or both), and is G34 a range or real infrastructure?
               5. Must a job submission or approval in the access layer be a human action?
               6. Is the 'SAST sandbox' project the code scan pipeline? Should the delivery document be updated to the November platform design?
               7. Budget, worker cap and reviewer head count for the scan agent stage (S-02, S-03).
               8. Which ticket system and ownership source serve first-party findings? Which CI system runs the promotion gate?
               9. Can the missing documents be added: the walkthrough with options A to F, two whiteboards, six raw intake notes, the Cyberspace sketch, the use-case inventory and ccsec, any pentest-agent design?
               10. (added in v3) Schema: column types and keys are not written down. Are the inferred keys right, and does source_cursor (v0.4) replace adapter_cursor (Q25)? Who writes advisory_match, notification and agent_config, and who stores the reachability verdict (Q26)?
               11. (added in v3) package_version has four writers and the cleaner has no database role. Is that intended, and who owns a row stuck in a state (K17)?
               12. (added in v3) Is the drop router part of the analysis side or the findings side (Q27)? Is there any API spec for the access layer or the Bitbucket plugin (Q28)?
Why it matters: These decide what the execution plane is for, whether the scan and pentest agents belong inside Cyberspace, and they unblock 20 open items. Several conflicts are between the owner's own statements, so no document can settle them.
What I know:   Every position, with its source, is on the page under each conflict (X02, X04, X07, X08, X09, X12, X16).
Where to look: Owner's decision; firm policy on model use in production; earlier chats and whiteboards for this project.
Answer format: One line per question: the decision or fact, who decided, the date. For missing documents: the file, or a note that it no longer exists.
Do not:        Do not settle a policy question by picking the newest document.
Answer:        (none yet)
