# Design party notes

## 2026-11-23 — Level mismatches, and the missing AWS, agent and schema views: what should change, in what order, who does what
Room: design-studio   Mode: session (non-interactive; no person in the room)

Full exchange: `design/party-transcript.md`.

**Decided by (nobody):**
- Nothing. The owner was not in the room. Everything below is a recommendation.

**Recommended:**
- Settle the ten level mismatches before adding views. They have four causes (all seven back this):
  1. "One job, start to finish" hangs off Control plane but carries a persona box (*Lead / SecOps*) and a *Sanitise* box that the page reads as the platform view's boxes. Make its boxes lifecycle states, and tell the cross-container part of each job use case on the platform view. (Maya, Finn, Vera)
  2. Two arrows are missing from coarser views: Control plane → Runner VM and Promotion gate → G35 Model Route on the platform view; Harness migration tool → Model access on the whole picture. Add them; the two model arrows are `assumed`. (Maya, Aria, Rhea)
  3. "After a finding lands" answers two questions. Move the validator's keep-or-quarantine check onto the agent design; keep "Review and disclosure" as a flowchart hanging off Review UI. (Maya, Aria, Finn)
  4. Drop router has no stand-in on the pipeline view. Add Analysis → Validator there as the router's hand-off, `assumed`, tied to conflict X15; relabel drop → validator as a read. (Dara, Maya, Rhea)
- Rename levels L0/L2/L3 to C0/C2/C3. Do not add C1 views: the top view already carries each system's people and outside systems. (Maya)
- Add a C4 schema view for the catalog and findings tables, with types left blank and keys marked as inferred. It already has a finding: three writers on `package_version`, and no writer named for `advisory_match` and `notification`. (Dara, Vera, Rhea)
- Add no API list: no document defines an endpoint. Record the one message contract (`intake.event/1`) in the Metadata queue's details. (Dara)
- Add an AWS view of the code scan pipeline drawn to VPC level only: no Region frame, no subnets, no Availability Zones; anything that cannot be placed goes outside the VPC frames marked unknown. (Skye; Vera accepts on those terms)
- Add an agent design for the scan agent: what it sees, what it is blind to, fixed-rule guards, the stop path. No design for the pentest agent: there is no source. (Aria, Rhea)
- Order: (1) Maya + Finn: mismatches and level names; (2) Dara: schema, data flow; (3) Skye: AWS; (4) Aria: agent design; (5) Finn: use cases over the new views, once; Rhea rules on status and stage and logs items throughout; (6) Vera reviews; (7) Maya merges, bumps to version 3, checks.

**Still disputed:**
- Is an AWS view with no Region and no subnets worth drawing before the cloud team answers brief R10? **Skye:** yes, drawing the frames is what surfaced three placement questions nobody had asked. **Vera:** it risks looking finished; "should", not "must", and last. They agreed how to draw it, not whether now is the time. Decides: the owner.
- Should flowchart views take part in the level roll-up at all? **Finn:** no, a flowchart arrow is an order of states, not a call, so rolling it up produces false mismatches. **Maya:** that is a matter for the page engine, which the team does not change; work within it and report. Decides: whoever maintains the design kit.
- (Carried, not new) One ECS task type or three (X07); where just-in-time approvals live (X20).

**New questions:**
- How is the Analysis VPC attached to the firm network, given "no internet gateway, no NAT" and "UAT and prod share a flat network" in the same document? (cloud and network teams; brief R10)
- Which VPC holds the Aurora cluster and RDS Proxy, and where do the core intake functions and the review UI run? (owner; cloud team)
- Which Region? (cloud team)
- Column types, primary and foreign keys of the catalog and findings tables; does `source_cursor` (v0.4) replace `adapter_cursor` (companion)? (owner)
- Who writes `advisory_match`, `notification` and `agent_config`? (owner)
- Is the drop router part of the analysis side or the findings side? (owner; conflict X15)

**Actions:**
- Maya: rename levels to C0–C4; add the three missing arrows; re-hang the flowcharts; merge; version 3; check; look at every screenshot.
- Finn: rewrite the job use cases so the cross-container steps run on the platform view; rewrite the four finding use cases; write use cases over the agent design and the AWS view.
- Dara: C4 schema view; `data` on the pipeline view's arrows; the message contract in the queue's details; no API list.
- Skye: AWS view to VPC level with official icons, embedded with the kit's tool; blocked paths; every unplaced resource as a question.
- Aria: agent design with sees / blind, guards, the kill path, blocked paths; run "Show what this can reach".
- Rhea: ledger rows for every new fact; the new questions and risks as items; rule on status and stage; keep `open-items.md` and the page in step.
- Vera: review the result: must change, should change, can wait.
- Report to the design kit's maintainer: flowcharts in the roll-up; no notation for a message contract; one `child` per box leaves a whole-system AWS view with no box to drill from.

**"Shall the team do it?"** Taken as yes on the coordinator's instruction (not the owner's).

## 2026-11-24 — The Cyberspace platform landscape: one platform with capabilities, and what a cyber team may change by itself
Room: architecture-board (five architects: Platform, Security, Data, Agents, Cyberops; the lead design architect in the chair)   Mode: subagent, four rounds (non-interactive; no person in the room)

Full exchange: `party/brief.md`, `party/round1/`, `party/round2/maya-draft.md`, `party/round3/`, `party/round4-outcome.md`.

**Decided by: nobody (no person in the room).**
- Nothing. The owner was not in the room. Everything below is a recommendation and is drawn `proposed`.

**Recommended:**
- Draw Cyberspace as one platform with capabilities in four zones (Build, Govern, Run, Governed data), with today's efforts as boxes inside it, not as four systems. (all five)
- One rule for models: no model in compute that holds prod credentials; a model runs only in a sandbox with no prod credential and no proven route to prod. (all five; it rests on E015, still proposed, and the owner's own wording E001 is stricter)
- A UAT content change (instructions, skills, decision tables, rules, query packs) is live the same day on automated checks plus one team peer; nobody outside the team. (Platform, Security, Agents, Cyberops)
- Key the gate on reach, not on each change: Security reviews an envelope once; read-only changes inside it ship without SecOps. This relaxes E028. (Security, Platform, Cyberops; Data with a condition; Agents for fixed flows)
- Split persona in two: the envelope is Security's record of reach, with a data row only the data owner grants; a persona is a team's selection inside one envelope, catalogued, same day. (all five)
- Nothing un-ported runs in the agent sandbox or in execution; porting is the ticket to the sandbox, not to the platform. (Platform, Agents, Cyberops)
- No arrow from the agent sandbox to execution; no agent submits or approves a job. (all five)
- The entitlement record decides and the broker enforces; evidence and findings stores stay apart; released copies sit behind the release gate. (Data, Security, Platform)
- Draw sandbox to prod, sandbox to one UAT target, build to prod and UAT data to build as unproven, not blocked; two network profiles for the sandbox. (Security, Agents, Data, Platform)
- The build workspace is a platform-owned profile; its hosts (G35 Workspaces, Devspace) sit outside. (Platform, Security, Agents)
- Put a clock on every gate lane. (Platform, Cyberops)

**Still disputed:**
- Who signs a read-only change inside a prod-capable envelope. **Platform, Cyberops, Data:** a team peer (Data: only where the source enforces reach by dataset). **Security:** the lead. Decides: the owner, with Security. (X21)
- Who approves a new read-only tool. **Security, Platform:** gate plus a team peer in UAT. **Agents:** outside the team once, when a model gets it. **Cyberops:** always outside, within one working day. Decides: the owner, with Security. (X21)
- Where existing harnesses run until the wrapper is known. **Platform, Agents:** in build, against UAT. **Cyberops:** they stay in G35 as the named interim place, and the platform pays for the first port. Decides: the owner. (X22)
- A human-typed read-only query mid-investigation. **Platform:** a catalogued job type with a typed query. **Security:** inside a running job's allowlist, results through the release gate. **Cyberops:** the string goes to the data source, never to the runner as code. **Agents:** no free text a model may have written; an agent may only propose a catalogued runbook with parameters. Decides: the owner. (X23)
- What to do if the UAT replica holds real records. **Platform, Data:** tokenise at load by fixed rules. **Cyberops:** pass the release gate before build. **Security:** a replica holding real records is prod data. Decides: the owner, with the data owners. (X24)
- Which host carries the build workspace first. **Platform, Cyberops:** G35 Workspaces. **Security:** undecided; both hosts have a defect. Decides: the owner. (X25)

**New questions:**
- Does "no Claude at run time" (E001) cover the agent sandbox, or only compute with prod reach? (owner; Q29)
- May SecOps review an envelope once instead of each prod-capable change (E028)? (owner, Security; Q30)
- Does the UAT replica hold real prod records, and who owns the tokeniser? (owner, data owners; Q31)
- Which clocks will the gate commit to, and where is a prod job approved? (owner, Security; Q32)
- May the agent sandbox leave the flat network, and who owns the pen-test risk meanwhile? (network and cloud teams, Security; Q33)
- Who owns envelopes, who is the data owner for each source, and must an existing firm entitlement scheme be used? (owner; Q34)
- Who may compose a persona: any team member, or the lead? (owner; Q35)
- Must scan and pen-test agents pass the one gate? (owner; Q36)
- Is a team the tenant, and where does the team record (members, lead, quota) live? (owner; Q37)
- Where does the scan pipeline's intake sit: inside the platform or with the tenant? (owner; Q38)
- Is there one model gateway for build and sandbox, who owns the approved model list, and where are prompt logs kept? (G35 and model gateway owners; Q39)

**Actions:**
- Lead design architect: draw the landscape as the first design, the lane flowchart, the self-service use cases, the requirement and conflict items; version 4; check. Covers the flow, data and agent parts herself in this run and says so in the change log.
- Evidence: ledger rows for the owner's five statements of 24 Nov; proposals from the room are not evidence.
- Open items: X21 to X25, Q29 to Q39 and R01 to R10 added on the page and in `open-items.md`. No existing item closed or rewritten.

**"Shall the team do it?"** Taken as yes on the coordinator's instruction (not the owner's). Only design files changed.
