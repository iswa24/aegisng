---
program: Cyberspace
status: draft
owner: Owner (architecture), for the program's sponsor
updated: 2026-11-25
---

## North star
"A next generation operating environment for cyber: a secure, isolated, persona-configurable workspace, bringing together compute, governed data access, operational tooling and agent capabilities, so our teams can build, test, investigate, automate and respond without risking production." (The owner's definition, 24 Nov, dictated; wording approximate. Source: design/requirements.md and ledger E196.)

## Goals
| Id | Goal | Measure | Source |
|---|---|---|---|
| G1 | Work in Cyberspace is secure and isolated, and never risks production | Not set yet: the owner sets it (OD1) | design/requirements.md:9, design/requirements.md:10, design/requirements.md:17 |
| G2 | Each team gets a persona-configurable workspace with compute and governed data access | Not set yet: the owner sets it (OD1) | design/requirements.md:11, design/requirements.md:12, design/requirements.md:13 |
| G3 | Teams can build, test, investigate, automate and respond with operational tooling and agent capabilities | Not set yet: the owner sets it (OD1) | design/requirements.md:14, design/requirements.md:15, design/requirements.md:16 |
| G4 | Cyber teams can come in and modify their own agents | Not set yet: the owner sets it (OD1) | design/requirements.md:18 |
| G5 | The agent sandbox is one effort inside Cyberspace, not the whole thing | Not set yet: the owner sets it (OD1) | design/requirements.md:19 |

## Non-goals
| Id | Not doing | Why | Source |
|---|---|---|---|

## Decisions
| Id | Decision | Decided by | Date | Source |
|---|---|---|---|---|

## Open decisions
| Id | Question | Who decides | Needed by |
|---|---|---|---|
| OD1 | How will each goal be measured? | Owner | - |
| OD2 | In what order do the goals matter? (The order below is a proposal.) | Owner | - |
| OD3 | Will the firm relax the approval rule so teams can change their own agents (E028, R10)? | Owner, with Security | - |
| OD4 | Do the scan and pen-test agents share the agent sandbox and pass the same gate (K14, R11)? | Owner | - |
| OD5 | What should "built on the initiative's own hub" say? | Owner | - |

## Priorities
Proposed, not decided (OD2):
1. G1
2. G4
3. G3
4. G2
5. G5

## Guardrails
- Read every source in full before any work; the reading gate enforces it.
- Nothing undecided is written or drawn as decided. Everything on the landscape is proposed until the owner decides it.
- Every piece of work traces to a goal.
- No person's name in shared artefacts unless the owner asks.
