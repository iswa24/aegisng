# One prompt: install everything into BMad

Unzip `cyberspace-all.zip` somewhere in your project (for example `./cyberspace-all`). Open Claude Code in the project root, the folder that contains `_bmad/`, and paste the prompt below. It installs the design page engine, the design studio personas (including Theo), the design party and the tools, checks them, and moves your existing design pages to the new engine without changing their content.

```
Install the Design Studio from ./cyberspace-all/design-studio into this
project's BMad setup. Work carefully and report at the end. Stop and ask me
before deleting anything, and if any step fails.

1. Check: find _bmad/ and the folder where BMad's skills are installed
   (usually .claude/skills/). Tell me the BMad version. If it is older than
   6.13, stop and tell me.
2. Back up: copy any existing design-studio skills (design-kit, design-party,
   bmod-design, design-agent-*) from the skills folder to
   ./backup-design-studio-<date>/. Also back up every design page I have
   (files containing "1. DIAGRAM DATA") and any agentic/ folder.
3. Install: copy all seventeen folders from ./cyberspace-all/design-studio/skills/
   into the skills folder, replacing the old versions of these folders only.
   Do not touch any other skill. In every bmod.toml under those folders,
   replace YOUR-ORG with a file: source pointing at
   ./cyberspace-all/design-studio, unless I tell you a hosted repo.
4. Register: run the bmad skill with "setup design". If
   _bmad/scripts/validate_manifests.py exists, run it with
   --project-root ./cyberspace-all/design-studio and show me the result.
5. Party mode: if bmad-party-mode is installed, merge the entry in
   design-party/assets/architecture-board.toml into
   _bmad/custom/bmad-party-mode.toml (create it if needed; keep anything
   already there).
6. Prove it works:
   python3 <skills>/design-kit/check.py doctor
   python3 <skills>/design-kit/tests/run_tests.py   (must end "0 failed"; about 300 checks)
   python3 <skills>/design-kit/check.py <skills>/design-kit/template.html
   If playwright or a browser is missing, tell me exactly what to install.
7. Move my design pages to the new engine, one by one, from the backups made
   in step 2: python3 <skills>/design-kit/page.py upgrade <page>. Then run
   page.py structure <page> and check.py on each. Do not re-lay anything
   yet; just list which designs the structure check flags.
8. Theo's workspace: run python3 <skills>/design-kit/enable.py init agentic
   first-feature. Then ask me where the SmartSDK repo, the Claude Code
   harness, the requirements and the agent builders' knowledge are, and fill
   agentic/sources.json with my answers. Do not guess the paths.
9. Program and reading gate: copy ./cyberspace-all/program/charter.md to
   ./program/charter.md if I have no charter yet (it is a DRAFT for me to
   confirm). Show me the hooks in <skills>/design-kit/hooks/cyberspace-hooks.json
   (session briefing and reading gate), and ask me before merging them into
   .claude/settings.json; replace SKILLS with the real skills path. Then ask
   me which folders hold the sources everyone must read, and declare them
   with readgate.py init . cyberspace <folders>. Show me readgate.py plan.
10. Smoke test: list the personas BMad now knows (design studio: Maya, Rhea,
   Finn, Dara, Skye, Aria, Theo, Vera; Cyberspace squad: Uma, Noor, Hana,
   Ada, Iris, Kai; program lead: Sage), open design-party, show its rooms, and close it.

Report: BMad version, what was backed up and where, what was installed,
validator and test results, each page upgraded with its structure flags,
what you still need from me, and anything that failed.
```

## After it is installed

- **To re-lay your existing pages:** paste the prompt in `REDESIGN-PROMPT.md`.
- **For SmartSDK work with Theo:** paste the prompts in `THEO-SMARTSDK-PROMPT.md`.
- **For a whole feature with the Cyberspace squad:** paste the prompt in `SQUAD-PROMPT.md`.
- **To talk to the team:** ask for `design-party`, or one persona by name ("talk to Maya", "talk to Theo").
