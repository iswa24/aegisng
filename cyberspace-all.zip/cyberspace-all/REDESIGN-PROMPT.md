# Redesign an existing design page with the team

Use this when you already have a design page made with an older version of the design studio, and want every design on it laid out in a clear order: left to right, swimlanes for flows, phases on the use case diagram. Nothing the page says is changed.

## 1. Install this version

Replace the old `design-studio` folder (skills folder, or BMAD module) with this one. If it is a BMAD module, run your BMAD validator again. Then check it works on this machine:

```
python3 design-studio/skills/design-kit/check.py doctor
python3 design-studio/skills/design-kit/tests/run_tests.py
```

The first should find a browser; the second should end with "0 failed".

## 2. Back up your page and move it to the new engine

1. Copy your design page somewhere safe.
2. If you made changes inside the page, use the copy you saved from the page (Edit, then Save page), not the original file.
3. Run:

```
python3 design-studio/skills/design-kit/page.py upgrade your-design.html
```

This swaps in the new engine (zoom, swimlanes, the structure check) and does not touch your data. The page looks the same afterwards; the re-ordering is the team's job in step 3.

## 3. The prompt to give Claude Code

Paste this, with your file name in it:

```
Use the design studio (design-party skill, with Maya, Finn and Vera).
Page: <your-design.html>. Its content is in progress and not approved.

Job: give every design on this page a clear order, the way
design-kit/references/layout.md says. Do not change what the page says.

1. Run page.py structure on the page and list every design it flags
   or that has no "reads" line.
2. Maya: for each such design, write a layout plan (the ten moves in
   layout.md) and apply it with page.py arrange. Positions and reads
   only. One plan file per run.
3. Finn: turn every flow design into swimlanes with page.py lanes.
   Take each lane from the evidence in this page and my documents.
   If no source says who does a step, put it in a "Not stated" lane
   and raise a question naming whom to ask. Never guess an owner.
4. Finn: give the use cases phases (and "then" where one use case
   leads to the next) so the use case diagram reads left to right.
   Tell me the phases before applying them.
5. Run check.py with screenshots and look at every design you moved.
6. Vera: review the result without having seen the work. Apply her
   must-change fixes.
7. Report: design by design, what moved, what is left and why, and
   every new question. Keep the plan and lanes files.
```

If the page has agents on it, add this line to the prompt:

```
8. Theo: review every agentic part of the design (REVIEW action) and
   log what he finds as items on the page. Do not change the design.
```

## Things to watch for

- **The tools refuse content changes.** `arrange` and `lanes` will not save if a box, arrow or label would differ. If Claude says it "had to" edit the page by hand, stop it.
- **Use case phases are a judgement call.** That is why the prompt asks Finn to show them to you before applying.
- **"Not stated" lanes are deliberate.** They mark where your documents do not say who does a step. Do not let it fill them with a guess.
- **Keep the plan and lanes files.** If the result is wrong, go back to your backup and re-apply them, or fix just one.
