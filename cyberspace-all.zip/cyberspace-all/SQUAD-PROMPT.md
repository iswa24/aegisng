# Run the Cyberspace squad on a feature

The squad takes an agent feature from "someone wants this" to stories a developer, or a dev agent, can build on SmartSDK. The method and every hand-off are in `skills/design-kit/references/cyberspace-squad.md`. Each step has a check, and nothing is handed on while its check reports a problem.

| Persona | Step |
|---|---|
| 🧩 Uma | Use cases and granular needs, under BMad's PRD |
| 🧭 Noor | Every use case and edge case walked through the design |
| 🔧 Hana | What the Claude Code harness really does |
| 🏛️ Theo | What SmartSDK must provide: gaps, change requests, story seeds |
| 📜 Ada | Agent operating procedures (AOPs), in the firm's template and SmartSDK's form |
| 🧪 Iris | Evals in SmartSDK's own eval format |
| 🧱 Kai | Imagined runtime per use case, drawn by the design studio |

## Before the first feature

Have the sources in one working folder (see `THEO-SMARTSDK-PROMPT.md`): `smartsdk/`, `harness/`, `req/` (PRD and epics) and `playbook/` (what the firm's agent builders know). Build the firm playbook once with Theo's PLAYBOOK action.

## One prompt for a whole feature

```
Run the Cyberspace squad (design-party, room cyberspace-squad) on the
feature "<feature-name>". Sources: agentic-work/ (smartsdk/, harness/,
req/, playbook/). Design page: <page.html>. Follow
design-kit/references/cyberspace-squad.md. Run each step's check and do
not hand on while it reports problems. Give each persona its own agent
where you can.

0. Sage (GATE, then DIRECTION): make sure every source is declared in the
   reading gate and read in full by whoever works on it, before any work.
   Every persona logs its reading and passes readgate.py check first.
   Trace every use case to a goal in program/charter.md.
1. Uma (DEFINE): use cases and granular needs from req/. Ask me where the
   PRD is silent. Show me the use cases and needs before going on.
2. Hana (REVERSE): inventory and behaviours of harness/.
3. Theo (ENABLE): capabilities citing Uma's needs and Hana's constructs,
   gaps, change requests, story seeds. Nothing from the harness dropped
   without a reason.
4. Ada (AOP): what form SmartSDK expects, then the AOPs.
5. Kai (PROTOTYPE, DRAW): an imagined runtime per use case; Maya and Skye
   draw each as a proposed "Prototype" design on the page.
6. Noor (WALK): every use case and edge case through the design and the
   prototypes; put every gap and question on the page.
7. Iris (EVALS): eval sets in SmartSDK's format covering every AOP step,
   story criterion and high-severity edge case.
8. Theo (HANDOFF, then STORYCHECK): design brief to the designers, story
   seeds to the BMad Scrum Master, then check the stories that come back.
9. Vera: review the page and the squad's files without having seen the work.
10. Sage (DIRECTION): is all of it pointed at the charter's goals and
   priorities? What is waiting on the owner?

Report: squad.py status, blockers and change requests, the AOPs, eval
coverage and vetoes, the prototypes drawn, every gap and question with
whom to ask, and the proposed playbook rules.
```

## One persona at a time

Ask for any of them by name with an action, for example "Uma, DEFINE for the triage feature", "Hana, REVERSE harness/", "Iris, FORMAT" (how SmartSDK's eval works), "Kai, PROTOTYPE for UC03". `python3 <skills>/design-kit/squad.py status agentic <feature>` shows who is next.

## Things to watch for

- **Uma works under the PRD.** She asks the product manager about anything unclear rather than deciding it.
- **Ada and Iris read SmartSDK's source first** to learn what it expects (procedure format, eval format) and cite it. If they say "SmartSDK expects..." without a citation, stop them.
- **Kai's prototypes are imagined.** They are drawn as proposed, every number is an estimate, and every assumption is a question.
- **Noor writes scenarios, not attack steps.** Gaps go onto the design page beside the boxes they concern.
