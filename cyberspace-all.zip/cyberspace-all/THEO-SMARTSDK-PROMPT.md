# Enable a feature on SmartSDK with Theo

Theo (`design-agent-theo`) is the firm's SmartSDK specialist. He reads the SmartSDK repo, the Claude Code harness and the requirements as source, and learns from what the firm's agent builders have written and built. He works out exactly what must change before a feature can run, in our code or in SmartSDK. Then he hands the designers and the story-writing agents the depth they need for buildable stories. His method is `skills/design-kit/references/smartsdk-enablement.md`.

## 1. Put the sources where Theo can read them

Use one working folder, for example:

```
agentic-work/
  smartsdk/        a checkout of the SmartSDK repo (or the unpacked package)
  harness/         the Claude Code harness (CLAUDE.md, .claude/, .mcp.json, scripts)
  req/             the requirements: PRD, spec, epics, the feature request
  playbook/        what the firm's agent builders know: SmartSDK guides, approved patterns,
                   reference agents built on SmartSDK, review notes, incident write-ups
```

Theo reads all of these as text. He never imports, installs or runs SmartSDK or the harness, and never loads the harness as live configuration. Run him in the build plane, without production credentials.

## 2. First time only: build the firm playbook

```
Use Theo (design-agent-theo), action PLAYBOOK.
Sources: agentic-work/ (smartsdk/, harness/, req/, playbook/).
Create agentic-work/agentic with enable.py init if it does not exist, fill
sources.json, then read everything in playbook/ and write the firm's rules
into playbook.json as confirmed rules, each with its citation.
Tell me where firm practice differs from the generic patterns guide.
```

## 3. For each feature

```
Use Theo (design-agent-theo), action ENABLE, for the feature "<feature-name>".
Sources: agentic-work/ (smartsdk/, harness/, req/, playbook/).
Requirement: req/<file>. Harness to port, if any: harness/.

Follow smartsdk-enablement.md:
1. Record SmartSDK's version and the ADK version it pins, and check the
   latest ADK. Say the date you checked.
2. Capabilities from the requirement, each cited. For each: how the harness
   does it today, the ADK primitive, and what SmartSDK exposes, read from its
   source and cited with the quote. Never mark something exposed because
   ADK has it.
3. Gaps on the least-machinery ladder, with a decision or a question and
   whom to ask. A change request for everything SmartSDK must change,
   written in SmartSDK's own style.
4. Story seeds with the SmartSDK APIs to use, what they replace in the
   harness, given/when/then criteria, tests, guardrails, dependencies on
   change requests, each small enough for one agent session.
5. The design brief for Maya, Aria and Finn.
6. enable.py check must report no problems; then enable.py render.

Report: blockers first, the change requests, the stories, the unknowns
with whom to ask, and the proposed playbook rules this feature taught.
```

## 4. Hand over

```
Theo, action HANDOFF: give the design brief to Maya, Aria and Finn to draw
on the design page, and give the rendered stories to the story-writing agent
(bmad-create-story or the Scrum Master). It must keep every Dev Notes line,
citation, guardrail and dependency, and add to them, never replace them.
Then Theo, action STORYCHECK, on the stories it wrote.
```

## What you get

- `agentic/<feature>/handoff/enablement-report.md`: the capability matrix, gaps, change requests, stories and unknowns.
- `agentic/<feature>/change-requests/`: what to take to the SmartSDK owners, most severe first.
- `agentic/<feature>/handoff/stories/`: one story file per story (BMad format), with the cited SmartSDK APIs, firm rules, guardrails and tests in Dev Notes.
- `agentic/<feature>/handoff/design-brief.md`: for the design page.
- New proposed rules in `agentic/playbook.json`: take them to the agent builders to confirm.

## Things to watch for

- **Unsupported claims are refused.** Every claim about SmartSDK cites a file, a line and the quoted words, and `enable.py check` opens the file to confirm. If Theo cannot cite it, the status is "unknown" with a question.
- **Stories are tied to SmartSDK's limits.** A story that needs a missing SmartSDK change is blocked by its change request, so nobody schedules it early.
- **Proposed playbook rules are not firm practice** until your agent builders confirm them.
- **Change requests are proposals** for the SmartSDK owners. Nothing in SmartSDK changes because Theo wrote one.
