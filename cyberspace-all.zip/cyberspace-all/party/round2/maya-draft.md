# Round 2 draft: the Cyberspace landscape

Nothing here is a decision. [doc: id]: ledger row or open item. [notes]: owner statement, no ledger row yet.

## What all five agree on
- No model beside prod credentials [doc: E015]. Still proposed; the owner's wording is stricter [doc: E001, X02].
- Three workspaces: build (Claude Code, UAT only), execution (no model), agent sandbox (no prod credentials) [proposal; E020, E038, E106].
- One agent sandbox shared by scan and pen-test [proposal; E007].
- Teams change their own content in UAT without a platform engineer [proposal]. Prod-capable personas and write tools need lead plus SecOps [doc: E028].
- No shell in execution [doc: E016]. Nobody approves their own change; a data owner grants data [proposal].
- Only sanitised evidence reaches build [doc: E017]. Recording, stop and metering sit outside the workload [doc: E044, E192, E123].

## Draft landscape

**People and outside systems.** Cyber teams; lead and SecOps approvers [doc: E028]; data owners [proposal]; findings reviewers [doc: E119]. Outside: prod and UAT targets on one flat network [doc: E012]; firm and public repositories [doc: E100]; the model service [doc: E130]; Devspace, G35 Workspaces [doc: E013, E002]; maintainers [doc: E111].

**The platform's capabilities.**

*Build*
1. Build workspace [doc: E018, E020]. Platform/Security/Agents/Cyberops.
2. Team repos and scaffold [doc: E021]. Platform/Agents.

*Govern*
3. Promotion gate [doc: E027, E124; one gate: proposal]. Platform/Security/Agents.
4. Catalogue: signed components and agent configurations [doc: E029; agents: proposal]. Platform/Security/Agents.
5. Personas and entitlements [proposal; E049]. Security/Data/Platform. Disputed (C3, C7).
6. Access layer and control plane: jobs, approvals, kill, per-run credentials [doc: E032, E034, E115]. Platform/Security/Agents.
7. Model gateway and meter [doc: E023, E123]. Platform/Security/Agents.

*Run*
8. Execution [doc: E038]. All five.
9. Agent sandbox [doc: E106, disputed X07]. Platform/Security/Agents/Cyberops.
10. Outside guards: scope guard, recorder, stop [doc: E056, E192]. Security/Agents.

*Governed data*
11. Raw stores with checked intake: evidence, code, findings drop [doc: E044, E109]. Data/Agents.
12. Release gate: sanitise, human release [doc: E046, E111; unifying: proposal]. Data.
13. Working store and findings store, apart [doc: E024, E158]. Data.

**Main arrows.**
1. Build -> Repos -> Gate -> Catalogue: edits, pull request, signed version [doc: E029].
2. People -> Access layer: job, approval, kill [doc: E032]. A model -> Access layer: BLOCKED [proposal; K02].
3. Catalogue, Personas -> Control plane: signed artifact, job scope [doc: E030, E049].
4. Control plane -> Execution, Sandbox: launch, per-run credentials, stop [doc: E041, E115].
5. Execution -> Prod targets: scoped calls via proxy [doc: E043].
6. Build, Sandbox -> Model gateway: metered prompts [doc: E023, E116; one gateway: proposal].
7. Execution, Sandbox -> Raw stores: evidence; findings, write-only [doc: E044, E109].
8. Findings store -> Release gate -> Maintainers: confirmed open-source findings [doc: E110, E111].
9. UNPROVEN: Raw stores -> Release gate -> Build: sanitised copy; rules unset [doc: E017, E047].
10. UNPROVEN: Sandbox -> one UAT target: pinned egress on a flat network [doc: E011, E012].
11. UNPROVEN: Sandbox -> Prod targets [doc: E187].
12. BLOCKED: Execution -> Model gateway [doc: E023].
13. BLOCKED: Build -> Prod targets, Execution [doc: E020, E016].

**Where the existing efforts sit** [proposal].
- Execution platform: boxes 3, 4, 6, 8, 10.
- Code scan pipeline: a tenant; sandbox is box 9, findings in 11 to 13, intake its own.
- Pen-test agent: box 9, egress pinned to one target [doc: E011].
- Harness migration tool: build zone; reads, never executes [doc: E069]. Disputed (C4).
- Devspace: outside, another team's product [doc: K03]. Disputed (C9).

**Self-service, merged.** Unmarked cells are [proposal].

| Changed | Team alone | Gate (approver) | Never |
|---|---|---|---|
| Prompt, query pack, rule, runbook | UAT, team peer (C1) | Prod-capable: lead plus SecOps [doc: E028] (C2) | Uncatalogued [doc: E030] |
| Tool | From catalogue | New: disputed (C2) | |
| Model, limits | Approved list; under team cap | Beyond either: outside the team | Beside prod credentials [doc: E015] |
| Persona | Narrow | New or wider: disputed (C3) | |
| Data access | Shorten own retention | Entitlement: data owner | Raw evidence to build [doc: E017] |
| Network, gate checks, guards, evidence | | | Always |

## Use case families against the landscape
1. **Build:** 1 to 4.
2. **Run:** 4 to 6, 8, 10, 11. Prod approval's place is undecided [doc: E162].
3. **Investigate:** 6, 13 to read. The follow-up query has no home (C5).
4. **Scan:** 6, 7, 9 to 13. Intake has no platform home [proposal].
5. **Migrate:** 1, 2. No run-time landing until C4.
6. **Failure, data lifecycle:** 6, 10 to 13. Retention is unset [doc: E045].
7. **Self-service:** 2 to 5. No use case; persona and data access have no agreed home (C3, C7).

## Points of conflict

**C1. Does a person approve a prompt change, and how fast is it live?**
- Agents: "A regression set decides, not a person."
- Platform, Security, Cyberops: a team peer too. Platform: "in days". Cyberops: "same day" [notes: weeks against a quarter].
- Drawing: a person and a time on the gate's content lane.
- Agents: what evaluates a detection rule, when E124 covers scan only? Platform: what takes days?

**C2. What sends a change outside the team: each prod-capable change, or the envelope?**
- Platform, Data: each change [doc: E028].
- Security: SecOps reviews "an envelope once"; yet any new tool goes outside. Agents: a new tool only "passes the gate". Cyberops wants "a threshold change without re-promotion".
- Drawing: what the gate's lanes are keyed on.
- Platform, Data: may a read-only prod runbook inside an approved envelope ship on a team peer? Security, Agents: who approves a new read-only UAT tool?

**C3. What is a persona, and who creates one?**
- Security: a "reach envelope"; "Security owns envelopes". Data: "a data scope first, an image second".
- Cyberops: "built from approved tools and UAT targets", same day. Platform: a "new or wider persona" passes a gate. Agents: silent.
- Drawing: persona in box 4 [doc: E022] or box 5, and whose.
- All four: name one owner and one home.

**C4. Must a harness be ported before it runs here?**
- Agents: "one agent configuration on the ADK wrapper". Platform: "on the firm's stack".
- Cyberops: "Take our harnesses as they are"; the wrapper is unknown [doc: E010, E131].
- Drawing: one run-time stack in box 9 or two.
- Cyberops: how does an as-is harness meet E001? Agents, Platform: what runs until the wrapper is known?

**C5. Does anything reach execution except a human submitting a catalogued job?**
- Security: never "let a model submit or approve". Platform: "humans only", yet from the workspace holding Claude Code [doc: K02].
- Agents: "Only data crosses, through a fixed-rule check." Cyberops: "Our harnesses are agent loops"; "investigation is not a form".
- Drawing: an arrow from box 9 to box 8, a free-text path, or neither.
- Agents: which data, which direction? Security, Platform: is a read-only ad hoc query inside a persona allowlist acceptable?

**C6. May a model read UAT replica data?**
- Data: "treat as prod", and never "unsanitised prod data to a model". Cyberops, Platform, Security build with Claude Code on it [doc: E020, E024].
- Drawing: UAT data -> Build direct, or through the release gate.
- Data: if the replica holds real records, is the build zone closed?

**C7. How much data governance sits on the top view?**
- Data: eight boxes, with a register and a lineage log; stores "apart" [doc: E158].
- Platform: entitlements "as short-lived credentials". Platform, Security: one evidence-and-findings box.
- Drawing: three data boxes plus box 5, or one store and one broker.
- Platform, Security: is the entitlement record the credential broker? Data: which three boxes carry the top view?

**C8. Is sandbox isolation blocked or unproven?**
- Agents: "Blocked: Cell -> Prod targets". Security: "UNPROVEN"; wants "no attachment to the firm network".
- Drawing: arrow 11 blocked or unproven; one network profile for box 9 or two.
- Security: how does a detached VPC reach the pen-test target? Agents: what evidence earns "blocked"?

**C9. Where does Claude Code live?**
- Agents: "Workbench: Devspace". Security: Devspace is "outside the trust boundary". Cyberops: "We are on G35 Workspaces".
- Drawing: Devspace inside box 1 or outside.
- Security, Platform: what hosts box 1 if not Devspace [doc: E020]? Cyberops: is G35 the first build workspace?

**Predictions checked.**
- Platform: both wrong. Security frees prompts; Agents' registry holds runbooks too.
- Security, Agents: nobody called an account or nono a boundary, or put harnesses on runners.
- Data: "image plus tools" fits Cyberops; logs "as plumbing" fits Platform.
- Agents: "every prompt change to an approver" is half right; the approver is a team peer.
- Cyberops: "pull request to the platform team" is wrong for content, true for images; "entry ticket" is right.

## What I will draw if nobody objects
- One top view: four zones, thirteen boxes. Existing efforts become labels over boxes, not systems.
- Everything stays proposed; box 5, box 12 and arrows 9 to 11 show as disputed or unproven.
- A self-service use case family, after round 3.
