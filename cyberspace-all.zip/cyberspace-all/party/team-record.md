# Team run: give every design a clear order (24–25 Nov)

First job under the "structure first" rules. Positions, lanes and reading lines only; every box, arrow and label unchanged
(the tools refuse to save otherwise).

| Member | Designs | Result |
|---|---|---|
| Maya | Cyberspace platform, Promotion gate, Runner VM, Devspace | Platform re-laid in two rows (build, run); the other three already read from the left and got reading lines |
| Maya | Code scan pipeline, Intake, Analysis, Scan agent, Harness migration tool | All re-laid; main path on one row each |
| Maya (cloud) | Code scan pipeline in AWS, Where a model runs | AWS turned round (traffic enters at the left); models as one row per place |
| Finn | A change's path, One job state by state | Swimlanes |
| Finn | Review and disclosure, How the platforms get built | Swimlanes |
| Vera | Whole page | Ready with fixes: six must-change findings, all applied |

Vera's fixes: disclosure and ticket moved to the Code scan pipeline lane (sources say the pipeline produces them); Record and
Kill treated alike (both Not stated, one question); pause approval question tied to the open approvals conflict; delivery lanes
reordered and a question raised on who pushes the branch; the change-path lanes marked as following the 24 Nov proposal; the
schema given a reading line; questions Q40–Q44 carry evidence ids.

New questions: Q40 who records and kills a closing job; Q41 who stops a job early; Q42 who decides a pause; Q43 who sends and owns
a disclosure; Q44 who pushes the branch.

Files: maya-a/plan.json, maya-b/plan.json, maya-c/plan.json, final/schema-plan.json, final/lanes.json, applied in that order to base.html.
