# Cyberspace platform landscape: the design party record

24 November 2026. Five architects and the design team. The owner was not in the room: **nothing here is a decision**. Each architect was a separate agent and wrote round 1 without seeing the others. Marks: [doc: id] is a fact from the project documents (id is a row in the evidence ledger, or K/Q/X for an open item); [proposal] is the architect's own.


---


# The brief the room was given


Date: 2026-11-24. Room: architecture board (five architects with the design team). The owner is not in the room, so **nothing decided here is a decision**. Everything the room produces is a recommendation for the owner.

### What the owner asked for

Her words were dictated, so a few are uncertain; this is the cleaned reading, with the uncertain words marked.

> Cyberspace is a next-generation operating environment for cyber: a **secure, isolated, persona-configurable workspace** that brings together **compute, governed data access, operational tooling and agent capabilities**, so our teams can **build, test, investigate, automate and respond without risking production**.
>
> This is the engineering-facing program design, built on the initiative's own hub *(uncertain wording: "initiative own hub")*. **The agent sandbox is an engineering effort inside Cyberspace, not the whole thing.**
>
> We should build **platform capabilities** such that the cyber teams themselves can come in and **modify their agents, modify their own things**. The platform should be built in that fashion.
>
> Bring in multiple architect agents, let them talk with the design agent, and come up with the **system landscape design: how this system should be**. Base it on all the use cases.

So the output is a **system landscape** (the top of the design: the platform, its capabilities, who uses them, what it connects to, and where the existing engineering efforts sit inside it), drawn by the design team.

### The shift this asks for

The design so far (see below) is drawn as four separate systems: the Cyberspace execution platform, the code scan pipeline, the harness migration tool and Devspace. The owner is now saying:

1. Cyberspace is **one platform with capabilities**, and those systems are efforts inside it or users of it.
2. Cyber teams must be able to **serve themselves**: change their agents, personas, tools, runbooks and data access without a platform engineer doing it for them.

### Tensions the room must argue, not smooth over

These come from the owner's own statements and the project documents (ids are rows in `design/evidence-ledger.md`).

- **Self-service versus control.** The platform design says cyberops never get an interactive session into the execution platform (E016) and the platform cannot offer a "vibe coding" experience (E006). The owner now wants cyber teams to modify their own agents. What exactly can a cyber team change by itself, what goes through a gate, and what can it never do?
- **Speed.** Cyberops ship in weeks; the platform team follows the firm's delivery process and takes about a quarter. A platform that makes cyber teams wait a quarter will be bypassed.
- **Models at run time.** The platform design says no model runs in compute holding prod credentials (E015). The code scan pipeline and the pen-test agent run an agent with a model at run time, in an isolated account. Both live "inside Cyberspace". What is the rule that makes both true?
- **Two agent stacks.** The firm's direction is Google ADK through its own wrapper, SmartSDK (E004, E008). Cyberops build with Claude Code and have ten months of harnesses built that way (E002). What does "modify their agents" mean when build-time and run-time stacks differ?
- **Network.** UAT and prod share one flat network (E012). "Isolated" and "without risking production" have to be earned by design, not assumed.
- **Governed data access** is in the definition and almost absent from the documents.
- **Persona-configurable workspace** is in the definition; the documents have a persona desktop and persona runner images, but no model of who configures a persona and how.

### What is on disk (read what your role needs)

- `party/current-design-summary.txt` — the current design: 16 designs, 31 use cases. Start here.
- `design/evidence-ledger.md` — 195 facts taken from the ten project documents and the owner's notes, each with its source, how sure it is, and how far along it is. This is the room's evidence. Search it; do not read it end to end unless you need to.
- `design/open-items.md` — 69 open conflicts, risks and questions on the current design.
- `design/review-v3.md` — the last design review.
- `design/cyberspace-design.html` — the interactive design page (large; use `python3 .claude/skills/design-kit/page.py summary design/cyberspace-design.html --items` to see what is on it).
- The ten source documents live in a claude.ai Project. If you have a Projects tool you may read them (**read only**: never write or delete there). If you do not, the ledger is your source.

### Use cases the landscape must serve

All 31 in the summary, which fall into these families:

1. **Build**: a cyber team builds a component or agent and gets it approved.
2. **Run**: a job runs against a real environment with approval, recording and a kill switch.
3. **Investigate**: the team reads evidence and decides the next step.
4. **Scan**: new library versions and pushes to firm repositories are fetched and analysed by an agent in a sandbox; findings are reviewed and disclosed.
5. **Migrate**: existing Claude Code harnesses are analysed for the move to the firm's agent stack.
6. **Failure paths and data lifecycle**: stopped jobs, budget limits, refused calls, life of evidence.

And the new family the owner just named, which no use case covers yet:

7. **Self-service**: a cyber team changes its own agent, persona, tool, runbook or data access.

### Rules for everything you write

- Mark every claim as **[doc]** (give the ledger id) or **[proposal]** (yours). Never present a proposal as something the documents say.
- No person names. No new firm-internal names beyond those already in the ledger.
- Write plainly, in short sentences. No padding.
- Disagree where you disagree. The owner wants the argument, not a blend.


---

# Round 1: five positions, written alone


## Platform architect

E = ledger row. K = open item.

### Position in one paragraph

Cyberspace is one platform: a control plane, a catalogue and three isolated workspace classes [proposal]. Self-service means a team changes components in its own repo and an automated gate publishes them, with no platform engineer in the path [proposal]. It never means a shell in execution [doc: E016]. The speed gap [brief] closes by splitting content from capability: content ships in days through the gate, capability on the firm's quarter [proposal]. Teams edit an agent's definition; the platform runs it on the firm's stack [proposal; E004]. A content change needing a platform ticket is a platform defect [proposal].

### Platform capabilities I insist on

1. **Control plane API.** Jobs, approvals, kill. Every team and pipeline calls it. [doc: E034]
2. **Component catalogue.** One signed catalogue for everything runnable [doc: E029, E030], agent configurations included [proposal]. Teams publish; the control plane reads.
3. **One risk-tiered gate.** Automated checks; extra humans only for prod-capable or write changes [doc: E027, E028]. Replaces three separate paths [doc: K14] [proposal].
4. **Golden-path scaffold.** A working component repo in minutes, for cyber teams [doc: E021].
5. **Workspace classes.** Build, execution, agent sandbox: platform-owned profiles of network, credentials and whether a model is allowed [proposal; E038, E106].
6. **Data access grants.** Per-team, per-persona entitlements as short-lived credentials [proposal; E041, E115].
7. **Model route with metering.** Team budgets, measured outside the agent [doc: E023, E123].
8. **Evidence and kill.** On every run [doc: E044, E053].

### Self-service: what a cyber team changes alone, what goes through a gate, what it can never do

**Alone** (automatic gate; an engineer approves [doc: E028], the team's own [proposal]):
- A UAT-only prompt, runbook, query pack, detection rule, decision table or read-only tool.
- Narrowing a persona; an approved-list model; budgets inside quota [proposal].
- UAT jobs [doc: E050].

**Through a gate:**
- Anything prod-capable or with a write tool: lead plus SecOps [doc: E028].
- A run-time agent's prompt, model or toolchain: regression set [doc: E124].
- A new or wider persona [proposal].
- A new data entitlement: the data owner approves [proposal].
- Each prod job [doc: E050].

**Never:**
- A shell in execution [doc: E016].
- A model beside prod credentials [doc: E015].
- Launching anything uncatalogued [doc: E030]; editing evidence [doc: E017].
- Changing network rules, gate checks or the scope guard; approving its own promotion [proposal].

### Boxes I want on the landscape

1. Team build workspace: persona desktop, Claude Code, UAT only [doc: E018, E020].
2. Team component repos [doc: E021].
3. Promotion gate [doc: E027].
4. Component catalogue [doc: E029].
5. Control plane and portal [doc: E032, E034].
6. Execution workspaces: no model [doc: E038].
7. Agent sandboxes: model, no prod credentials [doc: E106].
8. Data access broker [proposal].
9. Model route and meter [doc: E023].
10. Evidence and findings, behind sanitisation [doc: E044, E046].

- 1 -> 2 -> 3 -> 4: component change, pull request, signed version.
- 1 -> 5: job requests, approvals, kill; humans only [doc: K02].
- 5 -> 6, 7: launch with per-run credentials.
- 8 -> 6, 7: scoped data credentials.
- 1, 7 -> 9: metered model calls; never from 6.
- 6, 7 -> 10 -> 1: evidence, then the sanitised copy.

### Where the existing efforts sit

- Execution platform: the platform core, boxes 3 to 6 [proposal].
- Code scan pipeline: a tenant product. Its sandbox becomes box 7, shared with the pen-test agent [proposal; E007].
- Harness migration tool: an onboarding service in box 1 [doc: E069].
- Devspace: another team's product [doc: K03].

### Two things I expect the other architects to get wrong

1. Security will put a human on every change. That is a ticket queue; teams return to G35 [doc: E002].
2. Someone will give agents their own gate and catalogue: the platform built twice [doc: K14].

### Questions only the owner can answer

1. Is the tenant a cyber team, whose lead approves UAT-only changes?
2. Must scan and pen-test agents pass the same gate [doc: K14]?
3. Who approves a data entitlement?
4. Acceptable gate turnaround for a prompt change: hours or days?


## Security architect

### Position in one paragraph
Three zones, one rule: **a model and prod reach never share a compute boundary** [proposal]. That makes both efforts legitimate. The execution zone holds prod credentials and runs no model [doc: E015, E023]. The agent zone runs a model on hostile input [doc: E106] and must have no credential or route to prod [proposal]. The build zone has Claude Code and UAT only [doc: E020]. Teams own content inside an envelope; widening it needs someone outside the team [proposal]. "Isolated" is not earned yet: the agent zone's route to prod is unknown [doc: E187].

### Platform capabilities I insist on
1. **Per-run credential broker.** Short-lived, tagged credentials; runners and agents. [doc: E041, E115; one broker: proposal]
2. **One gate, one signed catalog.** Unsigned artifacts never run; every team. [doc: E027, E030; all agents: proposal]
3. **Persona envelope registry.** Persona = reach envelope: targets, tools, data, models, limits. Security owns envelopes; teams compose inside. [proposal, on E022, E043]
4. **Guards outside the workload.** Scope guard, recorder, kill, budgets; every job. [doc: E056, E032, E192]
5. **Agent zone.** Agent plus sandbox, fixed tools, write-only output through a validator; scan, pen-test, ported harnesses. [doc: E106, E109, E190; shared: proposal]
6. **Metered model gateway.** Metering outside the agent; logs classed as findings. [doc: E123, E178; single gateway: proposal]
7. **Evidence, sanitisation, entitlements.** Immutable evidence, sanitised analyst copy [doc: E017, E046]. Entitlement = persona × dataset, time-bound, logged [proposal].

### Self-service: what a cyber team changes alone, what goes through a gate, what it can never do
**Alone** (automated gate plus a team peer, no platform engineer) [proposal, extends E028]:
- Prompts, skills, decision tables. A prompt is not a control when tools and credentials are fixed outside it [doc: E190, E116]; regression runs automatically [doc: E124].
- Runbooks from catalogued tasks [doc: E035], query packs, detection rules.
- UAT-only components [doc: E028].
- A model from the approved list.

**Through a gate** (people outside the team):
- New tool, write tool, prod-capable persona: lead plus SecOps [doc: E028].
- Data entitlement, new model, toolchain image, network rule, higher budget [proposal].
- SecOps reviews an envelope once, not each read-only runbook inside it [proposal; relaxes E028].

**Never:**
- Approve its own change; let a model submit or approve [proposal; K02].
- Shell into a runner [doc: E016]; run unsigned artifacts [doc: E030].
- Put a model beside prod credentials [doc: E015].
- Edit gate, guards or evidence [doc: E017].
- Send first-party findings out [doc: E100].

### Boxes I want on the landscape
1. Build zone: Claude Code, UAT.
2. Promotion gate, catalog, persona registry.
3. Access layer: human actions only.
4. Control plane, credential broker.
5. Execution zone: runner, no model.
6. Agent zone: model, no prod.
7. Model gateway.
8. Evidence, findings, sanitisation.
9. Prod and UAT targets.

- Build zone -> Gate: change as pull request.
- Access layer -> Control plane: human-submitted job.
- Control plane -> Execution zone: job credentials, signed artifact.
- Execution zone -> Prod: scoped calls via proxy [doc: E043].
- Agent zone -> Model gateway: metered prompts.
- Agent zone -> Findings: write-only drop.
- Evidence -> Build zone: sanitised copy only.
- BLOCKED: Execution zone -> Model gateway [doc: E023]; Build zone -> Prod [doc: E020]; model -> Access layer [proposal].
- UNPROVEN: Agent zone -> Prod [doc: E187].

### Where the existing efforts sit
- Execution platform: boxes 3 to 5.
- Code scan pipeline: agent zone; findings in box 8.
- Pen-test agent: agent zone, egress pinned to one target [proposal]. Today: flat network [doc: E011, E012].
- Harness migration tool: build zone; reads, never executes [doc: E069].
- Devspace: outside the trust boundary. Undocumented, uses the prod proxy [doc: E013, E014].

### Two things I expect the other architects to get wrong
1. Calling an account or nono a boundary. The network is flat and nono is unverified [doc: E012, E113]. Give the agent zone a VPC with no attachment to the firm network; nono is the second layer [proposal].
2. Running ported ADK harnesses on runners. An ADK loop is a model loop [doc: E073]. Agent zone only [proposal].

### Questions only the owner can answer
1. Is the rule "no Claude at run time" [doc: E001] or "no model with prod reach" [doc: E015]?
2. One account is decided [doc: E091]. Which, and may the agent zone leave the flat network?
3. Must scan and pen-test agents pass the one gate?
4. Who owns envelopes and entitlements, and who approves prod runs?
5. Is Devspace inside the trust boundary [doc: E014]?


## Data architect

### Position in one paragraph
"Governed data access" must mean one rule: nothing is read, moved or released without a class label, a named owner, an entitlement and a log entry. [proposal] The documents barely govern data: sanitisation has no rules or owner, retention is unset, entitlement is one word. [doc: E047, E045, E049] I want one governance capability over several separate stores, and a persona defined as a data scope first, an image second. [proposal]

### The kinds of data this platform handles
- Raw prod evidence: from runners; highest; SecOps roles only. [doc: E033, E044]
- Sanitised evidence: from sanitisation; analysts, UAT replay. [doc: E046, E024]
- Live prod source data: runners only, inside a persona allowlist. [doc: E043]
- First-party code and findings: never leave the firm. [doc: E100, E110]
- Open-source copies: public but hostile; deleted after scan. [doc: E090]
- Findings, reproducers, traces, model logs: exploit detail; restricted, logged. [doc: E178]
- Control records (jobs, personas, approvals, manifests): integrity-critical. [doc: E034]
- UAT replica data: sensitivity unstated [doc: E024]; treat as prod. [proposal]

### Platform capabilities I insist on
1. Data register: every source and store with owner, class, retention, permitted personas. Everyone reads it. [proposal]
2. Entitlements: persona data scopes, requested by teams, approved by data owners, time-boxed. Job validation reads it. [doc: E049; service is proposal]
3. Class label at write: immutable, on every object. [doc: E110; platform-wide is proposal]
4. Release gate: the one way out of a restricted zone. Sanitisation and disclosure are both instances. [doc: E017, E111; unifying is proposal]
5. Lineage and read log: each output names its job, component version and inputs; restricted reads are logged. [doc: E044, E178; platform-wide is proposal]

### Self-service: what a cyber team changes alone, what goes through a gate, what it can never do
Alone [proposal; E028 requires an engineer even for UAT]:
- Edit a query pack against a source its persona already holds, in UAT.
- Shorten retention of its own working data.

Gate:
- Run a query pack on prod. [doc: E028]
- Onboard a data source; widen a persona's scope. [proposal]
- Change a sanitisation rule; lengthen retention; export anything. [proposal]

Never:
- Approve its own entitlement. [proposal]
- Read raw evidence from the build side. [doc: E017, E033]
- Lower a class label; send first-party findings outside. [doc: E110]
- Send unsanitised prod data to a model. [doc: E015, E054]

### Boxes I want on the landscape
1. Data register: what exists, owner, class. [proposal]
2. Entitlements: who reads what. [proposal]
3. Source connectors: governed doors to prod and UAT sources. [proposal]
4. Raw zone: evidence store, code store, findings drop. [doc: E044, E188]
5. Release gate: sanitise, human release. [doc: E046, E111]
6. Working zone: sanitised evidence, replay fixtures. [doc: E024]
7. Findings store: findings, traces, model logs. [doc: E167, E178]
8. Lineage and read log. [proposal]

Arrows:
- Source connectors -> Raw zone: collected prod records; sensitive. [proposal]
- Entitlements -> Job validation: persona data scope; integrity-critical. [doc: E049]
- Raw zone -> Release gate -> Working zone: raw in, sensitive; redacted out, lower. [doc: E017, E046]
- Working zone -> Build workspace: sanitised evidence, within reach of a model. [doc: E018, E033]
- Findings store -> Release gate -> Maintainers: open-source findings only, human-confirmed. [doc: E110, E111]

### Where the existing efforts sit
One governance capability, several stores. [proposal] Evidence store and findings store share a pattern: tamper-proof intake, integrity check, restricted reads. [doc: E044, E033, E109, E178; the comparison is proposal] Keep them apart, and findings apart from internet-fed catalogue data, as the review says. [doc: E158] The Artifact Catalog is a component registry; the scan catalog is a work inventory. Neither is a data catalogue. [doc: E029, E103]

### Two things I expect the other architects to get wrong
1. Drawing persona as image plus tools. [doc: E018, E038] A query pack is data access written as code [doc: E022], so agent self-service becomes data self-service unnoticed. [proposal]
2. Treating model prompts and logs as plumbing. They carry first-party code and exploit detail with no stated store or reader, and "sanitised" is undefined. [doc: open items K20, Q02]

### Questions only the owner can answer
1. Who owns each prod data source?
2. Does the UAT replica hold real prod records?
3. What retention per class? Is an irreversible lock acceptable?
4. May the sanitisation classifier be a model? Who owns it?
5. Must we use an existing firm entitlement and classification scheme?


## Agent systems architect

### Position in one paragraph
An agent is a versioned bundle of parts [proposal]. Teams own the parts that carry judgement; the platform owns the parts that set reach, and teams pick reach from lists [proposal]. Self-service means a team changes its judgement parts and an evaluation promotes them, with no platform engineer [proposal]. One run-time capability, the agent cell, serves scan, pen-test and ported harnesses [proposal].

### What "a cyber team modifies its own agent" has to mean
- **Instructions, skills:** team. Regression set, promoted on pass [doc: E124 for scan; proposal beyond]. The next run uses it [proposal].
- **Tools:** team picks from the catalog. A new tool passes the gate [doc: E027]. A write tool needs lead and SecOps [doc: E028].
- **Model:** team picks from a platform-owned list [proposal]; a change is re-evaluated [doc: E124].
- **Limits:** team sets them under a platform ceiling [proposal]. Metering sits outside the agent [doc: E123].
- **Sandbox image:** platform owns the base; team requests additions [proposal].
- **Data it may read:** the data owner grants, never the team [proposal]; the per-run role carries it [doc: E116].
- **Where it may write:** platform-fixed: drop and trace only [doc: E116].
- **Stop:** team may pull it, never disable it [proposal].

Two stacks: Claude Code authors, in the build plane [doc: E015, E020]. What runs is one agent configuration on the ADK wrapper [doc: E085 for scan; proposal beyond]. Teams never keep two copies [proposal]. Whether the wrapper supports custom tools and an external sandbox is unknown [doc: E131].

### Platform capabilities I insist on
1. **Agent registry.** Versioned prompt, model, tools, image, limits. Teams. [doc: E103 for scan; proposal beyond]
2. **Evaluation and promotion.** A regression set decides, not a person. Teams. [doc: E124]
3. **Agent cell.** Agent task with model access; sandbox task with no role; per-run credentials. Every agent. [doc: E106, E115]
4. **Validator and write-only drop.** Output is schema-checked data. Reviewers. [doc: E109]
5. **External stop.** Kills tasks, revokes sessions. Leads, orchestrator. [doc: E192]
6. **Model access.** Approved list, metering, restricted logs. Platform team. [proposal; doc: E130 undecided]

### The rule for models at run time
A model runs only in a cell with no prod credential and no route to prod. Prod credentials live only in compute with no route to a model [doc: E015, E023]. Only data crosses, through a fixed-rule check [proposal]. Draw two zones and one guarded line. "No route" must be enforced outside the agent, because UAT and prod share one network [doc: E012].

### Boxes I want on the landscape
1. Workbench: Devspace, Claude Code.
2. Agent repo.
3. Evaluation gate.
4. Registry: signed agents, tools, runbooks.
5. Agent cell.
6. Model access.
7. Broker and stop controller.
8. Validator and drop.
9. Runner: prod credentials, no model.
10. Prod targets.

- Workbench -> Repo: edits
- Repo -> Gate: candidate
- Gate -> Registry: signed version
- Registry -> Cell: pinned configuration
- Cell -> Model access: metered prompts
- Broker -> Cell: per-run credentials, kill
- Cell -> Validator: findings as data

Blocked: Cell -> Prod targets. Runner -> Model access. Workbench -> Cell [doc: E016]. Cell -> Registry.

### Where the existing efforts sit
Scan analysis and the pen-test agent are one capability: an agentic sandbox [doc: E007]. Pen-test adds egress to one target [doc: E011]. Runbooks are a different run-time kind, without a model [doc: E022, E023], sharing gate, registry and stop [proposal]. The migration tool is a build-plane on-ramp, not a run-time tenant [doc: E069].

### Two things I expect the other architects to get wrong
1. Sending every prompt change to an approver. Evaluation gates prompts; people gate reach [proposal].
2. Treating "isolated account" as isolation. It rests on nono, unverified [doc: E113].

### Questions only the owner can answer
1. Does "no Claude at run time" [doc: E001] ban Claude models, or only Claude Code?
2. May an instruction change go live on a regression pass alone?
3. Must scan and pen-test agents pass the same gate as runbooks?
4. Do ported harnesses run only in cells, never on runners [doc: E073]?
5. Who owns the approved model list and metering [doc: E130]?


## Cyber operations lead

### Position in one paragraph
I side with self-service: control at the fence, not at the keyboard [proposal]. The fence: no model beside prod credentials [doc: E015], a human approves prod [doc: E050]. Inside it, my teams change their own agents the same day [proposal]. We ship in weeks; the platform takes a quarter [doc: brief]. If this is slower than G35 [doc: E002], my people stay there [proposal].

### A day on this platform, for four of my people
**Detection engineer**
- Opens the persona desktop with Claude Code [doc: E018].
- Writes a rule, tests it on the replica SIEM [doc: E024].
- Waits for lead + SecOps to reach prod [doc: E028]. Lacks a threshold change without re-promotion [proposal].

**Incident responder**
- Opens the job form [doc: E032].
- Runs an approved read-only runbook on prod [doc: E032].
- Waits for approval, place undecided [doc: E162]. Lacks a follow-up query: the form takes no free text [doc: E032].

**Red team / pen tester**
- Opens the build desktop [doc: E018].
- Runs an agent with a model against one in-scope UAT target [doc: E011].
- Waits to learn if G34 is a range [doc: E025]. Lacks a way to declare scope and launch today [proposal].

**Vulnerability researcher**
- Opens the review UI [doc: E119].
- Confirms findings that carry a reproducer [doc: E107].
- Waits on limits with no numbers [doc: E191]. Lacks a way to change the agent's fixed tools and rerun [doc: E190; proposal].

### What my teams must be able to change by themselves, same day
All [proposal], peer-reviewed and replay-tested:
- Agent prompts, skills, decision tables, query packs, detection rules, UAT runbooks.
- Personas built from approved tools and UAT targets; budgets inside a team cap.

### What I accept goes through a gate, and how long that gate may take
- Prod-capable persona or write tool: lead + SecOps [doc: E028]. One working day [proposal].
- Prod job: just-in-time approval [doc: E050]. Fifteen minutes in an incident, one hour otherwise [proposal].
- New capability: a quarter [proposal].

### What I accept we can never do
- Run a model where prod credentials live [doc: E015].
- Take a shell on a prod runner [doc: E016].
- Move raw evidence to the build side [doc: E017].
- Approve our own prod job, or let an agent approve one [proposal; risk K02].

### Platform capabilities I need
1. A place to build with Claude Code on UAT data [doc: E020].
2. A place to run an agent loop with a model against a contained target, no prod credentials [doc: E011, E085; shared: proposal].
3. A way to change my agent or persona and see it live today, no image build [proposal].
4. A way to request data and see my entitlements [proposal].
5. A way to run an approved prod job with recording and kill [doc: E032, E044].
6. A way to ask a follow-up question mid-investigation [proposal].

### Where the current design fails my teams
- E022 freezes judgement into flow branches. Our harnesses are agent loops; where a ported one runs is undecided [doc: E002, E073].
- E016 with E032: investigation is not a form [proposal].
- E028, E050, E162: approvers named, no clock, no place [doc].
- E020 assumes Devspace. We are on G35 Workspaces [doc: E002].
- E038: a persona is an image; nobody is named to configure one [doc: brief].

### Two things I expect the architects to get wrong
1. They will call a pull request to the platform team self-service. That is a ticket queue [proposal].
2. They will make ADK porting the entry ticket. SmartSDK is unknown; the migration tool never ran on a real harness [doc: E010, E068]. Take our harnesses as they are [proposal].

### Questions only the owner can answer
1. Does "no vibe coding" [doc: E006] cover the build side, or only execution?
2. May our agent loops run with a model against contained targets, like the pen-test agent [doc: E011]?
3. Which gate times will you commit to?
4. Who may create a persona: a team lead or the platform team?
5. When do we get a cyber model [doc: E005]?


---


# Round 2: the lead designer's draft and the nine conflicts


Nothing here is a decision. [doc: id]: ledger row or open item. [notes]: owner statement, no ledger row yet.

### What all five agree on
- No model beside prod credentials [doc: E015]. Still proposed; the owner's wording is stricter [doc: E001, X02].
- Three workspaces: build (Claude Code, UAT only), execution (no model), agent sandbox (no prod credentials) [proposal; E020, E038, E106].
- One agent sandbox shared by scan and pen-test [proposal; E007].
- Teams change their own content in UAT without a platform engineer [proposal]. Prod-capable personas and write tools need lead plus SecOps [doc: E028].
- No shell in execution [doc: E016]. Nobody approves their own change; a data owner grants data [proposal].
- Only sanitised evidence reaches build [doc: E017]. Recording, stop and metering sit outside the workload [doc: E044, E192, E123].

### Draft landscape

**People and outside systems.** Cyber teams; lead and SecOps approvers [doc: E028]; data owners [proposal]; findings reviewers [doc: E119]. Outside: prod and UAT targets on one flat network [doc: E012]; firm and public repositories [doc: E100]; the model service [doc: E130]; Devspace, G35 Workspaces [doc: E013, E002]; maintainers [doc: E111].

**The platform's capabilities.**

*Build*
1. Build workspace [doc: E018, E020]. Platform/Security/Agents/Cyberops.
2. Team repos and scaffold [doc: E021]. Platform/Agents.

*Govern*
3. Promotion gate [doc: E027, E124; one gate: proposal]. Platform/Security/Agents.
4. Catalogue: signed components and agent configurations [doc: E029; agents: proposal]. Platform/Security/Agents.
5. Personas and entitlements [proposal; E049]. Security/Data/Platform. Disputed (C3, C7).
6. Access layer and control plane: jobs, approvals, kill, per-run credentials [doc: E032, E034, E115]. Platform/Security/Agents.
7. Model gateway and meter [doc: E023, E123]. Platform/Security/Agents.

*Run*
8. Execution [doc: E038]. All five.
9. Agent sandbox [doc: E106, disputed X07]. Platform/Security/Agents/Cyberops.
10. Outside guards: scope guard, recorder, stop [doc: E056, E192]. Security/Agents.

*Governed data*
11. Raw stores with checked intake: evidence, code, findings drop [doc: E044, E109]. Data/Agents.
12. Release gate: sanitise, human release [doc: E046, E111; unifying: proposal]. Data.
13. Working store and findings store, apart [doc: E024, E158]. Data.

**Main arrows.**
1. Build -> Repos -> Gate -> Catalogue: edits, pull request, signed version [doc: E029].
2. People -> Access layer: job, approval, kill [doc: E032]. A model -> Access layer: BLOCKED [proposal; K02].
3. Catalogue, Personas -> Control plane: signed artifact, job scope [doc: E030, E049].
4. Control plane -> Execution, Sandbox: launch, per-run credentials, stop [doc: E041, E115].
5. Execution -> Prod targets: scoped calls via proxy [doc: E043].
6. Build, Sandbox -> Model gateway: metered prompts [doc: E023, E116; one gateway: proposal].
7. Execution, Sandbox -> Raw stores: evidence; findings, write-only [doc: E044, E109].
8. Findings store -> Release gate -> Maintainers: confirmed open-source findings [doc: E110, E111].
9. UNPROVEN: Raw stores -> Release gate -> Build: sanitised copy; rules unset [doc: E017, E047].
10. UNPROVEN: Sandbox -> one UAT target: pinned egress on a flat network [doc: E011, E012].
11. UNPROVEN: Sandbox -> Prod targets [doc: E187].
12. BLOCKED: Execution -> Model gateway [doc: E023].
13. BLOCKED: Build -> Prod targets, Execution [doc: E020, E016].

**Where the existing efforts sit** [proposal].
- Execution platform: boxes 3, 4, 6, 8, 10.
- Code scan pipeline: a tenant; sandbox is box 9, findings in 11 to 13, intake its own.
- Pen-test agent: box 9, egress pinned to one target [doc: E011].
- Harness migration tool: build zone; reads, never executes [doc: E069]. Disputed (C4).
- Devspace: outside, another team's product [doc: K03]. Disputed (C9).

**Self-service, merged.** Unmarked cells are [proposal].

| Changed | Team alone | Gate (approver) | Never |
|---|---|---|---|
| Prompt, query pack, rule, runbook | UAT, team peer (C1) | Prod-capable: lead plus SecOps [doc: E028] (C2) | Uncatalogued [doc: E030] |
| Tool | From catalogue | New: disputed (C2) | |
| Model, limits | Approved list; under team cap | Beyond either: outside the team | Beside prod credentials [doc: E015] |
| Persona | Narrow | New or wider: disputed (C3) | |
| Data access | Shorten own retention | Entitlement: data owner | Raw evidence to build [doc: E017] |
| Network, gate checks, guards, evidence | | | Always |

### Use case families against the landscape
1. **Build:** 1 to 4.
2. **Run:** 4 to 6, 8, 10, 11. Prod approval's place is undecided [doc: E162].
3. **Investigate:** 6, 13 to read. The follow-up query has no home (C5).
4. **Scan:** 6, 7, 9 to 13. Intake has no platform home [proposal].
5. **Migrate:** 1, 2. No run-time landing until C4.
6. **Failure, data lifecycle:** 6, 10 to 13. Retention is unset [doc: E045].
7. **Self-service:** 2 to 5. No use case; persona and data access have no agreed home (C3, C7).

### Points of conflict

**C1. Does a person approve a prompt change, and how fast is it live?**
- Agents: "A regression set decides, not a person."
- Platform, Security, Cyberops: a team peer too. Platform: "in days". Cyberops: "same day" [notes: weeks against a quarter].
- Drawing: a person and a time on the gate's content lane.
- Agents: what evaluates a detection rule, when E124 covers scan only? Platform: what takes days?

**C2. What sends a change outside the team: each prod-capable change, or the envelope?**
- Platform, Data: each change [doc: E028].
- Security: SecOps reviews "an envelope once"; yet any new tool goes outside. Agents: a new tool only "passes the gate". Cyberops wants "a threshold change without re-promotion".
- Drawing: what the gate's lanes are keyed on.
- Platform, Data: may a read-only prod runbook inside an approved envelope ship on a team peer? Security, Agents: who approves a new read-only UAT tool?

**C3. What is a persona, and who creates one?**
- Security: a "reach envelope"; "Security owns envelopes". Data: "a data scope first, an image second".
- Cyberops: "built from approved tools and UAT targets", same day. Platform: a "new or wider persona" passes a gate. Agents: silent.
- Drawing: persona in box 4 [doc: E022] or box 5, and whose.
- All four: name one owner and one home.

**C4. Must a harness be ported before it runs here?**
- Agents: "one agent configuration on the ADK wrapper". Platform: "on the firm's stack".
- Cyberops: "Take our harnesses as they are"; the wrapper is unknown [doc: E010, E131].
- Drawing: one run-time stack in box 9 or two.
- Cyberops: how does an as-is harness meet E001? Agents, Platform: what runs until the wrapper is known?

**C5. Does anything reach execution except a human submitting a catalogued job?**
- Security: never "let a model submit or approve". Platform: "humans only", yet from the workspace holding Claude Code [doc: K02].
- Agents: "Only data crosses, through a fixed-rule check." Cyberops: "Our harnesses are agent loops"; "investigation is not a form".
- Drawing: an arrow from box 9 to box 8, a free-text path, or neither.
- Agents: which data, which direction? Security, Platform: is a read-only ad hoc query inside a persona allowlist acceptable?

**C6. May a model read UAT replica data?**
- Data: "treat as prod", and never "unsanitised prod data to a model". Cyberops, Platform, Security build with Claude Code on it [doc: E020, E024].
- Drawing: UAT data -> Build direct, or through the release gate.
- Data: if the replica holds real records, is the build zone closed?

**C7. How much data governance sits on the top view?**
- Data: eight boxes, with a register and a lineage log; stores "apart" [doc: E158].
- Platform: entitlements "as short-lived credentials". Platform, Security: one evidence-and-findings box.
- Drawing: three data boxes plus box 5, or one store and one broker.
- Platform, Security: is the entitlement record the credential broker? Data: which three boxes carry the top view?

**C8. Is sandbox isolation blocked or unproven?**
- Agents: "Blocked: Cell -> Prod targets". Security: "UNPROVEN"; wants "no attachment to the firm network".
- Drawing: arrow 11 blocked or unproven; one network profile for box 9 or two.
- Security: how does a detached VPC reach the pen-test target? Agents: what evidence earns "blocked"?

**C9. Where does Claude Code live?**
- Agents: "Workbench: Devspace". Security: Devspace is "outside the trust boundary". Cyberops: "We are on G35 Workspaces".
- Drawing: Devspace inside box 1 or outside.
- Security, Platform: what hosts box 1 if not Devspace [doc: E020]? Cyberops: is G35 the first build workspace?

**Predictions checked.**
- Platform: both wrong. Security frees prompts; Agents' registry holds runbooks too.
- Security, Agents: nobody called an account or nono a boundary, or put harnesses on runners.
- Data: "image plus tools" fits Cyberops; logs "as plumbing" fits Platform.
- Agents: "every prompt change to an approver" is half right; the approver is a team peer.
- Cyberops: "pull request to the platform team" is wrong for content, true for images; "entry ticket" is right.

### What I will draw if nobody objects
- One top view: four zones, thirteen boxes. Existing efforts become labels over boxes, not systems.
- Everything stays proposed; box 5, box 12 and arrows 9 to 11 show as disputed or unproven.
- A self-service use case family, after round 3.


---

# Round 3: the answers


## Platform architect: answer

### Conflicts that name me

**C1. MOVE.** Nothing takes days. A UAT content change is live the same day, once checks pass and a team peer approves [proposal]. I hold the peer: no evaluator exists outside scan [doc: E124].

**C2. MOVE** to Security's envelope. Reach is the control, not runbook text [doc: E043, E056]. Yes: a read-only prod runbook built from catalogued tasks [doc: E035], inside an approved envelope, ships on a team peer, if the gate checks the fit by machine [proposal; relaxes E028].

**C3. MOVE.** Home: box 4 [doc: E022]. Owner: the team. The envelope is a separate record, Security's, in box 5. A persona inside an envelope: team alone. Wider means a new envelope [proposal].

**C4. HOLD.** An as-is harness in box 9 is Claude at run time, against the owner's rule [doc: E001], and a second stack to operate. Until the wrapper is surveyed [doc: E131, K05], harnesses stay in build against UAT.

**C5. MOVE.** Yes: an ad hoc read as a catalogued job type, typed query, human-submitted, scope-guarded, recorded [proposal; relaxes E032]. No arrow from box 9 to box 8.

**C6. HOLD.** Real records in the replica are a replica defect; mask at source. Closing build sends teams back to G35 [doc: E002]. Draw it direct, unproven.

**C7. MOVE.** No. The record says who may read. The broker reads it at validation and issues credentials [doc: E049, E115]. I accept findings apart [doc: E158]. Register and lineage are not top-view boxes.

**C9. HOLD.** Box 1 is a platform contract: UAT-only network, model route, managed settings [doc: E020]. Hosts sit outside: G35 Workspaces first [doc: E002], Devspace once held to UAT [doc: K03].

### Objections to the draft landscape

- Box 5 mixes two owners. Move personas to box 4; box 5 holds envelopes and entitlements [proposal].
- Missing: a team record (members, lead, quota). "Team peer" and "team cap" have no home [proposal].
- Arrow 2's block has no mechanism. Mark it unproven [doc: K02].
- Each gate lane needs a clock [proposal].

### One compromise I could live with

For C2. SecOps approves each envelope once. Read-only changes inside it ship on a team peer; SecOps is notified and can revoke the catalogue entry [proposal]. Cost: SecOps loses pre-approval on read-only prod content. A bad runbook runs until revoked. The fit check is platform work, about a quarter. Until then E028 applies.


## Security architect: answer

### Conflicts that name me
- **C1: HOLD.** A team peer approves, same day. A regression set proves quality, not intent, and E124 covers scan only. Only humans merge [doc: E079].
- **C2: MOVE on tools, HOLD on envelopes.** I overstated E028. A new read-only UAT tool needs the gate plus a team peer [doc: E027, E028]. It leaves the team when it enters a prod-capable envelope [proposal]. A read-only prod runbook inside an approved envelope ships on the lead, without SecOps: each prod job is still approved and scope-guarded [doc: E050, E056].
- **C3: HOLD, with a split** [proposal]. Security owns the envelope, in box 5. A team's persona is a selection inside one, in box 4, same day. Data scope is one field, granted by the data owner.
- **C5: MOVE.** A human may type a read-only query inside a running job's allowlist, recorded, results through the release gate [proposal]. HOLD: no arrow from box 9 to box 8.
- **C6: MOVE to Data.** A replica holding real records is prod data. Draw UAT data -> Build as UNPROVEN [proposal; E024].
- **C7: HOLD.** The entitlement record decides; the broker enforces. Different owners [proposal]. MOVE: findings and evidence apart [doc: E158].
- **C8: HOLD unproven; MOVE to two profiles** [proposal]. Scan: no attachment to the firm network. Pen-test: the sandbox stays detached; a platform-owned egress proxy, pinned per run to one target, is the only part on the flat network. "Blocked" needs the network team's answer [doc: Q23] and a failing probe from inside the sandbox.
- **C9: HOLD.** Box 1 is a platform-owned profile; its host is undecided [proposal]. Devspace uses the prod proxy [doc: E013]; G35 has attribution issues [doc: E003].

### Objections to the draft landscape
- Arrow 13 is not BLOCKED: build's assumed host reaches the prod proxy [doc: E013, K03]. Draw UNPROVEN.
- Missing: Model gateway -> Findings store: prompt logs [doc: E178, K20].
- Missing: Raw stores -> Access layer: pause-state evidence before sanitisation [doc: E033, K01].
- Split the credential broker out of box 6 [doc: K08].

### One compromise I could live with
C8 [proposal]. Scan gets the detached VPC now. Pen-test stays on the flat network [doc: E011] for a fixed period while the proxy is built, with a named risk owner. Cost: until then only security groups and nono keep model-written test code from prod [doc: K06, E113].


## Data architect: answer

### Conflicts that name me
**C2: MOVE, with a condition.** Security is right: reviewing each read-only runbook inside an approved envelope protects nothing [proposal]. New position: a team peer suffices when data reach is unchanged and the source enforces it by dataset. Where reach is only a proxy allowlist [doc: E043], a new prod query pack still goes outside: one source holds several classes [proposal].

**C3: MOVE on the name, HOLD on the grant.** I accept "reach envelope", with data as a mandatory row. Home: box 5. Record owner: Security. The data row is granted by the data owner, never by Security or the team [proposal]. The image is a catalogued artifact in box 4 [doc: E029]. Same-day personas are fine when every data row is already granted [proposal].

**C6: HOLD.** No, the build zone is not closed. E020 points build at UAT; it does not say what the replica holds [doc: E020, E024]. If it holds real records, it is a path from prod to a model that skips sanitisation [doc: E017], and prompt retention is unknown [doc: K20]. A model may read the replica only if it is synthetic or tokenised at load [proposal]. Otherwise build runs on the other three substrates [doc: E024].

**C7: MOVE.** Eight boxes was a detail view. Three data boxes plus box 5 carry the top. The register sits inside box 5, lineage inside the recorder [proposal]. I HOLD two points. No single evidence-and-findings box: different classes, different exit rules [doc: E110, E158]. The entitlement record is not the broker: box 6 mints from box 5's record. A credential expires; an auditor needs who granted what [proposal].

### Objections to the draft landscape
- Box 13 sits on both sides of the gate. Draw 11 as "Restricted stores: evidence, code, findings, apart" and 13 as "Working store: released copies" [proposal].
- Missing arrow: UAT data -> Build, UNPROVEN [doc: E024].
- Missing arrow: Model gateway -> Restricted stores: invocation logs, classed as findings [doc: E178]. Arrow 6 carries code and exploit detail [doc: K20].

### One compromise I could live with
C6. Tokenise identifiers consistently when the replica is loaded, by fixed rules, no model [proposal]. Claude Code then reads it. Cost: the tokeniser needs an owner, and none is named [doc: E047]. Rules matching literal names or hosts cannot be tested in build; they run as a slower UAT job in execution.


## Agent systems architect: answer

### Conflicts that name me
**C1. MOVE.** A regression set alone may not put a prompt live: the team owns the set, so that is self-grading [doc: E075]. Now: team peer plus regression pass, live same day [proposal]. HOLD: nobody outside the team; reach is fixed outside the prompt [doc: E190]. Rules: fixture replay is the test [doc: E027].

**C2. HOLD.** Key the gate on reach [proposal]. A new tool handed to a model goes outside the team once, even read-only: hostile input steers a model [doc: K19]. For a fixed flow: team engineer [doc: E028].

**C3.** Persona is a reach envelope, Security-owned, box 5. Agent configurations reference it [proposal].

**C4. HOLD.** Porting is the entry ticket to box 9, not to the platform. As-is harnesses run in build against UAT [doc: E020]. The owner decided no Claude at run time [doc: E001]; not ours to trade. Until the wrapper is known [doc: E131], box 9 holds scan and pen-test, already on ADK [doc: E085, E011].

**C5. HOLD.** One direction: sandbox -> drop -> validator -> person [doc: E109]. No arrow box 9 to box 8. An agent may propose a job: catalogued runbook plus parameters. A human submits [proposal]. Model-written free text behind a human click drives prod [doc: K02].

**C8. MOVE.** The attachment is unknown [doc: E187]. Draw UNPROVEN. "Blocked" is earned by route tables with no path, plus a failing reach test from inside the sandbox on every change [proposal]. Two profiles: detached for scan; pinned egress for pen-test, enforced outside the task [proposal].

**C9. MOVE.** Box 1 is a profile: Claude Code, UAT, no prod route. Devspace uses the prod proxy [doc: E013]; draw it outside [proposal].

### Objections to the draft landscape
1. Missing arrow: Gate -> Sandbox, candidate run on the regression set [doc: E124; arrow: proposal].
2. Box 10: the scope guard is a library inside the runner [doc: E056]. Draw the proxy allowlist on arrow 5 [doc: E043].
3. Missing blocked arrow: Sandbox -> Catalogue; no agent edits its own definition [proposal].

### One compromise I could live with
C4. The owner rewords E001 as "no Claude beside prod". Then an as-is harness may run in box 9, UAT targets only, until the wrapper spike reports [proposal; E159]. The cell's guards do not depend on the stack [proposal]. Cost: two run-times, two catalogue formats, an exception to the ADK direction [doc: E004].


## Cyber operations lead: answer

### Conflicts that name me
- **C1. HOLD: same day.** Platform names nothing that takes days; the checks are automated [doc: E027].
- **C2. MOVE to Security.** The envelope is reviewed once; read-only changes inside ship on a peer. Every new tool leaves the team, within one working day [proposal].
- **C3. MOVE.** Reach is the control, so Security owns envelopes. Team leads compose narrower personas inside, same day [proposal].
- **C4. MOVE.** An as-is harness in box 9 breaks a decided owner rule [doc: E001]. New position: port before box 9, never before entry [proposal]. I hold this: harnesses keep running in G35 [doc: E002] until the wrapper runs one real harness [doc: E068, E131].
- **C5. HOLD the need, MOVE on agents.** No agent submits jobs; no arrow from box 9 to box 8. A responder still needs a human-typed read-only query inside the persona allowlist. The string goes to the data source as a query, never to the runner as code; the scope guard checks target and read-only [proposal; E056]. Without it, responders return to the console.
- **C6. Conditional.** If the replica holds real records, I accept the release gate before build [proposal]. If not, hold [doc: E024].
- **C9.** Yes: G35 Workspaces is the first build workspace [proposal]. Fix its attribution first [doc: E003].

### Would my teams use this landscape, or stay where they are today?
Detection engineers move, if same day holds. Responders do not, without the follow-up query. Harness owners stay in G35: they get a gate and no landing [proposal].

### Objections to the draft landscape
All [proposal]:
- Missing arrow: People -> Access layer -> Execution, "read-only ad hoc query inside persona allowlist". Draw it disputed, not absent.
- Missing box: G35 as today's run place, with an UNPROVEN arrow through migration to box 9 [doc: E002, E073].
- Every gate lane needs a clock [doc: E162].
- Envelope in box 5; team-composed persona in box 4.

### One compromise I could live with
For C4. The owner confirms E001 covers boxes 8 and 9: ADK wrapper only. In return, G35 is the named interim run place for existing harnesses, never prod, until one real harness passes in box 9; the platform funds that first port [proposal]. Cost: two run places for months, G35's attribution gap stays open [doc: E003], and my teams author in one stack, run in another.


---


# Round 4: where it ended


Decided by: nobody (no person in the room). "Settled" means the room recommends it; all of it stays `proposed`.

### Where each conflict ended

**C1. Prompt change: who approves, how fast. Settled.** A UAT content change is live the same day, on automated checks plus one team peer; nobody outside the team. Agents dropped "the regression set alone"; Platform dropped "days".

**C2. What leaves the team. Settled in part.** The gate is keyed on reach: SecOps reviews an envelope once, and read-only changes inside it ship without SecOps. This relaxes E028. Still disputed:
- Who signs inside a prod-capable envelope: a team peer (Platform, Cyberops, Data) or the lead (Security).
- Data: a new prod query pack still leaves the team where the source cannot enforce reach by dataset.
- A new read-only tool: gate plus team peer (Security, Platform); outside the team once when a model gets it (Agents); always outside, within one working day (Cyberops).

**C3. Persona. Settled in the main.** The envelope is Security's record of reach, with a data row only the data owner grants. A persona is a team's selection inside one envelope, catalogued, composed the same day. Wider means a new envelope. (Reviewer's note: the agent systems architect ended on 'a persona is the Security-owned envelope itself', so who owns the word 'persona' is not fully settled.)

**C4. Port before run. Rule settled, interim disputed.** Nothing un-ported runs in the sandbox or execution; porting is the ticket to the sandbox, not to the platform. Until the wrapper is known, existing harnesses run in build against UAT (Platform, Agents) or stay in G35 as the named interim place (Cyberops).

**C5. What reaches execution. Settled in part.** No arrow from sandbox to execution; no agent submits or approves. Still disputed: a human-typed read-only query. Platform, Security and Cyberops back it, in three shapes; Agents holds against free text a model may have written [doc: K02]. It relaxes E032.

**C6. A model on UAT replica data. Drawing settled.** Unproven until we know what the replica holds. If real records: tokenise at load (Platform, Data) or pass the release gate first (Cyberops); Security calls it prod data.

**C7. Data on the top view. Settled in the main.** The entitlement record decides; the broker enforces and mints from it. Evidence and findings stores stay apart. Register and lineage are not top-view boxes. Security's separate broker box [doc: K08] is not drawn; Security still asks for it (reviewer's note).

**C8. Sandbox isolation. Settled.** Drawn unproven. Two network profiles: scan detached; pen-test detached with a pinned egress proxy. "Blocked" needs the network team's answer [doc: Q23] and a failing probe from inside.

**C9. Where Claude Code lives. Settled in part.** The build workspace is a platform-owned profile; hosts sit outside. First host: G35 Workspaces (Platform, Cyberops) or undecided (Security). Build to prod is drawn unproven [doc: E013].

### What only the owner can settle, most important first

1. Does "no Claude at run time" [doc: E001] cover the agent sandbox, or only compute with prod reach?
2. May SecOps review an envelope once instead of each prod-capable change [doc: E028]? Who signs inside it?
3. May a person type a read-only query mid-investigation [doc: E032, E006]?
4. Does the UAT replica hold real prod records? Who owns the tokeniser?
5. Which host carries the build workspace first? Is G35 the interim place for harnesses? Who pays for the first port?
6. Which clocks will the gate commit to, and where is a prod job approved [doc: E162]?
7. May the sandbox leave the flat network? Who owns the pen-test risk meanwhile?
8. Who owns envelopes, and who owns each data source?
9. Must scan and pen-test agents pass the one gate [doc: K14]?
10. Who approves a new tool for an agent?


---


# Independent review of what was drawn


### Verdict in three lines
Not ready. The detail panels are honest; the faces mislead, and a leader reads only faces.
Her two key sentences do not show at a glance: self-service is one sub-label, and nothing frames "Cyberspace".
The lane chart is clean, but it sells a same-day prod lane that does not exist yet.

### Must change before the owner sees it
1. **A lane is sold that does not exist.** `lane/inside` says "same day". Today E028 applies and the fit check is a quarter of unbuilt work; only the details say so. Fix: the face reads "not open until the owner relaxes E028 and the fit check exists; until then lead plus SecOps".
2. **Self-service is invisible on the landscape.** `platform/team` has one arrow, "builds with Claude Code". Fix: relabel `team>build` "changes its own agents, tools, personas, runbooks"; `gate` sub "team alone for content; outside the team for reach"; restore the round 2 table (team alone / gate / never).
3. **Disputes do not show.** `platform/adhoc` renders amber; `hosts>build` and `build>uat` red. None reads as disputed, whatever X23 says. The model in `sandbox` rests on Q29, against an owner-decided rule (E001), yet is drawn plain. Fix: write "(disputed, X23)" into the labels; mark `sandbox>mgw` disputed, "rests on Q29".
4. **Arrows into prod say two things.** `build>prod` and `sandbox>prod` are solid arrows labelled "no ... route: unproven". Devspace reaches the prod proxy today (E013), so `build>prod` is open, not unproven. The centre has four crossings. Fix: label them "open today on Devspace: must close" and "not shown closed"; route `build>prod` along the bottom.
5. **"One way out" is not true as drawn.** The zone title and `rel` claim it. K01 says raw evidence shows in the access layer first (E033). Security asked for that arrow. `rel` has one exit, to `build`, so confirmed findings seem to reach the model's desk. Fix: draw `evid>ctl` unproven; add the disclosure exit and the findings reviewer; retitle "one way to the build side".
6. **`sandbox>exec` is drawn "cannot reach" on an agreement.** No mechanism exists; E109 does not say it. Fix: draw it unproven, "agreed rule, no mechanism", as Platform asked for `build>ctl`.
7. **"Inside Cyberspace" has no frame.** `mgw` floats outside every zone. Efforts are named only in details; round 2 promised labels. Fix: one outer frame "Cyberspace"; subs such as `sandbox` "today: code scan, pen-test agents".

### Should change
- R04 "covered" is not earned: no host, no sizes. Set partial. Add a requirement for the sandbox sentence (E197).
- `build` opens the Devspace design. That picks the host X25 leaves open. Link `hosts` instead.
- C3 and C7 read "settled". Agents ended on "persona is the envelope"; Security still wants the broker apart (K08). Log both as conflicts.
- Link K01, K02, K06, K08, K14, K20 and X02 to landscape boxes.
- The code store (Data asked) is absent and missing from the left-off note.
- `lane/envelope` runs straight to "Sign and publish": the change itself gets no approver, and no clock shows.
- "One working day" on `lane/secops` and `lane/tool` is one architect's ask.
- Tour steps 6 and 10 state unbuilt things as fact; so does `sspersona`.

### Can wait
- "Agreed by all five" on `sandbox>exec`: four said it; Data was silent.
- The legend has no entry for a red-bordered label. "Envelope" and "fit check" need plain words.

### What the landscape does well
Unproven lines are drawn unproven. Each conflict carries every architect's position and source. Nothing claims to be decided.

### Questions for the owner that the page does not yet ask
- What did "built on the initiative's own hub" mean?
- Is a persona a kind of user with a ready workspace, or a permission set? The room chose the second.
- "Their own things": does that include compute, models and network?
- Until the fit check exists, what self-service is enough?
- If the gate or control plane is down mid-incident, what may a responder do?
- Is an agent that reads first-party source "UAT only" for the same-day lane?
- What clock applies to a data grant and to a new envelope?
