## Conflicts that name me
**C1. MOVE.** A regression set alone may not put a prompt live: the team owns the set, so that is self-grading [doc: E075]. Now: team peer plus regression pass, live same day [proposal]. HOLD: nobody outside the team; reach is fixed outside the prompt [doc: E190]. Rules: fixture replay is the test [doc: E027].

**C2. HOLD.** Key the gate on reach [proposal]. A new tool handed to a model goes outside the team once, even read-only: hostile input steers a model [doc: K19]. For a fixed flow: team engineer [doc: E028].

**C3.** Persona is a reach envelope, Security-owned, box 5. Agent configurations reference it [proposal].

**C4. HOLD.** Porting is the entry ticket to box 9, not to the platform. As-is harnesses run in build against UAT [doc: E020]. The owner decided no Claude at run time [doc: E001]; not ours to trade. Until the wrapper is known [doc: E131], box 9 holds scan and pen-test, already on ADK [doc: E085, E011].

**C5. HOLD.** One direction: sandbox -> drop -> validator -> person [doc: E109]. No arrow box 9 to box 8. An agent may propose a job: catalogued runbook plus parameters. A human submits [proposal]. Model-written free text behind a human click drives prod [doc: K02].

**C8. MOVE.** The attachment is unknown [doc: E187]. Draw UNPROVEN. "Blocked" is earned by route tables with no path, plus a failing reach test from inside the sandbox on every change [proposal]. Two profiles: detached for scan; pinned egress for pen-test, enforced outside the task [proposal].

**C9. MOVE.** Box 1 is a profile: Claude Code, UAT, no prod route. Devspace uses the prod proxy [doc: E013]; draw it outside [proposal].

## Objections to the draft landscape
1. Missing arrow: Gate -> Sandbox, candidate run on the regression set [doc: E124; arrow: proposal].
2. Box 10: the scope guard is a library inside the runner [doc: E056]. Draw the proxy allowlist on arrow 5 [doc: E043].
3. Missing blocked arrow: Sandbox -> Catalogue; no agent edits its own definition [proposal].

## One compromise I could live with
C4. The owner rewords E001 as "no Claude beside prod". Then an as-is harness may run in box 9, UAT targets only, until the wrapper spike reports [proposal; E159]. The cell's guards do not depend on the stack [proposal]. Cost: two run-times, two catalogue formats, an exception to the ADK direction [doc: E004].
