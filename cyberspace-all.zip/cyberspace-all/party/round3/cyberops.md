## Conflicts that name me
- **C1. HOLD: same day.** Platform names nothing that takes days; the checks are automated [doc: E027].
- **C2. MOVE to Security.** The envelope is reviewed once; read-only changes inside ship on a peer. Every new tool leaves the team, within one working day [proposal].
- **C3. MOVE.** Reach is the control, so Security owns envelopes. Team leads compose narrower personas inside, same day [proposal].
- **C4. MOVE.** An as-is harness in box 9 breaks a decided owner rule [doc: E001]. New position: port before box 9, never before entry [proposal]. I hold this: harnesses keep running in G35 [doc: E002] until the wrapper runs one real harness [doc: E068, E131].
- **C5. HOLD the need, MOVE on agents.** No agent submits jobs; no arrow from box 9 to box 8. A responder still needs a human-typed read-only query inside the persona allowlist. The string goes to the data source as a query, never to the runner as code; the scope guard checks target and read-only [proposal; E056]. Without it, responders return to the console.
- **C6. Conditional.** If the replica holds real records, I accept the release gate before build [proposal]. If not, hold [doc: E024].
- **C9.** Yes: G35 Workspaces is the first build workspace [proposal]. Fix its attribution first [doc: E003].

## Would my teams use this landscape, or stay where they are today?
Detection engineers move, if same day holds. Responders do not, without the follow-up query. Harness owners stay in G35: they get a gate and no landing [proposal].

## Objections to the draft landscape
All [proposal]:
- Missing arrow: People -> Access layer -> Execution, "read-only ad hoc query inside persona allowlist". Draw it disputed, not absent.
- Missing box: G35 as today's run place, with an UNPROVEN arrow through migration to box 9 [doc: E002, E073].
- Every gate lane needs a clock [doc: E162].
- Envelope in box 5; team-composed persona in box 4.

## One compromise I could live with
For C4. The owner confirms E001 covers boxes 8 and 9: ADK wrapper only. In return, G35 is the named interim run place for existing harnesses, never prod, until one real harness passes in box 9; the platform funds that first port [proposal]. Cost: two run places for months, G35's attribution gap stays open [doc: E003], and my teams author in one stack, run in another.
