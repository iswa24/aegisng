## Conflicts that name me
- **C1: HOLD.** A team peer approves, same day. A regression set proves quality, not intent, and E124 covers scan only. Only humans merge [doc: E079].
- **C2: MOVE on tools, HOLD on envelopes.** I overstated E028. A new read-only UAT tool needs the gate plus a team peer [doc: E027, E028]. It leaves the team when it enters a prod-capable envelope [proposal]. A read-only prod runbook inside an approved envelope ships on the lead, without SecOps: each prod job is still approved and scope-guarded [doc: E050, E056].
- **C3: HOLD, with a split** [proposal]. Security owns the envelope, in box 5. A team's persona is a selection inside one, in box 4, same day. Data scope is one field, granted by the data owner.
- **C5: MOVE.** A human may type a read-only query inside a running job's allowlist, recorded, results through the release gate [proposal]. HOLD: no arrow from box 9 to box 8.
- **C6: MOVE to Data.** A replica holding real records is prod data. Draw UAT data -> Build as UNPROVEN [proposal; E024].
- **C7: HOLD.** The entitlement record decides; the broker enforces. Different owners [proposal]. MOVE: findings and evidence apart [doc: E158].
- **C8: HOLD unproven; MOVE to two profiles** [proposal]. Scan: no attachment to the firm network. Pen-test: the sandbox stays detached; a platform-owned egress proxy, pinned per run to one target, is the only part on the flat network. "Blocked" needs the network team's answer [doc: Q23] and a failing probe from inside the sandbox.
- **C9: HOLD.** Box 1 is a platform-owned profile; its host is undecided [proposal]. Devspace uses the prod proxy [doc: E013]; G35 has attribution issues [doc: E003].

## Objections to the draft landscape
- Arrow 13 is not BLOCKED: build's assumed host reaches the prod proxy [doc: E013, K03]. Draw UNPROVEN.
- Missing: Model gateway -> Findings store: prompt logs [doc: E178, K20].
- Missing: Raw stores -> Access layer: pause-state evidence before sanitisation [doc: E033, K01].
- Split the credential broker out of box 6 [doc: K08].

## One compromise I could live with
C8 [proposal]. Scan gets the detached VPC now. Pen-test stays on the flat network [doc: E011] for a fixed period while the proxy is built, with a named risk owner. Cost: until then only security groups and nono keep model-written test code from prod [doc: K06, E113].
