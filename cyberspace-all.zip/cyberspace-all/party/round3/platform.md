## Conflicts that name me

**C1. MOVE.** Nothing takes days. A UAT content change is live the same day, once checks pass and a team peer approves [proposal]. I hold the peer: no evaluator exists outside scan [doc: E124].

**C2. MOVE** to Security's envelope. Reach is the control, not runbook text [doc: E043, E056]. Yes: a read-only prod runbook built from catalogued tasks [doc: E035], inside an approved envelope, ships on a team peer, if the gate checks the fit by machine [proposal; relaxes E028].

**C3. MOVE.** Home: box 4 [doc: E022]. Owner: the team. The envelope is a separate record, Security's, in box 5. A persona inside an envelope: team alone. Wider means a new envelope [proposal].

**C4. HOLD.** An as-is harness in box 9 is Claude at run time, against the owner's rule [doc: E001], and a second stack to operate. Until the wrapper is surveyed [doc: E131, K05], harnesses stay in build against UAT.

**C5. MOVE.** Yes: an ad hoc read as a catalogued job type, typed query, human-submitted, scope-guarded, recorded [proposal; relaxes E032]. No arrow from box 9 to box 8.

**C6. HOLD.** Real records in the replica are a replica defect; mask at source. Closing build sends teams back to G35 [doc: E002]. Draw it direct, unproven.

**C7. MOVE.** No. The record says who may read. The broker reads it at validation and issues credentials [doc: E049, E115]. I accept findings apart [doc: E158]. Register and lineage are not top-view boxes.

**C9. HOLD.** Box 1 is a platform contract: UAT-only network, model route, managed settings [doc: E020]. Hosts sit outside: G35 Workspaces first [doc: E002], Devspace once held to UAT [doc: K03].

## Objections to the draft landscape

- Box 5 mixes two owners. Move personas to box 4; box 5 holds envelopes and entitlements [proposal].
- Missing: a team record (members, lead, quota). "Team peer" and "team cap" have no home [proposal].
- Arrow 2's block has no mechanism. Mark it unproven [doc: K02].
- Each gate lane needs a clock [proposal].

## One compromise I could live with

For C2. SecOps approves each envelope once. Read-only changes inside it ship on a team peer; SecOps is notified and can revoke the catalogue entry [proposal]. Cost: SecOps loses pre-approval on read-only prod content. A bad runbook runs until revoked. The fit check is platform work, about a quarter. Until then E028 applies.
