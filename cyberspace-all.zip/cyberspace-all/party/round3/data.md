## Conflicts that name me
**C2: MOVE, with a condition.** Security is right: reviewing each read-only runbook inside an approved envelope protects nothing [proposal]. New position: a team peer suffices when data reach is unchanged and the source enforces it by dataset. Where reach is only a proxy allowlist [doc: E043], a new prod query pack still goes outside: one source holds several classes [proposal].

**C3: MOVE on the name, HOLD on the grant.** I accept "reach envelope", with data as a mandatory row. Home: box 5. Record owner: Security. The data row is granted by the data owner, never by Security or the team [proposal]. The image is a catalogued artifact in box 4 [doc: E029]. Same-day personas are fine when every data row is already granted [proposal].

**C6: HOLD.** No, the build zone is not closed. E020 points build at UAT; it does not say what the replica holds [doc: E020, E024]. If it holds real records, it is a path from prod to a model that skips sanitisation [doc: E017], and prompt retention is unknown [doc: K20]. A model may read the replica only if it is synthetic or tokenised at load [proposal]. Otherwise build runs on the other three substrates [doc: E024].

**C7: MOVE.** Eight boxes was a detail view. Three data boxes plus box 5 carry the top. The register sits inside box 5, lineage inside the recorder [proposal]. I HOLD two points. No single evidence-and-findings box: different classes, different exit rules [doc: E110, E158]. The entitlement record is not the broker: box 6 mints from box 5's record. A credential expires; an auditor needs who granted what [proposal].

## Objections to the draft landscape
- Box 13 sits on both sides of the gate. Draw 11 as "Restricted stores: evidence, code, findings, apart" and 13 as "Working store: released copies" [proposal].
- Missing arrow: UAT data -> Build, UNPROVEN [doc: E024].
- Missing arrow: Model gateway -> Restricted stores: invocation logs, classed as findings [doc: E178]. Arrow 6 carries code and exploit detail [doc: K20].

## One compromise I could live with
C6. Tokenise identifiers consistently when the replica is loaded, by fixed rules, no model [proposal]. Claude Code then reads it. Cost: the tokeniser needs an owner, and none is named [doc: E047]. Rules matching literal names or hosts cannot be tested in build; they run as a slower UAT job in execution.
