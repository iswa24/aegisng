# Round 4 outcome: the Cyberspace landscape

Decided by: nobody (no person in the room). "Settled" means the room recommends it; all of it stays `proposed`.

## Where each conflict ended

**C1. Prompt change: who approves, how fast. Settled.** A UAT content change is live the same day, on automated checks plus one team peer; nobody outside the team. Agents dropped "the regression set alone"; Platform dropped "days".

**C2. What leaves the team. Settled in part.** The gate is keyed on reach: SecOps reviews an envelope once, and read-only changes inside it ship without SecOps. This relaxes E028. Still disputed:
- Who signs inside a prod-capable envelope: a team peer (Platform, Cyberops, Data) or the lead (Security).
- Data: a new prod query pack still leaves the team where the source cannot enforce reach by dataset.
- A new read-only tool: gate plus team peer (Security, Platform); outside the team once when a model gets it (Agents); always outside, within one working day (Cyberops).

**C3. Persona. Settled in the main.** The envelope is Security's record of reach, with a data row only the data owner grants. A persona is a team's selection inside one envelope, catalogued, composed the same day. Wider means a new envelope. (Reviewer's note: the agent systems architect ended on 'a persona is the Security-owned envelope itself', so who owns the word 'persona' is not fully settled.)

**C4. Port before run. Rule settled, interim disputed.** Nothing un-ported runs in the sandbox or execution; porting is the ticket to the sandbox, not to the platform. Until the wrapper is known, existing harnesses run in build against UAT (Platform, Agents) or stay in G35 as the named interim place (Cyberops).

**C5. What reaches execution. Settled in part.** No arrow from sandbox to execution; no agent submits or approves. Still disputed: a human-typed read-only query. Platform, Security and Cyberops back it, in three shapes; Agents holds against free text a model may have written [doc: K02]. It relaxes E032.

**C6. A model on UAT replica data. Drawing settled.** Unproven until we know what the replica holds. If real records: tokenise at load (Platform, Data) or pass the release gate first (Cyberops); Security calls it prod data.

**C7. Data on the top view. Settled in the main.** The entitlement record decides; the broker enforces and mints from it. Evidence and findings stores stay apart. Register and lineage are not top-view boxes. Security's separate broker box [doc: K08] is not drawn; Security still asks for it (reviewer's note).

**C8. Sandbox isolation. Settled.** Drawn unproven. Two network profiles: scan detached; pen-test detached with a pinned egress proxy. "Blocked" needs the network team's answer [doc: Q23] and a failing probe from inside.

**C9. Where Claude Code lives. Settled in part.** The build workspace is a platform-owned profile; hosts sit outside. First host: G35 Workspaces (Platform, Cyberops) or undecided (Security). Build to prod is drawn unproven [doc: E013].

## What only the owner can settle, most important first

1. Does "no Claude at run time" [doc: E001] cover the agent sandbox, or only compute with prod reach?
2. May SecOps review an envelope once instead of each prod-capable change [doc: E028]? Who signs inside it?
3. May a person type a read-only query mid-investigation [doc: E032, E006]?
4. Does the UAT replica hold real prod records? Who owns the tokeniser?
5. Which host carries the build workspace first? Is G35 the interim place for harnesses? Who pays for the first port?
6. Which clocks will the gate commit to, and where is a prod job approved [doc: E162]?
7. May the sandbox leave the flat network? Who owns the pen-test risk meanwhile?
8. Who owns envelopes, and who owns each data source?
9. Must scan and pen-test agents pass the one gate [doc: K14]?
10. Who approves a new tool for an agent?
