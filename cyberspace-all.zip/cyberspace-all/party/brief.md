# Design party brief: the Cyberspace platform landscape

Date: 2026-11-24. Room: architecture board (five architects with the design team). The owner is not in the room, so **nothing decided here is a decision**. Everything the room produces is a recommendation for the owner.

## What the owner asked for

Her words were dictated, so a few are uncertain; this is the cleaned reading, with the uncertain words marked.

> Cyberspace is a next-generation operating environment for cyber: a **secure, isolated, persona-configurable workspace** that brings together **compute, governed data access, operational tooling and agent capabilities**, so our teams can **build, test, investigate, automate and respond without risking production**.
>
> This is the engineering-facing program design, built on the initiative's own hub *(uncertain wording: "initiative own hub")*. **The agent sandbox is an engineering effort inside Cyberspace, not the whole thing.**
>
> We should build **platform capabilities** such that the cyber teams themselves can come in and **modify their agents, modify their own things**. The platform should be built in that fashion.
>
> Bring in multiple architect agents, let them talk with the design agent, and come up with the **system landscape design: how this system should be**. Base it on all the use cases.

So the output is a **system landscape** (the top of the design: the platform, its capabilities, who uses them, what it connects to, and where the existing engineering efforts sit inside it), drawn by the design team.

## The shift this asks for

The design so far (see below) is drawn as four separate systems: the Cyberspace execution platform, the code scan pipeline, the harness migration tool and Devspace. The owner is now saying:

1. Cyberspace is **one platform with capabilities**, and those systems are efforts inside it or users of it.
2. Cyber teams must be able to **serve themselves**: change their agents, personas, tools, runbooks and data access without a platform engineer doing it for them.

## Tensions the room must argue, not smooth over

These come from the owner's own statements and the project documents (ids are rows in `design/evidence-ledger.md`).

- **Self-service versus control.** The platform design says cyberops never get an interactive session into the execution platform (E016) and the platform cannot offer a "vibe coding" experience (E006). The owner now wants cyber teams to modify their own agents. What exactly can a cyber team change by itself, what goes through a gate, and what can it never do?
- **Speed.** Cyberops ship in weeks; the platform team follows the firm's delivery process and takes about a quarter. A platform that makes cyber teams wait a quarter will be bypassed.
- **Models at run time.** The platform design says no model runs in compute holding prod credentials (E015). The code scan pipeline and the pen-test agent run an agent with a model at run time, in an isolated account. Both live "inside Cyberspace". What is the rule that makes both true?
- **Two agent stacks.** The firm's direction is Google ADK through its own wrapper, SmartSDK (E004, E008). Cyberops build with Claude Code and have ten months of harnesses built that way (E002). What does "modify their agents" mean when build-time and run-time stacks differ?
- **Network.** UAT and prod share one flat network (E012). "Isolated" and "without risking production" have to be earned by design, not assumed.
- **Governed data access** is in the definition and almost absent from the documents.
- **Persona-configurable workspace** is in the definition; the documents have a persona desktop and persona runner images, but no model of who configures a persona and how.

## What is on disk (read what your role needs)

- `party/current-design-summary.txt` — the current design: 16 designs, 31 use cases. Start here.
- `design/evidence-ledger.md` — 195 facts taken from the ten project documents and the owner's notes, each with its source, how sure it is, and how far along it is. This is the room's evidence. Search it; do not read it end to end unless you need to.
- `design/open-items.md` — 69 open conflicts, risks and questions on the current design.
- `design/review-v3.md` — the last design review.
- `design/cyberspace-design.html` — the interactive design page (large; use `python3 .claude/skills/design-kit/page.py summary design/cyberspace-design.html --items` to see what is on it).
- The ten source documents live in a claude.ai Project. If you have a Projects tool you may read them (**read only**: never write or delete there). If you do not, the ledger is your source.

## Use cases the landscape must serve

All 31 in the summary, which fall into these families:

1. **Build**: a cyber team builds a component or agent and gets it approved.
2. **Run**: a job runs against a real environment with approval, recording and a kill switch.
3. **Investigate**: the team reads evidence and decides the next step.
4. **Scan**: new library versions and pushes to firm repositories are fetched and analysed by an agent in a sandbox; findings are reviewed and disclosed.
5. **Migrate**: existing Claude Code harnesses are analysed for the move to the firm's agent stack.
6. **Failure paths and data lifecycle**: stopped jobs, budget limits, refused calls, life of evidence.

And the new family the owner just named, which no use case covers yet:

7. **Self-service**: a cyber team changes its own agent, persona, tool, runbook or data access.

## Rules for everything you write

- Mark every claim as **[doc]** (give the ledger id) or **[proposal]** (yours). Never present a proposal as something the documents say.
- No person names. No new firm-internal names beyond those already in the ledger.
- Write plainly, in short sentences. No padding.
- Disagree where you disagree. The owner wants the argument, not a blend.
