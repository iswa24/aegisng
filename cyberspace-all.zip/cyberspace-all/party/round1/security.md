## Position in one paragraph
Three zones, one rule: **a model and prod reach never share a compute boundary** [proposal]. That makes both efforts legitimate. The execution zone holds prod credentials and runs no model [doc: E015, E023]. The agent zone runs a model on hostile input [doc: E106] and must have no credential or route to prod [proposal]. The build zone has Claude Code and UAT only [doc: E020]. Teams own content inside an envelope; widening it needs someone outside the team [proposal]. "Isolated" is not earned yet: the agent zone's route to prod is unknown [doc: E187].

## Platform capabilities I insist on
1. **Per-run credential broker.** Short-lived, tagged credentials; runners and agents. [doc: E041, E115; one broker: proposal]
2. **One gate, one signed catalog.** Unsigned artifacts never run; every team. [doc: E027, E030; all agents: proposal]
3. **Persona envelope registry.** Persona = reach envelope: targets, tools, data, models, limits. Security owns envelopes; teams compose inside. [proposal, on E022, E043]
4. **Guards outside the workload.** Scope guard, recorder, kill, budgets; every job. [doc: E056, E032, E192]
5. **Agent zone.** Agent plus sandbox, fixed tools, write-only output through a validator; scan, pen-test, ported harnesses. [doc: E106, E109, E190; shared: proposal]
6. **Metered model gateway.** Metering outside the agent; logs classed as findings. [doc: E123, E178; single gateway: proposal]
7. **Evidence, sanitisation, entitlements.** Immutable evidence, sanitised analyst copy [doc: E017, E046]. Entitlement = persona × dataset, time-bound, logged [proposal].

## Self-service: what a cyber team changes alone, what goes through a gate, what it can never do
**Alone** (automated gate plus a team peer, no platform engineer) [proposal, extends E028]:
- Prompts, skills, decision tables. A prompt is not a control when tools and credentials are fixed outside it [doc: E190, E116]; regression runs automatically [doc: E124].
- Runbooks from catalogued tasks [doc: E035], query packs, detection rules.
- UAT-only components [doc: E028].
- A model from the approved list.

**Through a gate** (people outside the team):
- New tool, write tool, prod-capable persona: lead plus SecOps [doc: E028].
- Data entitlement, new model, toolchain image, network rule, higher budget [proposal].
- SecOps reviews an envelope once, not each read-only runbook inside it [proposal; relaxes E028].

**Never:**
- Approve its own change; let a model submit or approve [proposal; K02].
- Shell into a runner [doc: E016]; run unsigned artifacts [doc: E030].
- Put a model beside prod credentials [doc: E015].
- Edit gate, guards or evidence [doc: E017].
- Send first-party findings out [doc: E100].

## Boxes I want on the landscape
1. Build zone: Claude Code, UAT.
2. Promotion gate, catalog, persona registry.
3. Access layer: human actions only.
4. Control plane, credential broker.
5. Execution zone: runner, no model.
6. Agent zone: model, no prod.
7. Model gateway.
8. Evidence, findings, sanitisation.
9. Prod and UAT targets.

- Build zone -> Gate: change as pull request.
- Access layer -> Control plane: human-submitted job.
- Control plane -> Execution zone: job credentials, signed artifact.
- Execution zone -> Prod: scoped calls via proxy [doc: E043].
- Agent zone -> Model gateway: metered prompts.
- Agent zone -> Findings: write-only drop.
- Evidence -> Build zone: sanitised copy only.
- BLOCKED: Execution zone -> Model gateway [doc: E023]; Build zone -> Prod [doc: E020]; model -> Access layer [proposal].
- UNPROVEN: Agent zone -> Prod [doc: E187].

## Where the existing efforts sit
- Execution platform: boxes 3 to 5.
- Code scan pipeline: agent zone; findings in box 8.
- Pen-test agent: agent zone, egress pinned to one target [proposal]. Today: flat network [doc: E011, E012].
- Harness migration tool: build zone; reads, never executes [doc: E069].
- Devspace: outside the trust boundary. Undocumented, uses the prod proxy [doc: E013, E014].

## Two things I expect the other architects to get wrong
1. Calling an account or nono a boundary. The network is flat and nono is unverified [doc: E012, E113]. Give the agent zone a VPC with no attachment to the firm network; nono is the second layer [proposal].
2. Running ported ADK harnesses on runners. An ADK loop is a model loop [doc: E073]. Agent zone only [proposal].

## Questions only the owner can answer
1. Is the rule "no Claude at run time" [doc: E001] or "no model with prod reach" [doc: E015]?
2. One account is decided [doc: E091]. Which, and may the agent zone leave the flat network?
3. Must scan and pen-test agents pass the one gate?
4. Who owns envelopes and entitlements, and who approves prod runs?
5. Is Devspace inside the trust boundary [doc: E014]?
