## Position in one paragraph
"Governed data access" must mean one rule: nothing is read, moved or released without a class label, a named owner, an entitlement and a log entry. [proposal] The documents barely govern data: sanitisation has no rules or owner, retention is unset, entitlement is one word. [doc: E047, E045, E049] I want one governance capability over several separate stores, and a persona defined as a data scope first, an image second. [proposal]

## The kinds of data this platform handles
- Raw prod evidence: from runners; highest; SecOps roles only. [doc: E033, E044]
- Sanitised evidence: from sanitisation; analysts, UAT replay. [doc: E046, E024]
- Live prod source data: runners only, inside a persona allowlist. [doc: E043]
- First-party code and findings: never leave the firm. [doc: E100, E110]
- Open-source copies: public but hostile; deleted after scan. [doc: E090]
- Findings, reproducers, traces, model logs: exploit detail; restricted, logged. [doc: E178]
- Control records (jobs, personas, approvals, manifests): integrity-critical. [doc: E034]
- UAT replica data: sensitivity unstated [doc: E024]; treat as prod. [proposal]

## Platform capabilities I insist on
1. Data register: every source and store with owner, class, retention, permitted personas. Everyone reads it. [proposal]
2. Entitlements: persona data scopes, requested by teams, approved by data owners, time-boxed. Job validation reads it. [doc: E049; service is proposal]
3. Class label at write: immutable, on every object. [doc: E110; platform-wide is proposal]
4. Release gate: the one way out of a restricted zone. Sanitisation and disclosure are both instances. [doc: E017, E111; unifying is proposal]
5. Lineage and read log: each output names its job, component version and inputs; restricted reads are logged. [doc: E044, E178; platform-wide is proposal]

## Self-service: what a cyber team changes alone, what goes through a gate, what it can never do
Alone [proposal; E028 requires an engineer even for UAT]:
- Edit a query pack against a source its persona already holds, in UAT.
- Shorten retention of its own working data.

Gate:
- Run a query pack on prod. [doc: E028]
- Onboard a data source; widen a persona's scope. [proposal]
- Change a sanitisation rule; lengthen retention; export anything. [proposal]

Never:
- Approve its own entitlement. [proposal]
- Read raw evidence from the build side. [doc: E017, E033]
- Lower a class label; send first-party findings outside. [doc: E110]
- Send unsanitised prod data to a model. [doc: E015, E054]

## Boxes I want on the landscape
1. Data register: what exists, owner, class. [proposal]
2. Entitlements: who reads what. [proposal]
3. Source connectors: governed doors to prod and UAT sources. [proposal]
4. Raw zone: evidence store, code store, findings drop. [doc: E044, E188]
5. Release gate: sanitise, human release. [doc: E046, E111]
6. Working zone: sanitised evidence, replay fixtures. [doc: E024]
7. Findings store: findings, traces, model logs. [doc: E167, E178]
8. Lineage and read log. [proposal]

Arrows:
- Source connectors -> Raw zone: collected prod records; sensitive. [proposal]
- Entitlements -> Job validation: persona data scope; integrity-critical. [doc: E049]
- Raw zone -> Release gate -> Working zone: raw in, sensitive; redacted out, lower. [doc: E017, E046]
- Working zone -> Build workspace: sanitised evidence, within reach of a model. [doc: E018, E033]
- Findings store -> Release gate -> Maintainers: open-source findings only, human-confirmed. [doc: E110, E111]

## Where the existing efforts sit
One governance capability, several stores. [proposal] Evidence store and findings store share a pattern: tamper-proof intake, integrity check, restricted reads. [doc: E044, E033, E109, E178; the comparison is proposal] Keep them apart, and findings apart from internet-fed catalogue data, as the review says. [doc: E158] The Artifact Catalog is a component registry; the scan catalog is a work inventory. Neither is a data catalogue. [doc: E029, E103]

## Two things I expect the other architects to get wrong
1. Drawing persona as image plus tools. [doc: E018, E038] A query pack is data access written as code [doc: E022], so agent self-service becomes data self-service unnoticed. [proposal]
2. Treating model prompts and logs as plumbing. They carry first-party code and exploit detail with no stated store or reader, and "sanitised" is undefined. [doc: open items K20, Q02]

## Questions only the owner can answer
1. Who owns each prod data source?
2. Does the UAT replica hold real prod records?
3. What retention per class? Is an irreversible lock acceptable?
4. May the sanitisation classifier be a model? Who owns it?
5. Must we use an existing firm entitlement and classification scheme?
