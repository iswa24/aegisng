## Position in one paragraph
I side with self-service: control at the fence, not at the keyboard [proposal]. The fence: no model beside prod credentials [doc: E015], a human approves prod [doc: E050]. Inside it, my teams change their own agents the same day [proposal]. We ship in weeks; the platform takes a quarter [doc: brief]. If this is slower than G35 [doc: E002], my people stay there [proposal].

## A day on this platform, for four of my people
**Detection engineer**
- Opens the persona desktop with Claude Code [doc: E018].
- Writes a rule, tests it on the replica SIEM [doc: E024].
- Waits for lead + SecOps to reach prod [doc: E028]. Lacks a threshold change without re-promotion [proposal].

**Incident responder**
- Opens the job form [doc: E032].
- Runs an approved read-only runbook on prod [doc: E032].
- Waits for approval, place undecided [doc: E162]. Lacks a follow-up query: the form takes no free text [doc: E032].

**Red team / pen tester**
- Opens the build desktop [doc: E018].
- Runs an agent with a model against one in-scope UAT target [doc: E011].
- Waits to learn if G34 is a range [doc: E025]. Lacks a way to declare scope and launch today [proposal].

**Vulnerability researcher**
- Opens the review UI [doc: E119].
- Confirms findings that carry a reproducer [doc: E107].
- Waits on limits with no numbers [doc: E191]. Lacks a way to change the agent's fixed tools and rerun [doc: E190; proposal].

## What my teams must be able to change by themselves, same day
All [proposal], peer-reviewed and replay-tested:
- Agent prompts, skills, decision tables, query packs, detection rules, UAT runbooks.
- Personas built from approved tools and UAT targets; budgets inside a team cap.

## What I accept goes through a gate, and how long that gate may take
- Prod-capable persona or write tool: lead + SecOps [doc: E028]. One working day [proposal].
- Prod job: just-in-time approval [doc: E050]. Fifteen minutes in an incident, one hour otherwise [proposal].
- New capability: a quarter [proposal].

## What I accept we can never do
- Run a model where prod credentials live [doc: E015].
- Take a shell on a prod runner [doc: E016].
- Move raw evidence to the build side [doc: E017].
- Approve our own prod job, or let an agent approve one [proposal; risk K02].

## Platform capabilities I need
1. A place to build with Claude Code on UAT data [doc: E020].
2. A place to run an agent loop with a model against a contained target, no prod credentials [doc: E011, E085; shared: proposal].
3. A way to change my agent or persona and see it live today, no image build [proposal].
4. A way to request data and see my entitlements [proposal].
5. A way to run an approved prod job with recording and kill [doc: E032, E044].
6. A way to ask a follow-up question mid-investigation [proposal].

## Where the current design fails my teams
- E022 freezes judgement into flow branches. Our harnesses are agent loops; where a ported one runs is undecided [doc: E002, E073].
- E016 with E032: investigation is not a form [proposal].
- E028, E050, E162: approvers named, no clock, no place [doc].
- E020 assumes Devspace. We are on G35 Workspaces [doc: E002].
- E038: a persona is an image; nobody is named to configure one [doc: brief].

## Two things I expect the architects to get wrong
1. They will call a pull request to the platform team self-service. That is a ticket queue [proposal].
2. They will make ADK porting the entry ticket. SmartSDK is unknown; the migration tool never ran on a real harness [doc: E010, E068]. Take our harnesses as they are [proposal].

## Questions only the owner can answer
1. Does "no vibe coding" [doc: E006] cover the build side, or only execution?
2. May our agent loops run with a model against contained targets, like the pen-test agent [doc: E011]?
3. Which gate times will you commit to?
4. Who may create a persona: a team lead or the platform team?
5. When do we get a cyber model [doc: E005]?
