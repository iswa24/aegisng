## Position in one paragraph
An agent is a versioned bundle of parts [proposal]. Teams own the parts that carry judgement; the platform owns the parts that set reach, and teams pick reach from lists [proposal]. Self-service means a team changes its judgement parts and an evaluation promotes them, with no platform engineer [proposal]. One run-time capability, the agent cell, serves scan, pen-test and ported harnesses [proposal].

## What "a cyber team modifies its own agent" has to mean
- **Instructions, skills:** team. Regression set, promoted on pass [doc: E124 for scan; proposal beyond]. The next run uses it [proposal].
- **Tools:** team picks from the catalog. A new tool passes the gate [doc: E027]. A write tool needs lead and SecOps [doc: E028].
- **Model:** team picks from a platform-owned list [proposal]; a change is re-evaluated [doc: E124].
- **Limits:** team sets them under a platform ceiling [proposal]. Metering sits outside the agent [doc: E123].
- **Sandbox image:** platform owns the base; team requests additions [proposal].
- **Data it may read:** the data owner grants, never the team [proposal]; the per-run role carries it [doc: E116].
- **Where it may write:** platform-fixed: drop and trace only [doc: E116].
- **Stop:** team may pull it, never disable it [proposal].

Two stacks: Claude Code authors, in the build plane [doc: E015, E020]. What runs is one agent configuration on the ADK wrapper [doc: E085 for scan; proposal beyond]. Teams never keep two copies [proposal]. Whether the wrapper supports custom tools and an external sandbox is unknown [doc: E131].

## Platform capabilities I insist on
1. **Agent registry.** Versioned prompt, model, tools, image, limits. Teams. [doc: E103 for scan; proposal beyond]
2. **Evaluation and promotion.** A regression set decides, not a person. Teams. [doc: E124]
3. **Agent cell.** Agent task with model access; sandbox task with no role; per-run credentials. Every agent. [doc: E106, E115]
4. **Validator and write-only drop.** Output is schema-checked data. Reviewers. [doc: E109]
5. **External stop.** Kills tasks, revokes sessions. Leads, orchestrator. [doc: E192]
6. **Model access.** Approved list, metering, restricted logs. Platform team. [proposal; doc: E130 undecided]

## The rule for models at run time
A model runs only in a cell with no prod credential and no route to prod. Prod credentials live only in compute with no route to a model [doc: E015, E023]. Only data crosses, through a fixed-rule check [proposal]. Draw two zones and one guarded line. "No route" must be enforced outside the agent, because UAT and prod share one network [doc: E012].

## Boxes I want on the landscape
1. Workbench: Devspace, Claude Code.
2. Agent repo.
3. Evaluation gate.
4. Registry: signed agents, tools, runbooks.
5. Agent cell.
6. Model access.
7. Broker and stop controller.
8. Validator and drop.
9. Runner: prod credentials, no model.
10. Prod targets.

- Workbench -> Repo: edits
- Repo -> Gate: candidate
- Gate -> Registry: signed version
- Registry -> Cell: pinned configuration
- Cell -> Model access: metered prompts
- Broker -> Cell: per-run credentials, kill
- Cell -> Validator: findings as data

Blocked: Cell -> Prod targets. Runner -> Model access. Workbench -> Cell [doc: E016]. Cell -> Registry.

## Where the existing efforts sit
Scan analysis and the pen-test agent are one capability: an agentic sandbox [doc: E007]. Pen-test adds egress to one target [doc: E011]. Runbooks are a different run-time kind, without a model [doc: E022, E023], sharing gate, registry and stop [proposal]. The migration tool is a build-plane on-ramp, not a run-time tenant [doc: E069].

## Two things I expect the other architects to get wrong
1. Sending every prompt change to an approver. Evaluation gates prompts; people gate reach [proposal].
2. Treating "isolated account" as isolation. It rests on nono, unverified [doc: E113].

## Questions only the owner can answer
1. Does "no Claude at run time" [doc: E001] ban Claude models, or only Claude Code?
2. May an instruction change go live on a regression pass alone?
3. Must scan and pen-test agents pass the same gate as runbooks?
4. Do ported harnesses run only in cells, never on runners [doc: E073]?
5. Who owns the approved model list and metering [doc: E130]?
