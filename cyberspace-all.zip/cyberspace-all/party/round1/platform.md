E = ledger row. K = open item.

## Position in one paragraph

Cyberspace is one platform: a control plane, a catalogue and three isolated workspace classes [proposal]. Self-service means a team changes components in its own repo and an automated gate publishes them, with no platform engineer in the path [proposal]. It never means a shell in execution [doc: E016]. The speed gap [brief] closes by splitting content from capability: content ships in days through the gate, capability on the firm's quarter [proposal]. Teams edit an agent's definition; the platform runs it on the firm's stack [proposal; E004]. A content change needing a platform ticket is a platform defect [proposal].

## Platform capabilities I insist on

1. **Control plane API.** Jobs, approvals, kill. Every team and pipeline calls it. [doc: E034]
2. **Component catalogue.** One signed catalogue for everything runnable [doc: E029, E030], agent configurations included [proposal]. Teams publish; the control plane reads.
3. **One risk-tiered gate.** Automated checks; extra humans only for prod-capable or write changes [doc: E027, E028]. Replaces three separate paths [doc: K14] [proposal].
4. **Golden-path scaffold.** A working component repo in minutes, for cyber teams [doc: E021].
5. **Workspace classes.** Build, execution, agent sandbox: platform-owned profiles of network, credentials and whether a model is allowed [proposal; E038, E106].
6. **Data access grants.** Per-team, per-persona entitlements as short-lived credentials [proposal; E041, E115].
7. **Model route with metering.** Team budgets, measured outside the agent [doc: E023, E123].
8. **Evidence and kill.** On every run [doc: E044, E053].

## Self-service: what a cyber team changes alone, what goes through a gate, what it can never do

**Alone** (automatic gate; an engineer approves [doc: E028], the team's own [proposal]):
- A UAT-only prompt, runbook, query pack, detection rule, decision table or read-only tool.
- Narrowing a persona; an approved-list model; budgets inside quota [proposal].
- UAT jobs [doc: E050].

**Through a gate:**
- Anything prod-capable or with a write tool: lead plus SecOps [doc: E028].
- A run-time agent's prompt, model or toolchain: regression set [doc: E124].
- A new or wider persona [proposal].
- A new data entitlement: the data owner approves [proposal].
- Each prod job [doc: E050].

**Never:**
- A shell in execution [doc: E016].
- A model beside prod credentials [doc: E015].
- Launching anything uncatalogued [doc: E030]; editing evidence [doc: E017].
- Changing network rules, gate checks or the scope guard; approving its own promotion [proposal].

## Boxes I want on the landscape

1. Team build workspace: persona desktop, Claude Code, UAT only [doc: E018, E020].
2. Team component repos [doc: E021].
3. Promotion gate [doc: E027].
4. Component catalogue [doc: E029].
5. Control plane and portal [doc: E032, E034].
6. Execution workspaces: no model [doc: E038].
7. Agent sandboxes: model, no prod credentials [doc: E106].
8. Data access broker [proposal].
9. Model route and meter [doc: E023].
10. Evidence and findings, behind sanitisation [doc: E044, E046].

- 1 -> 2 -> 3 -> 4: component change, pull request, signed version.
- 1 -> 5: job requests, approvals, kill; humans only [doc: K02].
- 5 -> 6, 7: launch with per-run credentials.
- 8 -> 6, 7: scoped data credentials.
- 1, 7 -> 9: metered model calls; never from 6.
- 6, 7 -> 10 -> 1: evidence, then the sanitised copy.

## Where the existing efforts sit

- Execution platform: the platform core, boxes 3 to 6 [proposal].
- Code scan pipeline: a tenant product. Its sandbox becomes box 7, shared with the pen-test agent [proposal; E007].
- Harness migration tool: an onboarding service in box 1 [doc: E069].
- Devspace: another team's product [doc: K03].

## Two things I expect the other architects to get wrong

1. Security will put a human on every change. That is a ticket queue; teams return to G35 [doc: E002].
2. Someone will give agents their own gate and catalogue: the platform built twice [doc: K14].

## Questions only the owner can answer

1. Is the tenant a cyber team, whose lead approves UAT-only changes?
2. Must scan and pen-test agents pass the same gate [doc: K14]?
3. Who approves a data entitlement?
4. Acceptable gate turnaround for a prompt change: hours or days?
